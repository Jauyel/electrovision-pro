# ElectroVision AI PRO — Audit & Patch Notes

This package is a cautious patch of the uploaded project. Existing React/TypeScript modules and routes were preserved.

## Changes applied
- Made the floating AI Co-Pilot entry point visible on mobile as well as desktop.
- Added client-side image type and 12 MB size validation before room/blueprint scanning.
- Sent the image MIME type to the backend and made the server infer MIME type from a data URL where available. Unsupported image formats are rejected clearly.
- Reduced oversized API payload exposure with an 18 MB JSON body limit, suitable for a 12 MB image encoded as base64.
- Added a lightweight in-memory per-IP rate limit to POST requests under `/api/ai` (30 requests per minute). For multi-instance production, replace this with a shared rate limiter and authenticated user identity.
- Limited AI chat messages to 6,000 characters and chat history to the latest 12 turns, with per-turn truncation.

## Important existing capability
The project already includes an AI Engineering Co-Pilot modal with chat, audit, room/blueprint scan, and project generation tabs. It uses `/api/ai/chat`, `/api/ai/audit`, `/api/ai/blueprint-scan`, and `/api/ai/generate-project`.

## Not yet verified
- Production build and TypeScript/lint checks could not run because npm dependencies were not installed in this environment (`vite: not found`; dependency installation timed out).
- Live Gemini API behavior requires a valid `GEMINI_API_KEY` configured through the host's secrets mechanism.
- Camera scanning, AI model availability, electrical calculation accuracy, PDF export, and full end-to-end workflows still need runtime testing.
- The in-memory rate limiter is not shared across multiple server instances and is not a substitute for authentication or production abuse controls.

## Before deployment
1. Run `npm install` in a network-enabled environment.
2. Configure `GEMINI_API_KEY` as a server-side secret; never put it in client code.
3. Run `npm run lint` and `npm run build` and fix all reported errors.
4. Test chat, audit, project generation, image scan, project save/restore, and PDF export.
5. Have a qualified electrician review engineering formulas and standards before using calculations for real installations.
