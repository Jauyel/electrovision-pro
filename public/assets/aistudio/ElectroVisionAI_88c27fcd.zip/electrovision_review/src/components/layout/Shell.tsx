import React, { useEffect } from 'react';
import { TopHeader } from './TopHeader';
import { Sidebar } from './Sidebar';
import { useProject } from '../../context/ProjectContext';
import { Dashboard } from '../dashboard/Dashboard';
import { AIObjectScanner } from '../scanner/AIObjectScanner';
import { InstallationMode } from '../installation/InstallationMode';
import { PanelBuilder } from '../panel/PanelBuilder';
import { ElectricalCAD } from '../cad/ElectricalCAD';
import { MaterialEstimator } from '../estimator/MaterialEstimator';
import { ProjectsView } from '../projects/ProjectsView';
import { ReportsView } from '../reports/ReportsView';
import { SettingsView } from '../settings/SettingsView';
import { ComplianceAuditor } from '../compliance/ComplianceAuditor';
import { ProjectTemplates } from '../templates/ProjectTemplates';
import { AiCopilotModal } from '../ai/AiCopilotModal';
import { Modal } from '../common/Modal';
import { Sparkles, Bot, ShieldCheck } from 'lucide-react';

export const Shell: React.FC = () => {
  const { 
    activeModule, 
    isAiModalOpen, 
    aiModalTab, 
    openAiModal, 
    closeAiModal,
    isTemplatesModalOpen,
    closeTemplatesModal
  } = useProject();

  // Keyboard shortcut listener (Cmd+J / Ctrl+J to toggle AI Co-Pilot)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'j') {
        e.preventDefault();
        if (isAiModalOpen) {
          closeAiModal();
        } else {
          openAiModal('audit');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAiModalOpen, openAiModal, closeAiModal]);

  const renderActiveModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <Dashboard />;
      case 'scanner':
        return <AIObjectScanner />;
      case 'installation':
        return <InstallationMode />;
      case 'panel':
        return <PanelBuilder />;
      case 'cad':
        return <ElectricalCAD />;
      case 'estimator':
        return <MaterialEstimator />;
      case 'compliance':
        return <ComplianceAuditor />;
      case 'templates':
        return <ProjectTemplates />;
      case 'projects':
      case 'saved':
        return <ProjectsView />;
      case 'reports':
        return <ReportsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#030B18] text-[#F4F8FF] flex flex-col relative">
      {/* Top Application Header */}
      <TopHeader />

      {/* Main Container with Sidebar + Content Canvas */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar />

        {/* Dynamic Content Canvas */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#030B18]">
          <div className="max-w-7xl mx-auto">
            {renderActiveModule()}
          </div>
        </main>
      </div>

      {/* Global Floating AI Co-Pilot Trigger Badge */}
      <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 flex items-center gap-2">
        <button
          onClick={() => openAiModal('chat')}
          className="group flex items-center gap-2.5 px-3 sm:px-4 py-2.5 bg-gradient-to-r from-[#10243D] to-[#0B1C32] hover:from-[#147DFF] hover:to-[#18D8F2] text-[#F4F8FF] hover:text-[#030B18] border border-[#147DFF]/40 rounded-full shadow-2xl shadow-[#147DFF]/25 hover:shadow-[#18D8F2]/40 transition-all duration-300 cursor-pointer font-bold text-xs hover:scale-105"
          title="Open AI Engineering Co-Pilot (Ctrl+J / ⌘J)"
        >
          <div className="w-5 h-5 rounded-full bg-[#18D8F2]/20 group-hover:bg-[#030B18]/20 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-[#18D8F2] group-hover:text-[#030B18]" />
          </div>
          <span className="hidden xs:inline sm:inline">AI Co-Pilot</span>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#061426]/70 group-hover:bg-[#030B18]/30 text-[#18D8F2] group-hover:text-[#030B18] border border-white/10">
            ⌘J
          </span>
        </button>
      </div>

      {/* AI Engineering Co-Pilot Suite Modal */}
      <AiCopilotModal
        isOpen={isAiModalOpen}
        onClose={closeAiModal}
        defaultTab={aiModalTab}
      />

      {/* Global Project Templates & Presets Modal */}
      {isTemplatesModalOpen && (
        <Modal
          isOpen={isTemplatesModalOpen}
          onClose={closeTemplatesModal}
          title="Circuit Presets & Engineering Templates"
          maxWidth="max-w-6xl"
        >
          <ProjectTemplates isModalView onClose={closeTemplatesModal} />
        </Modal>
      )}
    </div>
  );
};
