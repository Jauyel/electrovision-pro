import React, { useState } from 'react';
import { 
  FolderKanban, 
  Plus, 
  MapPin, 
  Calendar, 
  User, 
  ArrowRight, 
  CheckCircle2, 
  ShieldCheck,
  Zap,
  Sparkles,
  Download,
  Layers
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { Modal } from '../common/Modal';

export const ProjectsView: React.FC = () => {
  const { 
    projects, 
    activeProject, 
    setActiveProjectId, 
    createNewProject, 
    setActiveModule,
    formatCurrency,
    openAiModal,
    downloadProjectPdf,
    openTemplatesModal
  } = useProject();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;
    createNewProject(name, location);
    setName('');
    setLocation('');
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-[#061426] border border-[#1B3A5C] rounded-xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <FolderKanban className="w-5 h-5 text-[#147DFF]" />
            <h1 className="text-xl font-extrabold text-[#F4F8FF] tracking-tight">Engineering Projects Portfolio</h1>
          </div>
          <p className="text-xs text-[#9EB2CC] mt-1">Manage multiple electrical installations across residential, commercial, and industrial facilities.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          <button
            onClick={openTemplatesModal}
            className="px-4 py-2 bg-[#0B1C32] hover:bg-[#10243D] border border-[#1B3A5C] text-[#F4F8FF] rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Browse pre-engineered circuit presets and project templates"
          >
            <Layers className="w-4 h-4 text-[#18D8F2]" />
            <span>Circuit Presets</span>
          </button>

          <button
            onClick={() => openAiModal('generate')}
            className="px-4 py-2 bg-gradient-to-r from-[#147DFF]/20 to-[#18D8F2]/20 hover:from-[#147DFF]/30 hover:to-[#18D8F2]/30 text-[#18D8F2] border border-[#18D8F2]/40 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#18D8F2]" />
            <span>AI Turnkey Generator</span>
          </button>

          <button
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#147DFF]/25 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Project</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {projects.map(p => {
          const isActive = p.id === activeProject.id;
          const totalWatts = p.cadCircuits.reduce((a, b) => a + b.powerWatts, 0);

          return (
            <div
              key={p.id}
              className={`p-5 rounded-xl border transition-all flex flex-col justify-between gap-4 ${
                isActive 
                  ? 'bg-[#0B1C32] border-[#147DFF] ring-2 ring-[#147DFF]/30 shadow-xl' 
                  : 'bg-[#0B1C32] border-[#1B3A5C] hover:border-[#147DFF]/40'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span className="text-[10px] font-mono text-[#18D8F2] bg-[#061426] px-2 py-0.5 rounded border border-[#1B3A5C]">
                      {p.code}
                    </span>
                    <h3 className="text-base font-bold text-[#F4F8FF] mt-1.5 leading-snug">{p.name}</h3>
                  </div>

                  {isActive && (
                    <span className="px-2 py-0.5 bg-[#00D6A0]/15 text-[#00D6A0] text-[10px] font-mono font-bold rounded border border-[#00D6A0]/30 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Active
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1 text-xs text-[#9EB2CC] mb-4">
                  <MapPin className="w-3.5 h-3.5 text-[#18D8F2]" />
                  <span>{p.location}</span>
                </div>

                <div className="grid grid-cols-3 gap-2 py-3 border-y border-[#1B3A5C]/60 text-xs font-mono">
                  <div>
                    <div className="text-[10px] text-[#9EB2CC]">Design Load</div>
                    <div className="font-bold text-[#F4F8FF]">{(totalWatts / 1000).toFixed(1)} kW</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-[#9EB2CC]">Enclosure</div>
                    <div className="font-bold text-[#FF9A24] truncate">{p.panelEnclosure.ipRating}</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-[#9EB2CC]">Standard</div>
                    <div className="font-bold text-[#00D6A0]">{p.standard}</div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[10px] font-mono text-[#9EB2CC]">
                  Lead: {p.leadEngineer}
                </span>

                <div className="flex items-center gap-2">
                  {!isActive && (
                    <button
                      onClick={() => setActiveProjectId(p.id)}
                      className="px-3 py-1.5 bg-[#061426] hover:bg-[#10243D] text-[#F4F8FF] text-xs font-semibold rounded-lg border border-[#1B3A5C] transition-colors"
                    >
                      Set Active
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setActiveProjectId(p.id);
                      setActiveModule('dashboard');
                    }}
                    className="px-3 py-1.5 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white text-xs font-bold rounded-lg flex items-center gap-1 transition-colors"
                  >
                    <span>Open Project</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Initialize New Project"
        subtitle="Set project code, site location, and initialize unified engineering databases."
      >
        <form onSubmit={handleCreate} className="space-y-4 text-xs">
          <div>
            <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Project Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Samarkand High-Tech Campus"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Location</label>
            <input
              type="text"
              placeholder="e.g. Samarkand, Uzbekistan"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
            />
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-[#1B3A5C]">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-3 py-1.5 bg-[#061426] text-xs font-medium text-[#9EB2CC] rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-[#147DFF] text-white text-xs font-bold rounded-lg"
            >
              Create Project
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
