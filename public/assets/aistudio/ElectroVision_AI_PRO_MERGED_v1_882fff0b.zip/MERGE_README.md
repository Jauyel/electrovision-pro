# ElectroVision AI PRO — merged source package (v1)

## What is included
- Main application: the third ZIP version, left intact as the root application.
- Full first-version source and assets: `integration/first-version/`.
- First-version Express/Gemini server: root `server.ts`.
- Required server/AI/PDF/chart dependencies added to root `package.json`.

## Important integration note
The two source versions use different React architectures and data stores. To avoid breaking the current third-version app, the first version's full source is preserved under `integration/first-version/` rather than blindly overwriting conflicting files. This means the archive combines the code, but the first-version AI modal, PDF reports, and dashboard are **not yet wired into the third-version UI**. They require a deliberate integration pass and tests.

## Run the current third-version UI
1. Install Node.js LTS.
2. In this folder run `npm install`.
3. Run `npm run dev`.

## Run the AI API server (separately)
1. Copy `.env.example` to `.env`.
2. Add a valid `GEMINI_API_KEY` to `.env` (never put it in frontend code or share it).
3. Run `npm run dev:api`.

The frontend currently needs API wiring before its AI controls can use the server. Do not treat the merge as production-ready until `npm run build:check`, API tests, mobile checks, and electrical-engineering validation pass.
