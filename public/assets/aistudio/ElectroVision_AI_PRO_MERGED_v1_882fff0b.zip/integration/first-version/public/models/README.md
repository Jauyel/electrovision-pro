# Imported 3D models

Put licensed `.glb` files into `devices/` and list their names (without `.glb`) in `manifest.json`.
Anything not listed, or failing to load, falls back to the built-in generic shape.

## Naming

`<kind>-<modules>m.glb`, kind in lower case, matching the panel library:

| Library item          | File                  |
| --------------------- | --------------------- |
| MCB single pole (1M)  | `mcb-1m.glb`          |
| MCB two pole (2M)     | `mcb-2m.glb`          |
| MCB three pole (3M)   | `mcb-3m.glb`          |
| MCB four pole (4M)    | `mcb-4m.glb`          |
| RCD two pole          | `rcd-2m.glb`          |
| RCBO two pole         | `rcbo-2m.glb`         |
| Contactor two pole    | `contactor-2m.glb`    |
| Terminal block        | `terminal-1m.glb`     |

```json
{ "devices": ["mcb-1m", "mcb-2m", "rcd-2m"] }
```

## Model requirements

- Y axis up, device front face towards +Z. Origin position does not matter (the app re-centres).
- The model's **width (X) must equal the real module width**: modules x 17.5 mm. The app scales uniformly by width,
  so height and depth then come out at true proportions. Model one device only, no rail, no wires.
- Keep it light: under roughly 1 MB and 50k triangles per device; compress textures. Draco/Meshopt are not enabled.
- Use only models you are licensed to ship. Manufacturer CAD files usually have their own terms; check them first.
