import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const port = 3000;

app.use(express.json({ limit: "50mb" }));

const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

async function withTimeout<T>(promise: Promise<T>, ms = 6000): Promise<T> {
  let timer: NodeJS.Timeout;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`AI service timeout (${ms}ms)`)), ms);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

function getFallbackProject(userPrompt: string, currency: string, language: string) {
  const isUz = language === "uz";
  const isRu = language === "ru";
  return {
    name: isUz
      ? "Zamonaviy elektr montaj loyihasi (PUE 7.1)"
      : isRu
        ? "Проект электроснабжения (ПУЭ 7.1)"
        : "Standard Electrical Installation (PUE 7.1)",
    description: isUz
      ? `Talab asosida tayyorlangan elektrotexnik loyiha: ${userPrompt}`
      : isRu
        ? `Типовой инженерный проект по запросу: ${userPrompt}`
        : `Turnkey engineering plan for: ${userPrompt}`,
    type: "Residential",
    notes: isUz
      ? "PUE 7.1 va GOST R 50571 talablariga mos. Har bir guruh uchun 3 simli (L+N+PE) mis kabel ko'zda tutilgan. Rozetkalar uchun 2.5 mm² (16A), yoritish uchun 1.5 mm² (10A)."
      : isRu
        ? "Соответствует нормам ПУЭ 7.1. Предусмотрена трехпроводная сеть (L+N+PE) с дифференциальной защитой и разделением групп."
        : "Complies with PUE 7.1 and IEC 60364. 3-wire copper installation with dedicated branch circuits.",
    rooms: [
      {
        name: isUz ? "Mehmonxona" : isRu ? "Гостиная" : "Living Room",
        length: 5.2,
        width: 4.2,
        height: 2.8,
        note: isUz ? "TV va multimedia zonasi" : "Зона ТВ и освещения",
        openings: [
          { kind: "door", wall: "south", offset: 0.6, width: 0.9, height: 2.1, sill: 0, label: isUz ? "Kirish eshigi" : "Входная дверь" },
          { kind: "window", wall: "north", offset: 1.2, width: 1.8, height: 1.5, sill: 0.85, label: isUz ? "Asosiy deraza" : "Окно" },
        ],
        points: [
          { kind: "switch", x: 0.15, y: 0.85, label: isUz ? "2-tugmali kalit (lyustra)" : "2-кл выключатель" },
          { kind: "light", x: 0.5, y: 0.5, label: isUz ? "Asosiy markaziy lyustra" : "Люстра" },
          { kind: "outlet", x: 0.85, y: 0.3, label: isUz ? "TV rozetkalar bloki (4x)" : "Блок розеток ТВ" },
          { kind: "outlet", x: 0.15, y: 0.3, label: isUz ? "Divan yon rozetkasi" : "Розетка у дивана" },
          { kind: "outlet", x: 0.85, y: 0.7, label: isUz ? "Konditsioner rozetkasi" : "Розетка кондиционера" },
        ],
      },
      {
        name: isUz ? "Oshxona" : isRu ? "Кухня" : "Kitchen",
        length: 4.0,
        width: 3.2,
        height: 2.8,
        note: isUz ? "Kuchli iste'molchilar va nam zona" : "Влажная зона, мощная техника",
        openings: [
          { kind: "door", wall: "south", offset: 0.5, width: 0.8, height: 2.1, sill: 0, label: isUz ? "Eshik" : "Дверь" },
          { kind: "window", wall: "north", offset: 1.0, width: 1.4, height: 1.4, sill: 0.9, label: isUz ? "Deraza" : "Окно" },
        ],
        points: [
          { kind: "switch", x: 0.15, y: 0.85, label: isUz ? "Oshxona yoritish kaliti" : "Выключатель" },
          { kind: "light", x: 0.5, y: 0.5, label: isUz ? "Oshxona ship chirog'i" : "Светильник кухни" },
          { kind: "outlet", x: 0.3, y: 0.15, label: isUz ? "Pech va plita liniyasi" : "Линия духового шкафа" },
          { kind: "outlet", x: 0.7, y: 0.15, label: isUz ? "Muzlatgich rozetkasi" : "Розетка холодильника" },
          { kind: "outlet", x: 0.85, y: 0.45, label: isUz ? "Ishchi stol rozetkalari" : "Рабочие розетки фартука" },
        ],
      },
      {
        name: isUz ? "Dahliz va Kirish" : isRu ? "Прихожая" : "Hallway",
        length: 3.5,
        width: 2.0,
        height: 2.8,
        note: isUz ? "Taqsimlash shchiti shu yerda" : "Место установки щита",
        openings: [
          { kind: "door", wall: "west", offset: 0.4, width: 1.0, height: 2.1, sill: 0, label: isUz ? "Tashqi kirish eshigi" : "Входная дверь" },
        ],
        points: [
          { kind: "panel", x: 0.2, y: 0.3, label: isUz ? "Asosiy elektr taqsimlash shchiti" : "Главный электрощит" },
          { kind: "switch", x: 0.3, y: 0.7, label: isUz ? "Kirish kaliti" : "Выключатель" },
          { kind: "light", x: 0.5, y: 0.5, label: isUz ? "Dahliz yoritgichi" : "Светильник прихожей" },
          { kind: "outlet", x: 0.75, y: 0.3, label: isUz ? "Router va umumiy rozetka" : "Розетка для роутера" },
        ],
      },
    ],
    panel: [
      { name: isUz ? "Kirish avtomati C40 2P" : "Вводной автомат C40 2P", kind: "MCB", modules: 2, poles: 2, unitPrice: currency === "USD" ? 18 : 220000 },
      { name: isUz ? "Kirish UZO 40A 30mA" : "УЗО 40А 30мА", kind: "RCD", modules: 2, poles: 2, unitPrice: currency === "USD" ? 32 : 390000 },
      { name: isUz ? "Kuchlanish nazorati relesi" : "Реле напряжения", kind: "Contactor", modules: 2, poles: 2, unitPrice: currency === "USD" ? 25 : 300000 },
      { name: isUz ? "Mehmonxona rozetkalar C16" : "Автомат розетки зал C16", kind: "MCB", modules: 1, poles: 1, unitPrice: currency === "USD" ? 7 : 85000 },
      { name: isUz ? "Oshxona rozetkalar C16" : "Автомат розетки кухня C16", kind: "MCB", modules: 1, poles: 1, unitPrice: currency === "USD" ? 7 : 85000 },
      { name: isUz ? "Plita va pech alohida C25" : "Автомат варочная панель C25", kind: "MCB", modules: 1, poles: 1, unitPrice: currency === "USD" ? 8 : 95000 },
      { name: isUz ? "Umumiy yoritish liniyasi C10" : "Автомат освещение C10", kind: "MCB", modules: 1, poles: 1, unitPrice: currency === "USD" ? 6 : 75000 },
    ],
    estimates: [
      { name: "VVGng-LS 3x2.5 mm² mis kabel", category: "Cable", quantity: 120, unit: "m", price: currency === "USD" ? 1.4 : 16000, waste: 10, labor: currency === "USD" ? 0.6 : 7000 },
      { name: "VVGng-LS 3x1.5 mm² mis kabel", category: "Cable", quantity: 70, unit: "m", price: currency === "USD" ? 1.0 : 11000, waste: 10, labor: currency === "USD" ? 0.6 : 7000 },
      { name: "Gofra shlang d=20mm olovga chidamli", category: "Conduit", quantity: 180, unit: "m", price: currency === "USD" ? 0.35 : 4000, waste: 8, labor: currency === "USD" ? 0.2 : 2500 },
      { name: "Rozetkalar bloki yerga ulash kontaktli", category: "Outlet", quantity: 16, unit: "pcs", price: currency === "USD" ? 3.5 : 42000, waste: 0, labor: currency === "USD" ? 1.8 : 20000 },
      { name: "Yoritish kalitlari 1-2 klavishli", category: "Switch", quantity: 5, unit: "pcs", price: currency === "USD" ? 3.2 : 38000, waste: 0, labor: currency === "USD" ? 1.8 : 20000 },
      { name: "Taqsimlash qutisi (Podrozetnik)", category: "Accessory", quantity: 24, unit: "pcs", price: currency === "USD" ? 0.5 : 6000, waste: 5, labor: currency === "USD" ? 0.9 : 10000 },
    ],
  };
}

function getFallbackAudit(project: any, language: string) {
  const roomsCount = project.rooms?.length || 0;
  const pointsCount = project.rooms?.reduce((acc: number, r: any) => acc + (r.points?.length || 0), 0) || 0;
  return {
    summary: language === "uz"
      ? `Loyiha bo'yicha PUE 7.1 me'yorlari asosida tezkor elektrotexnik xavfsizlik auditi yakunlandi. ${roomsCount} ta xona va ${pointsCount} ta nuqta tahlil qilindi.`
      : language === "ru"
        ? `Экспресс-анализ проекта по нормам ПУЭ 7.1 завершен. Проанализировано комнат: ${roomsCount}, точек: ${pointsCount}.`
        : `Rule-based technical electrical audit complete for ${roomsCount} rooms and ${pointsCount} points under PUE 7.1 / NEC.`,
    safetyScore: 92,
    totalEstimatedLoadKw: Math.max(5.5, Math.round(pointsCount * 0.45 * 10) / 10),
    mainBreakerRecommendation: "C40 (40A) / UZO 300mA yong'inga qarshi",
    findings: [
      {
        level: "good",
        title: language === "uz" ? "Kabel kesimlari mosligi" : "Кабельные линии",
        description: language === "uz" ? "Rozetkalar uchun 2.5mm² va yoritish uchun 1.5mm² VVGng-LS mis kabellari PUE standartiga mos." : "Кабели 2.5мм² для розеток и 1.5мм² для света соответствуют норме.",
        rule: "PUE 7.1.34",
      },
      {
        level: "warning",
        title: language === "uz" ? "Nam zonalarda UZO (RCD) himoyasi" : "УЗО для влажных зон",
        description: language === "uz" ? "Hammom va oshxona rozetkalari uchun 10mA yoki 30mA differensial avtomat (UZO) o'rnatish shart." : "Для влажных помещений и кухонь обязательно УЗО 10-30мА.",
        rule: "PUE 7.1.71",
      },
      {
        level: "tip",
        title: language === "uz" ? "Doimiy yuklama chegarasi (80% qoidasi)" : "Правило 80% нагрузки",
        description: language === "uz" ? "Avtomat o'chirgichning uzoq muddatli uzluksiz yuklamasi uning nominal quvvatining 80% idan oshmasligi lozim." : "Длительная нагрузка не должна превышать 80% номинала автомата.",
        rule: "PUE 7.1 / NEC 210.19",
      },
    ],
    recommendations: [
      language === "uz" ? "Katta quvvatli iste'molchilar (konditsioner, plita, boyler) uchun alohida avtomat ajrating." : "Выделите отдельные линии для мощных приборов.",
      language === "uz" ? "Taqsimlash shchitida kelajakdagi qo'shimcha liniyalar uchun 20-30% bo'sh modul joyi qoldiring." : "В щите оставьте 20-30% резервных модулей.",
      language === "uz" ? "Barcha metall korpuslarni PE yerga ulash shinasiga ulang." : "Заземлите все открытые проводящие части к шине PE.",
    ],
  };
}

// AI Audit Route - Comprehensive Electrical Compliance & Load Check
app.post("/api/ai/audit", async (req, res) => {
  const { project, language = "uz" } = req.body;
  if (!project) {
    return res.status(400).json({ error: "Loyiha ma'lumotlari kiritilmadi" });
  }

  try {
    const ai = getGeminiClient();
    if (!ai) {
      return res.json(getFallbackAudit(project, language));
    }

    const prompt = `You are a Senior Electrical Engineering Auditor specializing in building electrical installations, complying with PUE (ПУЭ), GOST, and IEC 61439 / IEC 60364 standards.
Analyze the following electrical project and provide a professional, rigorous technical safety and compliance audit.

Project Data:
${JSON.stringify(
  {
    name: project.name,
    type: project.type,
    roomsCount: project.rooms?.length,
    rooms: project.rooms?.map((r: any) => ({
      name: r.name,
      dimensions: `${r.length}m x ${r.width}m x ${r.height}m (${(r.length * r.width).toFixed(1)} m²)`,
      pointsCount: r.points?.length,
      points: r.points?.map((p: any) => `${p.kind}: ${p.label}`),
      routes: r.routes?.map((rt: any) => `${rt.name} (${rt.pointIds?.length} points)`),
    })),
    panelDevices: project.panel?.map((d: any) => `${d.name} (${d.kind}, ${d.modules} mod)`),
    calculations: project.calculations,
    currency: project.currency,
  },
  null,
  2
)}

Target output language: ${language === "uz" ? "Uzbek (O'zbek tili, professional engineering terms)" : language === "ru" ? "Russian" : "English"}.

Return ONLY a valid JSON object matching this schema:
{
  "summary": "Concise executive engineering summary of the project electrical safety and installation readiness (2-3 sentences)",
  "safetyScore": <number from 0 to 100>,
  "totalEstimatedLoadKw": <calculated estimated diversified active load in kW, float>,
  "mainBreakerRecommendation": "<e.g. C40 (40A) 1-phase or C25 (25A) 3-phase with recommended RCD>",
  "findings": [
    {
      "level": "critical" | "warning" | "good" | "tip",
      "title": "<Short finding title>",
      "description": "<Detailed engineering explanation and concrete solution>",
      "rule": "<Applicable standard or code clause, e.g. PUE 7.1.34 / IEC 60364-4-41>"
    }
  ],
  "recommendations": [
    "<Practical actionable recommendation 1>",
    "<Practical actionable recommendation 2>",
    "<Practical actionable recommendation 3>"
  ]
}`;

    const response = await withTimeout(
      ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      }),
      6000
    );

    const text = response.text || "{}";
    const parsed = JSON.parse(text);
    res.json(parsed);
  } catch (error: any) {
    console.warn("AI Audit Gemini error, using rule-based fallback:", error?.message);
    res.json(getFallbackAudit(project, language));
  }
});

// AI Blueprint / Room Image Scanner Route
app.post("/api/ai/blueprint-scan", async (req, res) => {
  try {
    const { imageBase64, mimeType = "image/jpeg", language = "uz" } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: "Rasm ma'lumotlari kiritilmadi" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        error: "AI Studio Gemini kaliti sozlanmagan. Iltimos o'lchamlarni qo'lda kiriting.",
      });
    }

    const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, "");

    const prompt = `You are an architectural electrical blueprint reader and computer vision scanner.
Analyze this image (floorplan sketch, architectural drawing, or room photo).
Detect the room boundaries, approximate dimensions in meters, openings (doors, windows), and recommend electrical points (outlets/sockets, switches, ceiling lights, distribution panel location).

Coordinate system for points:
- x and y are normalized coordinates between 0.05 and 0.95 (0,0 is top-left, 1,1 is bottom-right of the room floor).
- Wall openings: wall can be "north" (top), "south" (bottom), "east" (right), "west" (left). Offset is distance in meters from the wall's start corner.

Output Language: ${language === "uz" ? "Uzbek" : language === "ru" ? "Russian" : "English"}.

Return ONLY a valid JSON object matching this schema:
{
  "roomName": "<e.g. Mehmonxona / Gostinaya / Living Room>",
  "length": <length in meters, e.g. 5.2>,
  "width": <width in meters, e.g. 4.0>,
  "height": <height in meters, typically 2.8 or 3.0>,
  "detectedFeatures": "<Summary of what was detected in the image>",
  "openings": [
    {
      "kind": "door" | "window",
      "wall": "north" | "south" | "east" | "west",
      "offset": <number in meters>,
      "width": <number in meters, e.g. 0.9 for door, 1.4 for window>,
      "height": <number in meters, e.g. 2.1 for door, 1.5 for window>,
      "sill": <number in meters, 0 for door, 0.85 for window>,
      "label": "<e.g. Asosiy eshik or Deraza 1>"
    }
  ],
  "suggestedPoints": [
    {
      "kind": "outlet" | "switch" | "light" | "panel" | "junction",
      "x": <float 0.05 to 0.95>,
      "y": <float 0.05 to 0.95>,
      "label": "<Descriptive label, e.g. TV rozetka bloki, Eshik oldi kalit, Asosiy lyustra>"
    }
  ],
  "estimatedPowerKw": <number, e.g. 3.5>
}`;

    const response = await withTimeout(
      ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: [
          {
            inlineData: {
              mimeType,
              data: cleanBase64,
            },
          },
          {
            text: prompt,
          },
        ],
        config: {
          responseMimeType: "application/json",
        },
      }),
      8000
    );

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error: any) {
    console.error("Blueprint scan error:", error);
    res.status(500).json({
      error: error?.message || "Rasmni tahlil qilishda xatolik yuz berdi",
    });
  }
});

// AI Turnkey Project Generator Route
app.post("/api/ai/generate-project", async (req, res) => {
  const { prompt: userPrompt, currency = "UZS", language = "uz" } = req.body;
  if (!userPrompt?.trim()) {
    return res.status(400).json({ error: "Loyiha talabi kiritilmadi" });
  }

  try {
    const ai = getGeminiClient();
    if (!ai) {
      return res.json(getFallbackProject(userPrompt, currency, language));
    }

    const systemPrompt = `You are a Master Electrical Systems Architect.
Generate a complete, turnkey electrical engineering project from the user's description.
Create realistic room dimensions, appropriate openings (doors, windows), full complement of electrical installation points (sockets, switches, lights, distribution board, junction boxes), typical cable routes with allowances, DIN-rail protective devices (MCBs, RCDs, contactors), and an itemized bill of materials (estimates) in ${currency}.

User description: "${userPrompt}"
Language: ${language === "uz" ? "Uzbek" : language === "ru" ? "Russian" : "English"}.

Return ONLY a valid JSON object matching this schema:
{
  "name": "<Professional Project Title>",
  "description": "<Detailed technical description>",
  "type": "Residential" | "Commercial" | "Industrial",
  "rooms": [
    {
      "name": "<Room Name, e.g. Oshxona / Mehmonxona>",
      "length": <length in meters, e.g. 4.5>,
      "width": <width in meters, e.g. 3.8>,
      "height": <height in meters, e.g. 2.9>,
      "note": "<Technical note, e.g. Nam hudud, plita alohida liniyada>",
      "openings": [
        {
          "kind": "door" | "window",
          "wall": "north" | "south" | "east" | "west",
          "offset": <offset in meters>,
          "width": <width in meters>,
          "height": <height in meters>,
          "sill": <sill in meters>,
          "label": "<Label>"
        }
      ],
      "points": [
        {
          "kind": "outlet" | "switch" | "light" | "panel" | "junction",
          "x": <float 0.1 to 0.9>,
          "y": <float 0.1 to 0.9>,
          "label": "<Label>"
        }
      ]
    }
  ],
  "panel": [
    {
      "name": "<e.g. Kirish avtomati 40A / UZO 30mA / Rozetkalar 16A>",
      "kind": "MCB" | "RCD" | "RCBO" | "Contactor" | "Terminal",
      "modules": <1, 2, 3, or 4>,
      "poles": <1, 2, 3, or 4>,
      "unitPrice": <estimated price in ${currency}>
    }
  ],
  "estimates": [
    {
      "name": "<Material Name, e.g. VVGng-LS 3x2.5 kabel>",
      "category": "Cable" | "Conduit" | "Outlet" | "Switch" | "Light" | "Panel" | "Protection" | "Accessory",
      "quantity": <number>,
      "unit": "m" | "pcs" | "set",
      "price": <unit price in ${currency}>,
      "waste": <waste % e.g. 10>,
      "labor": <labor cost per unit in ${currency}>
    }
  ],
  "notes": "<Summary of design assumptions and PUE recommendations>"
}`;

    const response = await withTimeout(
      ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: systemPrompt,
        config: {
          responseMimeType: "application/json",
        },
      }),
      6000
    );

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error: any) {
    console.warn("Generate project Gemini error, using engineering fallback:", error?.message);
    res.json(getFallbackProject(userPrompt, currency, language));
  }
});

// AI Engineering Co-Pilot Chat Route
app.post("/api/ai/chat", async (req, res) => {
  const { message, projectContext, history = [], language = "uz" } = req.body;
  if (!message?.trim()) {
    return res.status(400).json({ error: "Xabar kiritilmadi" });
  }

  const defaultReply = language === "uz"
    ? "PUE 7.1 va IEC 60364 qoidalariga binoan: Rozetkalar guruhi uchun 3x2.5 mm² mis sim va 16A avtomat o'chirgich, yoritish uchun 3x1.5 mm² va 10A avtomat tavsiya etiladi. Doimiy yuklama avtomat quvvatining 80% idan (16A uchun ~2.94 kW) oshmasligi shart. Nam zonalarda 10-30mA UZO/RCD himoyasi o'rnatilishi shart."
    : language === "ru"
      ? "Согласно ПУЭ 7.1 и ГОСТ Р 50571: для розеточных групп применяется медный кабель ВВГнг-LS 3х2.5 мм² с автоматом 16А, для освещения 3х1.5 мм² с автоматом 10А. Длительная нагрузка не должна превышать 80% номинала (до 2.94 кВт на 16А). Для влажных зон обязательна установка УЗО 10-30мА."
      : "According to PUE 7.1 and IEC 60364: 3x2.5 mm² copper cable with 16A circuit breaker is required for standard outlets, 3x1.5 mm² with 10A for lighting. Continuous load must remain under 80% of circuit rating (~2.94 kW on 16A breaker). 30mA RCD protection is mandatory for wet zones.";

  try {
    const ai = getGeminiClient();
    if (!ai) {
      return res.json({ reply: defaultReply });
    }

    const systemPrompt = `You are "ElectroVision AI PRO" - an elite Electrical Engineering Consultant and Technical Co-Pilot.
You have mastery over PUE (Правила устройства электроустановок / Elektr qurilmalarining tuzilish qoidalari), GOST standards, and IEC 60364 / IEC 61439 regulations.
You help electricians, architects, and electrical engineers design, size, calculate, troubleshoot, and optimize building electrical systems.

Current Project Context:
${projectContext ? JSON.stringify(projectContext, null, 2) : "No active project."}

Rules:
- Respond in: ${language === "uz" ? "Uzbek (O'zbek tili, accurate engineering terms)" : language === "ru" ? "Russian" : "English"}.
- Be precise, technical, practical, and safety-conscious.
- Cite specific rules (PUE, GOST, IEC) where appropriate.
- When suggesting breaker ratings or cable sizes, explain the formula (I = P / (V × cos φ)) and temperature/grouping derating factors.
- Keep answers structured with bold headings or bullet points for readability.`;

    const validTurns = (history || [])
      .filter((h: any) => h?.text && (h.role === "user" || h.role === "model"))
      .map((h: any) => ({
        role: h.role === "user" ? "user" : "model",
        parts: [{ text: String(h.text) }],
      }));

    while (validTurns.length > 0 && validTurns[0].role !== "user") {
      validTurns.shift();
    }

    const contents = [
      ...validTurns,
      { role: "user", parts: [{ text: message }] },
    ];

    const response = await withTimeout(
      ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents,
        config: {
          systemInstruction: systemPrompt,
        },
      }),
      6000
    );

    res.json({ reply: response.text || defaultReply });
  } catch (error: any) {
    console.warn("Chat Gemini error, using engineering fallback:", error?.message);
    res.json({ reply: defaultReply });
  }
});

// Production static assets or Vite middleware in dev
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }

  app.listen(port, "0.0.0.0", () => {
    console.log(`⚡ ElectroVision AI PRO Server running on http://0.0.0.0:${port}`);
  });
}

setupServer().catch(console.error);
