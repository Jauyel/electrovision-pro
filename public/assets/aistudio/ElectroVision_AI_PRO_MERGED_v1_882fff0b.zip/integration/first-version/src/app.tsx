import { Link, Route, Switch } from "wouter";
import { Provider } from "./components/provider";
import { Shell } from "./components/shell";
import { StoreProvider } from "./model/store";
import Index from "./pages/index";
import Projects from "./pages/projects";
import RoomPage from "./pages/room";
import Calculations from "./pages/calculations";
import Estimator from "./pages/estimator";
import PanelPage from "./pages/panel";
import { LibraryPage, ReportsPage, SettingsPage, ValidationPage, WorkPage } from "./pages/other";

export default function App() {
  return (
    <Provider>
      <StoreProvider>
        <Shell>
          <Switch>
            <Route path="/" component={Index} />
            <Route path="/projects" component={Projects} />
            <Route path="/room">{() => <RoomPage mode="room" />}</Route>
            <Route path="/installation">{() => <RoomPage mode="installation" />}</Route>
            <Route path="/panel" component={PanelPage} />
            <Route path="/calculations" component={Calculations} />
            <Route path="/estimator" component={Estimator} />
            <Route path="/validation" component={ValidationPage} />
            <Route path="/work" component={WorkPage} />
            <Route path="/reports" component={ReportsPage} />
            <Route path="/library" component={LibraryPage} />
            <Route path="/settings" component={SettingsPage} />
            <Route>
              <div className="empty-state tall">
                <h2>404</h2>
                <p>This page does not exist.</p>
                <Link href="/" className="btn primary">
                  Dashboard
                </Link>
              </div>
            </Route>
          </Switch>
        </Shell>
      </StoreProvider>
    </Provider>
  );
}
