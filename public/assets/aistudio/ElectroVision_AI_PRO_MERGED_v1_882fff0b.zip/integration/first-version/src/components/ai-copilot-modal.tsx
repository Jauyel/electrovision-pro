import { useState, useRef } from "react";
import {
  Sparkles,
  ShieldCheck,
  ScanLine,
  Bot,
  Wand2,
  X,
  Upload,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  Lightbulb,
  ArrowRight,
  Loader2,
  Send,
  Zap,
  RotateCcw,
} from "lucide-react";
import { useStore } from "../model/store";
import { makeRoom, newId, type Room } from "../model/project";

type Tab = "audit" | "scan" | "generate" | "chat";

export function AiCopilotModal({
  isOpen,
  onClose,
  defaultTab = "audit",
}: {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: Tab;
}) {
  const { db, project, update, replace, t } = useStore();
  const [tab, setTab] = useState<Tab>(defaultTab);

  // Audit state
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditData, setAuditData] = useState<any>(null);
  const [auditError, setAuditError] = useState("");

  // Scan state
  const [scanImage, setScanImage] = useState<string | null>(null);
  const [scanLoading, setScanLoading] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const [scanError, setScanError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Generate state
  const [promptText, setPromptText] = useState("");
  const [generateLoading, setGenerateLoading] = useState(false);
  const [generateError, setGenerateError] = useState("");

  // Chat state
  const [messages, setMessages] = useState<Array<{ role: "user" | "model"; text: string }>>([
    {
      role: "model",
      text:
        db.language === "uz"
          ? "Assalomu alaykum! Men sizning AI muhandis yordamchingizman. PUE, GOST va IEC standartlari bo'yicha kabel hisoblari, avtomat tanlash, yuklama taqsimoti yoki loyihangiz xavfsizligi bo'yicha har qanday savolingizga javob berishga tayyorman."
          : db.language === "ru"
            ? "Здравствуйте! Я ваш инженерный ИИ-помощник. Помогу с расчётами по ПУЭ, подбором кабелей и автоматов, распределением фаз и проверкой электробезопасности."
            : "Hello! I am your AI Electrical Engineering Co-Pilot. Ask me anything about PUE/IEC codes, cable sizing, breaker selection, or electrical safety.",
    },
  ]);
  const [chatInput, setChatInput] = useState("");
  const [chatLoading, setChatLoading] = useState(false);

  if (!isOpen) return null;

  async function runAudit() {
    if (!project) return;
    setAuditLoading(true);
    setAuditError("");
    try {
      const res = await fetch("/api/ai/audit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ project, language: db.language }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Audit failed");
      }
      const data = await res.json();
      setAuditData(data);
    } catch (e: any) {
      setAuditError(e.message || "Tahlil qilishda xatolik yuz berdi");
    } finally {
      setAuditLoading(false);
    }
  }

  function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const b64 = reader.result as string;
      setScanImage(b64);
      setScanResult(null);
    };
    reader.readAsDataURL(file);
  }

  async function runScan() {
    if (!scanImage) return;
    setScanLoading(true);
    setScanError("");
    try {
      const res = await fetch("/api/ai/blueprint-scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: scanImage,
          language: db.language,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Scan failed");
      }
      const data = await res.json();
      setScanResult(data);
    } catch (e: any) {
      setScanError(e.message || "Skanerlashda xatolik yuz berdi");
    } finally {
      setScanLoading(false);
    }
  }

  function importScanToProject() {
    if (!project || !scanResult) return;
    const newRoom: Room = {
      id: newId(),
      name: scanResult.roomName || "Skanerlangan xona",
      length: Number(scanResult.length) || 4.5,
      width: Number(scanResult.width) || 3.5,
      height: Number(scanResult.height) || 2.8,
      note: scanResult.detectedFeatures || "AI Skaner orqali aniqlangan",
      openings: (scanResult.openings || []).map((o: any) => ({
        id: newId(),
        kind: o.kind === "window" ? "window" : "door",
        wall: o.wall || "north",
        offset: Number(o.offset) || 0.5,
        width: Number(o.width) || 0.9,
        height: Number(o.height) || 2.1,
        sill: Number(o.sill) || 0,
        label: o.label || "Eshik/Deraza",
      })),
      points: (scanResult.suggestedPoints || []).map((p: any) => ({
        id: newId(),
        kind: p.kind || "outlet",
        x: Math.max(0.05, Math.min(0.95, Number(p.x) || 0.5)),
        y: Math.max(0.05, Math.min(0.95, Number(p.y) || 0.5)),
        label: p.label || "Nuqta",
      })),
      routes: [],
    };

    update(project.id, (p) => ({
      ...p,
      rooms: [...p.rooms, newRoom],
    }));

    onClose();
  }

  async function runGenerate(customPrompt?: string) {
    const textToUse = customPrompt || promptText;
    if (!textToUse.trim()) return;
    setGenerateLoading(true);
    setGenerateError("");
    try {
      const res = await fetch("/api/ai/generate-project", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: textToUse,
          currency: project?.currency || "UZS",
          language: db.language,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Generation failed");
      }
      const data = await res.json();
      const newProjId = newId();
      const generatedProject = {
        id: newProjId,
        name: data.name || "AI Loyiha",
        description: data.description || "",
        type: data.type || "Residential",
        status: "in-progress" as const,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        customer: "",
        site: "",
        workOrder: "",
        currency: (project?.currency || "UZS") as "UZS" | "USD" | "RUB",
        contingency: 10,
        notes: data.notes || "Generatsiya qilingan PUE loyihasi",
        rooms: (data.rooms || []).map((r: any) => ({
          id: newId(),
          name: r.name || "Xona",
          length: Number(r.length) || 4.0,
          width: Number(r.width) || 3.0,
          height: Number(r.height) || 2.8,
          note: r.note || "",
          openings: (r.openings || []).map((o: any) => ({
            id: newId(),
            kind: o.kind === "window" ? "window" : "door",
            wall: o.wall || "north",
            offset: Number(o.offset) || 0.5,
            width: Number(o.width) || 0.9,
            height: Number(o.height) || 2.1,
            sill: Number(o.sill) || 0,
            label: o.label || "Ochilish",
          })),
          points: (r.points || []).map((pt: any) => ({
            id: newId(),
            kind: pt.kind || "outlet",
            x: Math.max(0.05, Math.min(0.95, Number(pt.x) || 0.5)),
            y: Math.max(0.05, Math.min(0.95, Number(pt.y) || 0.5)),
            label: pt.label || "Nuqta",
          })),
          routes: [],
        })),
        panel: (data.panel || []).map((d: any) => ({
          id: newId(),
          name: d.name || "Avtomat",
          kind: d.kind || "MCB",
          modules: Number(d.modules) || 1,
          poles: Number(d.poles) || 1,
          unitPrice: Number(d.unitPrice) || 45000,
        })),
        estimates: (data.estimates || []).map((e: any) => ({
          id: newId(),
          name: e.name || "Material",
          category: e.category || "Cable",
          quantity: Number(e.quantity) || 1,
          unit: e.unit || "m",
          price: Number(e.price) || 12000,
          waste: Number(e.waste) || 10,
          labor: Number(e.labor) || 5000,
        })),
        calculations: [],
      };

      replace({
        ...db,
        projects: [generatedProject, ...db.projects],
        activeId: newProjId,
      });

      onClose();
    } catch (e: any) {
      setGenerateError(e.message || "Loyiha generatsiya qilishda xatolik");
    } finally {
      setGenerateLoading(false);
    }
  }

  async function sendChatMessage() {
    if (!chatInput.trim() || chatLoading) return;
    const msg = chatInput.trim();
    setChatInput("");
    setMessages((prev) => [...prev, { role: "user", text: msg }]);
    setChatLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: msg,
          projectContext: project
            ? {
                name: project.name,
                rooms: project.rooms.map((r) => `${r.name}: ${r.points.length} points`),
                panel: project.panel.map((d) => d.name),
              }
            : null,
          history: messages,
          language: db.language,
        }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, { role: "model", text: data.reply || "Xatolik yuz berdi." }]);
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: "model",
          text: "Serverga ulanishda xatolik yuz berdi. Iltimos qaytadan urinib ko'ring.",
        },
      ]);
    } finally {
      setChatLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative flex flex-col w-full max-w-4xl max-h-[90vh] bg-[#0b1829] border border-[#23374f] rounded-2xl shadow-2xl overflow-hidden text-[#f1f6fc]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#102137] border-b border-[#23374f]">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-[#3b8cff] to-[#4bc8dc] text-white shadow-lg shadow-[#3b8cff]/20">
              <Sparkles size={22} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold tracking-tight text-white">ELECTROVISION AI PRO</h2>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-[#3b8cff]/20 text-[#69acff] border border-[#3b8cff]/40">
                  GEMINI 3.8
                </span>
              </div>
              <p className="text-xs text-[#9bb0c8]">
                {db.language === "uz"
                  ? "Aqlli elektr muhandisligi & PUE xavfsizlik assistenti"
                  : db.language === "ru"
                    ? "Умный электротехнический ассистент и аудит ПУЭ"
                    : "Intelligent electrical engineering & safety co-pilot"}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#9bb0c8] hover:text-white hover:bg-[#1a2d45] rounded-xl transition"
            aria-label="Close"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#23374f] bg-[#0d1c30] px-4">
          <button
            onClick={() => {
              setTab("audit");
              if (!auditData && project) runAudit();
            }}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold border-b-2 transition ${
              tab === "audit"
                ? "border-[#3b8cff] text-[#3b8cff] bg-[#102137]/60"
                : "border-transparent text-[#9bb0c8] hover:text-white"
            }`}
          >
            <ShieldCheck size={18} />
            {db.language === "uz" ? "Xavfsizlik Auditi" : db.language === "ru" ? "Аудит безопасности" : "Safety Audit"}
          </button>

          <button
            onClick={() => setTab("scan")}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold border-b-2 transition ${
              tab === "scan"
                ? "border-[#3b8cff] text-[#3b8cff] bg-[#102137]/60"
                : "border-transparent text-[#9bb0c8] hover:text-white"
            }`}
          >
            <ScanLine size={18} />
            {db.language === "uz" ? "Chizma / Rasm Skaneri" : db.language === "ru" ? "Сканер чертежей / фото" : "Blueprint / Photo Scanner"}
          </button>

          <button
            onClick={() => setTab("generate")}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold border-b-2 transition ${
              tab === "generate"
                ? "border-[#3b8cff] text-[#3b8cff] bg-[#102137]/60"
                : "border-transparent text-[#9bb0c8] hover:text-white"
            }`}
          >
            <Wand2 size={18} />
            {db.language === "uz" ? "Loyiha Generatori" : db.language === "ru" ? "Генератор проекта" : "Turnkey Generator"}
          </button>

          <button
            onClick={() => setTab("chat")}
            className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold border-b-2 transition ${
              tab === "chat"
                ? "border-[#3b8cff] text-[#3b8cff] bg-[#102137]/60"
                : "border-transparent text-[#9bb0c8] hover:text-white"
            }`}
          >
            <Bot size={18} />
            {db.language === "uz" ? "Muhandis Chat" : db.language === "ru" ? "Чат с инженером" : "Engineer Chat"}
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: AUDIT */}
          {tab === "audit" && (
            <div className="space-y-6">
              {!project ? (
                <div className="p-8 text-center bg-[#102137]/50 rounded-xl border border-[#23374f]">
                  <HelpCircle size={36} className="mx-auto mb-3 text-[#e9b663]" />
                  <h3 className="font-semibold text-lg">Faol loyiha tanlanmagan</h3>
                  <p className="text-sm text-[#9bb0c8] mt-1">
                    Audit o'tkazish uchun avval loyiha yarating yoki ro'yxatdan birortasini tanlang.
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between flex-wrap gap-4 p-4 bg-[#102137] border border-[#23374f] rounded-xl">
                    <div>
                      <span className="text-xs font-mono tracking-wider text-[#9bb0c8] uppercase">
                        {project.name}
                      </span>
                      <h3 className="text-base font-bold text-white mt-0.5">
                        {db.language === "uz"
                          ? "PUE & IEC Standartlari Bo'yicha Xavfsizlik Tekshiruvi"
                          : "Комплексный аудит электробезопасности"}
                      </h3>
                    </div>
                    <button
                      onClick={runAudit}
                      disabled={auditLoading}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#3b8cff] hover:bg-[#2f75db] text-white font-semibold text-sm transition shadow-lg shadow-[#3b8cff]/20 disabled:opacity-50"
                    >
                      {auditLoading ? <Loader2 size={16} className="animate-spin" /> : <RotateCcw size={16} />}
                      {auditLoading ? "Tahlil qilinmoqda..." : "Qayta audit qilish"}
                    </button>
                  </div>

                  {auditLoading && (
                    <div className="py-16 text-center space-y-3">
                      <Loader2 size={36} className="mx-auto animate-spin text-[#3b8cff]" />
                      <p className="text-sm font-medium text-[#9bb0c8]">
                        Gemini AI barcha xonalar, rozetkalar, kabellar va avtomatlarni PUE qoidalariga solishtirmoqda...
                      </p>
                    </div>
                  )}

                  {auditError && (
                    <div className="p-4 rounded-xl bg-[#f47785]/10 border border-[#f47785]/30 text-[#f47785] text-sm">
                      {auditError}
                    </div>
                  )}

                  {auditData && !auditLoading && (
                    <div className="space-y-6">
                      {/* Metric cards */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="p-4 rounded-xl bg-[#102137] border border-[#23374f]">
                          <span className="text-xs text-[#9bb0c8] uppercase font-mono">Xavfsizlik reytingi</span>
                          <div className="flex items-baseline gap-2 mt-1">
                            <span className="text-3xl font-extrabold text-[#37c99b]">
                              {auditData.safetyScore || 90}%
                            </span>
                            <span className="text-xs text-[#37c99b] font-medium">A'lo daraja</span>
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-[#102137] border border-[#23374f]">
                          <span className="text-xs text-[#9bb0c8] uppercase font-mono">Hisobiy quvvat</span>
                          <div className="flex items-baseline gap-2 mt-1">
                            <span className="text-3xl font-extrabold text-[#4bc8dc]">
                              {auditData.totalEstimatedLoadKw || "8.5"} kW
                            </span>
                            <span className="text-xs text-[#9bb0c8]">Bir vaqtda (Kс=0.7)</span>
                          </div>
                        </div>

                        <div className="p-4 rounded-xl bg-[#102137] border border-[#23374f]">
                          <span className="text-xs text-[#9bb0c8] uppercase font-mono">Tavsiya etilgan kirish</span>
                          <div className="text-lg font-bold text-[#e9b663] mt-1 truncate">
                            {auditData.mainBreakerRecommendation || "C40 (40A) / UZO 300mA"}
                          </div>
                        </div>
                      </div>

                      {/* Summary */}
                      <div className="p-4 rounded-xl bg-[#0a1829] border border-[#23374f]">
                        <h4 className="text-xs uppercase font-mono text-[#69acff] mb-1">Xulosa</h4>
                        <p className="text-sm text-[#f1f6fc] leading-relaxed">{auditData.summary}</p>
                      </div>

                      {/* Findings list */}
                      <div>
                        <h4 className="text-xs font-mono uppercase tracking-wider text-[#9bb0c8] mb-3">
                          Tekshiruv xulosalari ({auditData.findings?.length || 0})
                        </h4>
                        <div className="space-y-3">
                          {(auditData.findings || []).map((f: any, idx: number) => {
                            const isCrit = f.level === "critical";
                            const isWarn = f.level === "warning";
                            const isGood = f.level === "good";

                            return (
                              <div
                                key={idx}
                                className={`p-4 rounded-xl border flex gap-3 ${
                                  isCrit
                                    ? "bg-[#f47785]/10 border-[#f47785]/30"
                                    : isWarn
                                      ? "bg-[#e9b663]/10 border-[#e9b663]/30"
                                      : isGood
                                        ? "bg-[#37c99b]/10 border-[#37c99b]/30"
                                        : "bg-[#102137] border-[#23374f]"
                                }`}
                              >
                                <div className="mt-0.5">
                                  {isCrit ? (
                                    <AlertTriangle size={18} className="text-[#f47785]" />
                                  ) : isWarn ? (
                                    <AlertTriangle size={18} className="text-[#e9b663]" />
                                  ) : isGood ? (
                                    <CheckCircle2 size={18} className="text-[#37c99b]" />
                                  ) : (
                                    <Lightbulb size={18} className="text-[#69acff]" />
                                  )}
                                </div>
                                <div className="flex-1">
                                  <div className="flex items-center justify-between gap-2">
                                    <strong className="text-sm text-white">{f.title}</strong>
                                    {f.rule && (
                                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#07111f] border border-[#23374f] text-[#9bb0c8]">
                                        {f.rule}
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-xs text-[#9bb0c8] mt-1 leading-relaxed">
                                    {f.description}
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Recommendations */}
                      {auditData.recommendations?.length > 0 && (
                        <div className="p-4 rounded-xl bg-[#102137] border border-[#23374f]">
                          <h4 className="text-xs font-mono uppercase text-[#37c99b] mb-2">Amaliy tavsiyalar</h4>
                          <ul className="space-y-1.5 text-xs text-[#9bb0c8]">
                            {auditData.recommendations.map((rec: string, i: number) => (
                              <li key={i} className="flex items-start gap-2">
                                <span className="text-[#37c99b] font-bold">✓</span>
                                <span>{rec}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {/* TAB 2: BLUEPRINT SCANNER */}
          {tab === "scan" && (
            <div className="space-y-6">
              <div className="p-4 bg-[#102137] border border-[#23374f] rounded-xl text-xs text-[#9bb0c8] leading-relaxed">
                {db.language === "uz"
                  ? "Xona chizmasi, qog'ozdagi sxema eskizi yoki xonaning fotosuratini yuklang. Gemini AI xona o'lchamlari, eshik/derazalar va zarur elektr montaj nuqtalarini (rozetka, kalit, lyustra) avtomatik aniqlab beradi."
                  : "Загрузите чертёж, эскиз комнаты или фото помещения. ИИ определит размеры, проёмы и порекомендует электроточки."}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                {/* Upload box */}
                <div className="flex flex-col items-center justify-center border-2 border-dashed border-[#23374f] hover:border-[#3b8cff] transition rounded-2xl p-6 bg-[#0a1829] min-h-[260px] text-center relative overflow-hidden">
                  {scanImage ? (
                    <div className="relative w-full h-full max-h-[300px]">
                      <img
                        src={scanImage}
                        alt="Uploaded blueprint"
                        className="w-full h-full object-contain rounded-lg max-h-[280px]"
                      />
                      <button
                        onClick={() => {
                          setScanImage(null);
                          setScanResult(null);
                        }}
                        className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 hover:bg-black text-white"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload size={36} className="text-[#69acff] mb-3" />
                      <h4 className="font-semibold text-sm">Chizma yoki fotosuratni yuklang</h4>
                      <p className="text-xs text-[#9bb0c8] mt-1 mb-4">PNG, JPG, WEBP (maks. 20MB)</p>
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 rounded-xl bg-[#102137] border border-[#23374f] hover:bg-[#1a2d45] text-sm font-semibold transition"
                      >
                        Fayl tanlash
                      </button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleImageUpload}
                      />
                    </>
                  )}
                </div>

                {/* Controls & Output */}
                <div className="space-y-4">
                  <button
                    onClick={runScan}
                    disabled={!scanImage || scanLoading}
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-[#3b8cff] hover:bg-[#2f75db] text-white font-semibold text-sm transition shadow-lg shadow-[#3b8cff]/20 disabled:opacity-40"
                  >
                    {scanLoading ? <Loader2 size={18} className="animate-spin" /> : <ScanLine size={18} />}
                    {scanLoading ? "AI Chizmani o'rganmoqda..." : "AI Vision orqali tahlil qilish"}
                  </button>

                  {scanError && (
                    <div className="p-3 rounded-xl bg-[#f47785]/10 border border-[#f47785]/30 text-[#f47785] text-xs">
                      {scanError}
                    </div>
                  )}

                  {scanResult && (
                    <div className="p-4 rounded-xl bg-[#102137] border border-[#23374f] space-y-3">
                      <div className="flex items-center justify-between">
                        <strong className="text-sm text-white">{scanResult.roomName}</strong>
                        <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#3b8cff]/20 text-[#69acff]">
                          {scanResult.length}m × {scanResult.width}m ({((scanResult.length || 0) * (scanResult.width || 0)).toFixed(1)} m²)
                        </span>
                      </div>

                      <p className="text-xs text-[#9bb0c8]">{scanResult.detectedFeatures}</p>

                      <div className="text-xs text-[#9bb0c8] space-y-1">
                        <div>
                          <b>Ochilishlar:</b> {scanResult.openings?.length || 0} ta (eshik/deraza)
                        </div>
                        <div>
                          <b>Elektr nuqtalari:</b> {scanResult.suggestedPoints?.length || 0} ta
                        </div>
                      </div>

                      <button
                        onClick={importScanToProject}
                        className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#37c99b] hover:bg-[#2ea37d] text-white font-semibold text-xs transition"
                      >
                        <Zap size={15} />
                        Loyiha xonalariga qo'shish
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: TURNKEY PROJECT GENERATOR */}
          {tab === "generate" && (
            <div className="space-y-6">
              <div className="p-4 bg-[#102137] border border-[#23374f] rounded-xl text-xs text-[#9bb0c8] leading-relaxed">
                {db.language === "uz"
                  ? "Yangi ob'ekt haqida qisqacha yozing. Gemini AI barcha xonalarni, mebel va maishiy texnikaga mos rozetka/kalitlarni, taqsimlash shchitidagi avtomatlarni va to'liq xarajatlar smetasini hisoblab chiqadi."
                  : "Опишите объект, и ИИ создаст готовый проект с комнатами, электроточками, щитом и сметой."}
              </div>

              {/* Quick Prompt Templates */}
              <div>
                <span className="text-xs font-mono uppercase text-[#9bb0c8] block mb-2">
                  Tezkor andozalar:
                </span>
                <div className="flex flex-wrap gap-2">
                  {[
                    "3 xonali zamonaviy kvartira (mehmonxona, yotoqxona, oshxona, hammom)",
                    "2 qavatli kottej (zal, oshxona, 3 ta yotoqxona, garaj va qozonxona)",
                    "Kichik qahvaxona / restoran 70 m² (oshxona, zal, qahva bar)",
                    "Zamonaviy IT ofis 60 m² (open-space, server xonasi, muzokaralar xonasi)",
                  ].map((tpl, i) => (
                    <button
                      key={i}
                      onClick={() => setPromptText(tpl)}
                      className="text-xs px-3 py-1.5 rounded-lg bg-[#102137] hover:bg-[#1a2d45] border border-[#23374f] text-[#f1f6fc] text-left transition"
                    >
                      {tpl}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <textarea
                  rows={4}
                  value={promptText}
                  onChange={(e) => setPromptText(e.target.value)}
                  placeholder={
                    db.language === "uz"
                      ? "Masalan: Toshkentdagi yangi kottej. Oshxonada induksion plita, duxovka va idish yuvish mashinasi uchun alohida kuchli liniyalar kerak. 3 ta konditsioner..."
                      : "Например: 3-комнатная квартира с мощной техникой на кухне, кондиционерами и теплым полом..."
                  }
                  className="w-full p-4 rounded-xl bg-[#0a1829] border border-[#23374f] focus:border-[#3b8cff] outline-none text-sm text-[#f1f6fc] placeholder-[#6e849d] resize-none"
                />

                {generateError && (
                  <div className="p-3 rounded-xl bg-[#f47785]/10 border border-[#f47785]/30 text-[#f47785] text-xs">
                    {generateError}
                  </div>
                )}

                <button
                  onClick={() => runGenerate()}
                  disabled={!promptText.trim() || generateLoading}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-[#3b8cff] to-[#4bc8dc] hover:from-[#2f75db] hover:to-[#38b1c4] text-white font-bold text-sm transition shadow-lg shadow-[#3b8cff]/20 disabled:opacity-40"
                >
                  {generateLoading ? (
                    <Loader2 size={18} className="animate-spin" />
                  ) : (
                    <Wand2 size={18} />
                  )}
                  {generateLoading ? "AI Loyiha arxitekturasini yaratmoqda..." : "Yangi loyihani to'liq yaratish"}
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: CHAT WITH ELECTRICAL ENGINEER */}
          {tab === "chat" && (
            <div className="flex flex-col h-[500px]">
              {/* Message log */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                {messages.map((m, i) => (
                  <div
                    key={i}
                    className={`flex gap-3 ${m.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    {m.role === "model" && (
                      <div className="w-8 h-8 rounded-lg bg-[#102137] border border-[#23374f] flex items-center justify-center text-[#69acff] shrink-0">
                        <Bot size={18} />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] p-3.5 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap ${
                        m.role === "user"
                          ? "bg-[#3b8cff] text-white rounded-tr-none"
                          : "bg-[#102137] border border-[#23374f] text-[#f1f6fc] rounded-tl-none"
                      }`}
                    >
                      {m.text}
                    </div>
                  </div>
                ))}
                {chatLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-8 h-8 rounded-lg bg-[#102137] border border-[#23374f] flex items-center justify-center text-[#69acff] shrink-0">
                      <Bot size={18} />
                    </div>
                    <div className="p-3 rounded-xl bg-[#102137] border border-[#23374f] text-xs text-[#9bb0c8] flex items-center gap-2">
                      <Loader2 size={14} className="animate-spin text-[#3b8cff]" />
                      AI Muhandis javob tayyorlamoqda...
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Input */}
              <div className="pt-4 border-t border-[#23374f] mt-4 flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendChatMessage()}
                  placeholder={
                    db.language === "uz"
                      ? "Savolingizni yozing (masalan: 3 fazali shchitda yuklamani qanday taqsimlash kerak?)..."
                      : "Задайте технический вопрос по электрике..."
                  }
                  className="flex-1 px-4 py-2.5 rounded-xl bg-[#0a1829] border border-[#23374f] focus:border-[#3b8cff] outline-none text-xs text-white placeholder-[#6e849d]"
                />
                <button
                  onClick={sendChatMessage}
                  disabled={!chatInput.trim() || chatLoading}
                  className="px-4 py-2.5 rounded-xl bg-[#3b8cff] hover:bg-[#2f75db] text-white font-semibold text-xs transition disabled:opacity-40"
                >
                  <Send size={15} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
