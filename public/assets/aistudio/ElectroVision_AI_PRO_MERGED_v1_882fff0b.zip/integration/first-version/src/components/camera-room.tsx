import { useEffect, useRef, useState } from "react";
import { Camera, CameraOff, Check, Pause, Play, RotateCcw, Trash2, X } from "lucide-react";
import { newId, type RoomPhoto } from "../model/project";
type State = "idle" | "starting" | "live" | "paused";
export function CameraRoom({
  photos,
  onSave,
  onDelete,
  capacity,
}: {
  photos: RoomPhoto[];
  onSave: (photos: RoomPhoto[]) => void;
  onDelete: (id: string) => void;
  capacity: number;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sessionRef = useRef(0);
  const [state, setState] = useState<State>("idle");
  const [pending, setPending] = useState<RoomPhoto[]>([]);
  const [error, setError] = useState("");
  const stop = () => {
    sessionRef.current++;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setState("idle");
  };
  useEffect(
    () => () => {
      sessionRef.current++;
      streamRef.current?.getTracks().forEach((track) => track.stop());
    },
    [],
  );
  async function start() {
    const session = ++sessionRef.current;
    setError("");
    if (!navigator.mediaDevices?.getUserMedia) {
      setError(
        "Camera access needs HTTPS or localhost and a supported browser. Use manual measurements instead.",
      );
      return;
    }
    setState("starting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" } },
        audio: false,
      });
      if (session !== sessionRef.current) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      streamRef.current = stream;
      stream.getVideoTracks()[0]?.addEventListener(
        "ended",
        () => {
          setError("Camera session was interrupted.");
          stop();
        },
        { once: true },
      );
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      if (session === sessionRef.current) setState("live");
    } catch (e) {
      if (session !== sessionRef.current) return;
      stop();
      const name = e instanceof DOMException ? e.name : "";
      setError(
        name === "NotAllowedError"
          ? "Camera permission was denied. Enable it in browser settings or use manual measurements."
          : name === "NotFoundError"
            ? "No camera was found on this device."
            : `Camera could not start: ${e instanceof Error ? e.message : "Unknown error"}`,
      );
    }
  }
  function capture() {
    const video = videoRef.current;
    if (!video || !video.videoWidth || state !== "live") return;
    const ratio = Math.min(1, 960 / video.videoWidth, 720 / video.videoHeight);
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(video.videoWidth * ratio);
    canvas.height = Math.round(video.videoHeight * ratio);
    canvas.getContext("2d")?.drawImage(video, 0, 0, canvas.width, canvas.height);
    const image = canvas.toDataURL("image/jpeg", 0.62);
    if (image.length > 450000) {
      setError("Photo is too large for local storage. Move closer or reduce camera resolution.");
      return;
    }
    setPending((old) => [
      ...old,
      {
        id: newId(),
        image,
        capturedAt: new Date().toISOString(),
        note: "",
        source: "camera",
      },
    ]);
    setError("");
  }
  function finish() {
    if (pending.length) onSave(pending);
    setPending([]);
    stop();
  }
  function cancel() {
    setPending([]);
    stop();
    setError("Session cancelled. Unsaved captures were discarded.");
  }
  return (
    <div className="camera-workspace">
      <div className="camera-copy">
        <Camera size={19} />
        <div>
          <strong>Camera-assisted survey</strong>
          <span>
            Photos are stored in this browser only. Enter dimensions yourself; no AR measurement or
            automatic reconstruction is connected.
          </span>
        </div>
      </div>
      <div className={`camera-view ${state === "idle" ? "camera-idle" : ""}`}>
        <video
          ref={videoRef}
          playsInline
          muted
          autoPlay
          aria-label="Live camera preview"
          style={{ visibility: state === "idle" ? "hidden" : "visible" }}
        />
        {state === "idle" && (
          <div className="camera-placeholder">
            <CameraOff size={28} />
            <span>Camera off · permission requested only when started</span>
          </div>
        )}
        {state === "paused" && <span className="camera-paused">PAUSED</span>}
        {state === "live" && (
          <span className="camera-live">
            <i /> LIVE · LOCAL
          </span>
        )}
      </div>
      {error && (
        <div className="alert danger" role="alert">
          {error}
        </div>
      )}
      <div className="camera-actions">
        {state === "idle" ? (
          <button
            className="btn primary"
            onClick={() => void start()}
            disabled={photos.length >= capacity}
          >
            <Camera size={16} /> Start camera
          </button>
        ) : (
          <>
            {state === "live" ? (
              <>
                <button
                  className="btn primary"
                  onClick={capture}
                  disabled={pending.length + photos.length >= capacity}
                >
                  <Camera size={16} /> Capture photo
                </button>
                <button
                  className="btn outline"
                  onClick={() => {
                    streamRef.current?.getVideoTracks().forEach((t) => (t.enabled = false));
                    setState("paused");
                  }}
                >
                  <Pause size={16} /> Pause
                </button>
              </>
            ) : state === "paused" ? (
              <button
                className="btn primary"
                onClick={() => {
                  streamRef.current?.getVideoTracks().forEach((t) => (t.enabled = true));
                  setState("live");
                }}
              >
                <Play size={16} /> Resume
              </button>
            ) : (
              <span className="muted">Requesting camera permission…</span>
            )}
            <>
              {state !== "starting" && (
                <button className="btn outline" onClick={finish}>
                  <Check size={16} /> Finish & save ({pending.length})
                </button>
              )}
              <button className="btn danger-button" onClick={cancel}>
                <X size={16} /> Cancel
              </button>
            </>
          </>
        )}
      </div>
      {(pending.length > 0 || photos.length > 0) && (
        <>
          <div className="eyebrow">
            SURVEY PHOTOS · {photos.length} SAVED / {pending.length} IN SESSION
          </div>
          <div className="photo-grid">
            {[
              ...photos.map((photo) => ({ ...photo, saved: true })),
              ...pending.map((photo) => ({ ...photo, saved: false })),
            ].map((photo) => (
              <div className="photo-tile" key={photo.id}>
                <img
                  src={photo.image}
                  alt={`Room survey, ${new Date(photo.capturedAt).toLocaleString()}`}
                />
                <div>
                  <span>
                    {photo.saved ? "SAVED" : "UNSAVED"} ·{" "}
                    {new Date(photo.capturedAt).toLocaleTimeString()}
                  </span>
                  <button
                    type="button"
                    className="icon-button"
                    aria-label={`Delete ${photo.saved ? "saved" : "unsaved"} photo`}
                    onClick={() =>
                      photo.saved
                        ? onDelete(photo.id)
                        : setPending((old) => old.filter((p) => p.id !== photo.id))
                    }
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
      <div className="subtle-note">
        <RotateCcw size={15} /> Max {capacity} compressed local photos per room. Backups include
        these images. Hidden wiring cannot be detected by a normal phone camera.
      </div>
    </div>
  );
}
