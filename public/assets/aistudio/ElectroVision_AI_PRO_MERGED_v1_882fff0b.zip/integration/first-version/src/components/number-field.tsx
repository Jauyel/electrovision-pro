import { useEffect, useId, useRef, useState } from "react";

/**
 * Numeric input that lets the user type freely (empty field, "0.", "-") and only commits valid values.
 * `commit` may return an error message to reject a value; the field then keeps the typed text, shows
 * the message, and returns to the saved value on blur.
 */
export function NumberField({
  value,
  commit,
  min,
  max,
  step = "any",
  label,
  className,
  decimals,
}: {
  value: number;
  commit: (value: number) => string | void;
  min?: number;
  max?: number;
  step?: number | "any";
  label: string;
  className?: string;
  /** Round the displayed value to this many decimals (floating point noise from arithmetic). */
  decimals?: number;
}) {
  const shown = (n: number) => String(decimals === undefined ? n : Number(n.toFixed(decimals)));
  const [text, setText] = useState(shown(value));
  const [error, setError] = useState("");
  const editing = useRef(false);
  const errorId = useId();
  useEffect(() => {
    if (!editing.current) setText(shown(value));
  }, [value]);
  const check = (raw: string): string => {
    if (raw.trim() === "") return "Enter a number.";
    const n = Number(raw);
    if (!Number.isFinite(n)) return "Enter a valid number.";
    if (min !== undefined && n < min) return `Minimum is ${min}.`;
    if (max !== undefined && n > max) return `Maximum is ${max}.`;
    return commit(n) ?? "";
  };
  return (
    <>
      <input
        className={className}
        type="number"
        inputMode="decimal"
        aria-label={label}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        min={min}
        max={max}
        step={step}
        value={text}
        onFocus={() => {
          editing.current = true;
        }}
        onChange={(e) => {
          setText(e.target.value);
          setError(check(e.target.value));
        }}
        onBlur={() => {
          editing.current = false;
          setError("");
          setText(shown(value));
        }}
      />
      {error && (
        <small id={errorId} className="field-error" role="alert">
          {error}
        </small>
      )}
    </>
  );
}
