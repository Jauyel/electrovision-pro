import { useState } from "react";
import { DoorOpen, Plus, Trash2, View } from "lucide-react";
import { NumberField } from "./number-field";
import { firstFreeOffset, openingError, wallLength } from "../model/geometry";
import { newId, type Opening, type Room, type WallSide } from "../model/project";
const sides: WallSide[] = ["north", "south", "east", "west"];
export function OpeningsEditor({
  room,
  onChange,
}: {
  room: Room;
  onChange: (next: Opening[]) => void;
}) {
  const [kind, setKind] = useState<"door" | "window">("door");
  const [wall, setWall] = useState<WallSide>("north");
  const [error, setError] = useState("");
  function add() {
    const width = kind === "door" ? 0.9 : 1.2;
    const offset = firstFreeOffset(room, wall, width);
    if (offset === null) {
      setError(`No free ${width} m gap on the ${wall} wall.`);
      return;
    }
    const taken = new Set((room.openings ?? []).map((o) => o.label));
    let n = 1;
    while (taken.has(`${kind === "door" ? "Door" : "Window"} ${n}`)) n++;
    const opening: Opening = {
      id: newId(),
      kind,
      wall,
      offset,
      width,
      height: kind === "door" ? Math.min(2.1, room.height) : Math.min(1.2, room.height),
      sill: kind === "door" ? 0 : Math.max(0, Math.min(0.9, room.height - 1.2)),
      label: `${kind === "door" ? "Door" : "Window"} ${n}`,
    };
    const problem = openingError(room, opening);
    if (problem) {
      setError(problem);
      return;
    }
    onChange([...(room.openings ?? []), opening]);
    setError("");
  }
  function modify(id: string, changes: Partial<Opening>): string | void {
    const candidate = (room.openings ?? []).find((o) => o.id === id);
    if (!candidate) return;
    const next = { ...candidate, ...changes };
    const problem = openingError(room, next, id);
    if (problem) return problem;
    onChange((room.openings ?? []).map((o) => (o.id === id ? next : o)));
    setError("");
  }
  return (
    <div className="openings-editor">
      <div className="opening-add">
        <label>
          Opening
          <select
            aria-label="Opening type"
            value={kind}
            onChange={(e) => setKind(e.target.value as typeof kind)}
          >
            <option value="door">Door</option>
            <option value="window">Window</option>
          </select>
        </label>
        <label>
          Wall
          <select
            aria-label="Wall side"
            value={wall}
            onChange={(e) => setWall(e.target.value as WallSide)}
          >
            {sides.map((side) => (
              <option key={side} value={side}>
                {side} · {wallLength(room, side)} m
              </option>
            ))}
          </select>
        </label>
        <button className="btn outline" onClick={add}>
          <Plus size={16} /> Add opening
        </button>
      </div>
      {error && (
        <div className="alert danger" role="alert">
          {error}
        </div>
      )}
      {(room.openings ?? []).length === 0 && (
        <p className="muted">
          No openings yet. Add a door or window to a wall; geometry updates in both views.
        </p>
      )}
      {(room.openings ?? []).map((opening) => (
        <div className="opening-record" key={opening.id}>
          <div className="opening-title">
            {opening.kind === "door" ? <DoorOpen size={17} /> : <View size={17} />}
            <strong>{opening.label}</strong>
            <span>
              {opening.wall} wall · {wallLength(room, opening.wall)} m
            </span>
            <button
              className="icon-button"
              aria-label={`Remove ${opening.label}`}
              onClick={() => {
                if (window.confirm(`Remove ${opening.label}?`))
                  onChange((room.openings ?? []).filter((o) => o.id !== opening.id));
              }}
            >
              <Trash2 size={16} />
            </button>
          </div>
          <div className="opening-fields">
            <label>
              Offset (m)
              <NumberField
                label={`${opening.label} offset`}
                min={0}
                step={0.1}
                decimals={3}
                value={opening.offset}
                commit={(n) => modify(opening.id, { offset: n })}
              />
            </label>
            <label>
              Width (m)
              <NumberField
                label={`${opening.label} width`}
                min={0.1}
                step={0.1}
                decimals={3}
                value={opening.width}
                commit={(n) => modify(opening.id, { width: n })}
              />
            </label>
            <label>
              Height (m)
              <NumberField
                label={`${opening.label} height`}
                min={0.1}
                step={0.1}
                decimals={3}
                value={opening.height}
                commit={(n) => modify(opening.id, { height: n })}
              />
            </label>
            <label>
              Sill (m)
              <NumberField
                label={`${opening.label} sill`}
                min={0}
                step={0.1}
                decimals={3}
                value={opening.sill}
                commit={(n) => modify(opening.id, { sill: n })}
              />
            </label>
          </div>
        </div>
      ))}
    </div>
  );
}
