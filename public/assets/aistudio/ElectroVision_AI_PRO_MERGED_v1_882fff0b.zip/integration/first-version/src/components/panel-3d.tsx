import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import type { PanelDevice } from "../model/project";
import { deviceModelName, ensureDeviceModel, fitToWidth, peekDeviceModel } from "../lib/model-loader";
export type PanelView = "iso" | "front" | "side";
export function Panel3D({
  devices,
  selectedId,
  onSelect,
  view = "iso",
  cover = false,
  onModelStatus,
}: {
  devices: PanelDevice[];
  selectedId?: string;
  onSelect: (id: string) => void;
  view?: PanelView;
  cover?: boolean;
  /** Reports how many placed devices currently render an imported GLB instead of the generic shape. */
  onModelStatus?: (loaded: number, total: number) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const statusRef = useRef(onModelStatus);
  statusRef.current = onModelStatus;
  const camRef = useRef<{ view: PanelView; pos: THREE.Vector3; target: THREE.Vector3 } | null>(null);
  useEffect(() => {
    const host = ref.current;
    if (!host) return;
    let disposed = false;
    const extras: { dispose: () => void }[] = [];
    const isLight = document.documentElement.getAttribute("data-theme") === "light";
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(isLight ? "#e8edf5" : "#0a1929");
    const camera = new THREE.PerspectiveCamera(39, 1, 0.1, 100);
    camera.position.set(
      view === "side" ? 8 : view === "front" ? 0 : 5,
      view === "iso" ? 3.2 : 0,
      view === "side" ? 0 : 11,
    );
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    host.appendChild(renderer.domElement);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.target.set(0, 0, 0);
    controls.minDistance = 4;
    controls.maxDistance = 18;
    controls.enablePan = true;
    const saved = camRef.current;
    if (saved && saved.view === view) {
      camera.position.copy(saved.pos);
      controls.target.copy(saved.target);
    }
    controls.update();
    scene.add(
      new THREE.HemisphereLight(
        isLight ? 0xffffff : 0xbfdffc,
        isLight ? 0xa8bccc : 0x2b3d52,
        isLight ? 2.4 : 2,
      ),
    );
    const key = new THREE.DirectionalLight(0xffffff, 2.6);
    key.position.set(3, 5, 8);
    scene.add(key);
    const materials: THREE.Material[] = [];
    const surface = (color: number, metalness = 0, roughness = 0.65, opacity = 1) => {
      const mat = new THREE.MeshStandardMaterial({
        color,
        metalness,
        roughness,
        transparent: opacity < 1,
        opacity,
        depthWrite: opacity === 1,
      });
      materials.push(mat);
      return mat;
    };
    const charcoal = surface(0x223448, 0.22),
      backplate = surface(0x324e61, 0.43),
      steel = surface(0x899eaa, 0.78, 0.36),
      railFace = surface(0xb0bbc4, 0.8, 0.34),
      white = surface(0xdee6e8, 0.05, 0.48),
      paper = surface(0xf2f5ee),
      dark = surface(0x354451),
      cyan = surface(0x2a8fbf),
      amber = surface(0xe1a648),
      green = surface(0x58ac93),
      coverMat = surface(0x86b7d1, 0.06, 0.18, 0.19);
    function box(
      parent: THREE.Object3D,
      w: number,
      h: number,
      d: number,
      x: number,
      y: number,
      z: number,
      mat: THREE.Material,
    ) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      mesh.position.set(x, y, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      parent.add(mesh);
      return mesh;
    }
    function dot(
      parent: THREE.Object3D,
      r: number,
      x: number,
      y: number,
      z: number,
      mat: THREE.Material,
    ) {
      const mesh = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 0.012, 10), mat);
      mesh.rotation.x = Math.PI / 2;
      mesh.position.set(x, y, z);
      parent.add(mesh);
    }
    // 20-module illustrative enclosure, metal backplate, side depth, top and bottom cable entry.
    box(scene, 6.6, 3.75, 0.18, 0, 0, -0.65, backplate);
    box(scene, 0.16, 3.75, 1.85, -3.22, 0, 0.275, charcoal);
    box(scene, 0.16, 3.75, 1.85, 3.22, 0, 0.275, charcoal);
    box(scene, 6.6, 0.15, 1.85, 0, 1.81, 0.275, charcoal);
    box(scene, 6.6, 0.15, 1.85, 0, -1.81, 0.275, charcoal);
    for (const side of [-1, 1])
      for (let i = 0; i < 5; i++) {
        const x = -2.45 + i * 1.22;
        const cylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.04, 18), dark);
        cylinder.position.set(x, side * 1.8, 0.25);
        scene.add(cylinder);
        dot(scene, 0.055, x, side * 1.8, 0.28, steel);
      }
    for (const y of [0.64, -0.73]) {
      box(scene, 5.8, 0.12, 0.19, 0, y, -0.17, steel);
      for (const sx of [-2.6, 2.6]) box(scene, 0.14, 0.14, 0.3, sx, y, -0.41, steel); // standoffs to the backplate
      box(scene, 5.8, 0.036, 0.23, 0, y + 0.055, -0.04, railFace);
      for (let x = -2.7; x < 2.8; x += 0.28)
        box(scene, 0.12, 0.028, 0.01, x, y + 0.08, 0.083, charcoal);
    }
    // Unpopulated lower terminal strip and insulated busbar are explicitly illustrative.
    box(scene, 5.75, 0.21, 0.22, 0, -1.25, 0.05, charcoal);
    for (let i = 0; i < 16; i++) {
      let x = -2.65 + i * 0.35;
      box(scene, 0.27, 0.13, 0.09, x, -1.25, 0.22, green);
      dot(scene, 0.045, x, -1.25, 0.28, steel);
    }
    box(scene, 5.72, 0.045, 0.11, 0, 1.5, 0.03, amber);
    for (let i = 0; i < 20; i++) {
      const x = -2.72 + i * 0.28;
      box(scene, 0.09, 0.07, 0.09, x, 1.5, 0.12, dark);
    }
    let loaded = 0;
    const report = () => statusRef.current?.(loaded, deviceGroups.length);
    let used = 0;
    const deviceGroups: THREE.Group[] = [];
    for (const device of devices) {
      const modules = Math.max(1, Math.min(20, device.modules));
      if (used + modules > 20) continue;
      const width = modules * 0.27 - 0.018,
        x = -2.7 + used * 0.27 + width / 2;
      used += modules;
      const g = new THREE.Group();
      const body = new THREE.Group(); // generic fallback shape, replaced when an imported model loads
      g.add(body);
      g.position.set(x, 0.51, 0.22);
      g.userData.deviceId = device.id;
      scene.add(g);
      deviceGroups.push(g);
      const selected = device.id === selectedId,
        kind = device.kind;
      const housing = selected ? surface(0xe9f8fb) : white;
      box(body, width, 0.96, 0.48, 0, 0, 0.03, housing);
      box(body, width - 0.035, 0.64, 0.018, 0, -0.03, 0.285, paper);
      box(body,
        width - 0.03,
        0.17,
        0.045,
        0,
        0.32,
        0.31,
        kind === "RCD" ? cyan : kind === "RCBO" ? green : kind === "Contactor" ? amber : dark,
      );
      const poles = device.poles ?? Math.max(1, device.modules);
      const count = Math.min(poles, Math.max(1, Math.floor(width / 0.16)));
      for (let pole = 0; pole < count; pole++) {
        const px = (pole - (count - 1) / 2) * Math.min(0.22, width / count);
        box(body,
          Math.min(0.105, (width / count) * 0.7),
          0.25,
          0.085,
          px,
          -0.11,
          0.345,
          kind === "Contactor" ? dark : kind === "RCD" ? cyan : kind === "RCBO" ? green : dark,
        );
        box(body, Math.min(0.17, (width / count) * 0.8), 0.08, 0.06, px, 0.47, 0.16, dark);
        box(body, Math.min(0.17, (width / count) * 0.8), 0.08, 0.06, px, -0.47, 0.16, dark);
        dot(body, 0.025, px, 0.47, 0.2, steel);
        dot(body, 0.025, px, -0.47, 0.2, steel);
      }
      if (kind === "RCD" || kind === "RCBO")
        box(body, 0.095, 0.09, 0.04, -width * 0.23, -0.35, 0.33, amber);
      if (kind === "Contactor") {
        for (let i = 0; i < 2; i++) box(body, 0.12, 0.06, 0.04, (i - 0.5) * 0.18, -0.35, 0.33, cyan);
      }
      if (kind === "Terminal") {
        box(body, width - 0.045, 0.45, 0.08, 0, -0.05, 0.34, green);
        dot(body, 0.055, 0, -0.05, 0.4, steel);
      }
      // Terminal channels remain visible from the side to make the generic model identifiable.
      box(body, width, 0.045, 0.12, 0, 0.5, -0.15, dark);
      box(body, width, 0.045, 0.12, 0, -0.5, -0.15, dark);
      const attach = (template: THREE.Object3D) => {
        if (disposed) return;
        const fit = fitToWidth(template, width);
        if (!fit) return;
        g.remove(body);
        body.traverse((o) => {
          if (o instanceof THREE.Mesh) o.geometry.dispose();
        });
        g.add(fit.wrap);
        g.position.set(x, 0.64, 0.075 + fit.depth / 2); // back of the device sits on the rail face
        if (selected) {
          const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(fit.width, fit.height, fit.depth));
          const lineMat = new THREE.LineBasicMaterial({ color: 0x4bc8dc });
          extras.push(edges, lineMat);
          g.add(new THREE.LineSegments(edges, lineMat));
        }
        loaded++;
        report();
      };
      const modelName = deviceModelName(device.kind, device.modules);
      const ready = peekDeviceModel(modelName);
      if (ready) attach(ready);
      else void ensureDeviceModel(modelName).then((template) => template && attach(template));
    }
    report();
    if (cover) {
      const frame = surface(0x62849b, 0.45, 0.37, 0.8);
      box(scene, 6.55, 0.12, 0.13, 0, 1.82, 1.2, frame);
      box(scene, 6.55, 0.12, 0.13, 0, -1.82, 1.2, frame);
      box(scene, 0.12, 3.55, 0.13, -3.22, 0, 1.2, frame);
      box(scene, 0.12, 3.55, 0.13, 3.22, 0, 1.2, frame);
      box(scene, 6.3, 3.5, 0.035, 0, 0, 1.24, coverMat);
      box(scene, 0.08, 0.5, 0.15, 3.05, 0, 1.33, steel);
    }
    const raycaster = new THREE.Raycaster(),
      pointer = new THREE.Vector2();
    const select = (event: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.set(
        ((event.clientX - rect.left) / rect.width) * 2 - 1,
        -((event.clientY - rect.top) / rect.height) * 2 + 1,
      );
      raycaster.setFromCamera(pointer, camera);
      for (const hit of raycaster.intersectObjects(deviceGroups, true)) {
        let node: THREE.Object3D | null = hit.object;
        while (node && !node.userData.deviceId) node = node.parent;
        if (node?.userData.deviceId) {
          onSelect(String(node.userData.deviceId));
          break;
        }
      }
    };
    renderer.domElement.addEventListener("pointerup", select);
    const observer = new ResizeObserver(() => {
      const w = host.clientWidth,
        h = host.clientHeight;
      if (w && h) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    });
    observer.observe(host);
    let frame = 0;
    const animate = () => {
      frame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();
    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      camRef.current = { view, pos: camera.position.clone(), target: controls.target.clone() };
      renderer.domElement.removeEventListener("pointerup", select);
      observer.disconnect();
      controls.dispose();
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh && !obj.userData.sharedAsset) obj.geometry.dispose();
      });
      materials.forEach((m) => m.dispose());
      extras.forEach((e) => e.dispose());
      renderer.dispose();
      host.removeChild(renderer.domElement);
    };
  }, [devices, selectedId, onSelect, view, cover]);
  return (
    <div
      className="three-canvas panel-canvas engineering-viewport"
      ref={ref}
      aria-label="Interactive distribution board with selectable generic components"
    />
  );
}
