import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import {
  AlertTriangle,
  ArrowRight,
  Boxes,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  Download,
  ExternalLink,
  Eye,
  EyeOff,
  Filter,
  Layers,
  Maximize2,
  RotateCcw,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  TrendingUp,
  X,
  Zap,
} from "lucide-react";
import type { EstimateItem, PanelDevice, Point, Project, Room } from "../model/project";
import { calculateRoomLoad, estimateTotals, getPointPowerKw, isHvacPoint } from "../model/project";
import { compileItemizedRoomLoads, downloadItemizedPdfReport } from "../lib/pdf-report";
import { useStore } from "../model/store";

interface ProjectOverviewDashboardProps {
  project: Project;
  onSelectProject?: (id: string) => void;
  allProjects?: Project[];
  compact?: boolean;
}

// Engineering palette for Recharts
const COST_COLORS: Record<string, string> = {
  Cables: "#3b8cff",
  Protection: "#e9b663",
  Outlets: "#4bc8dc",
  Switches: "#37c99b",
  Lighting: "#818cf8",
  Conduits: "#fb923c",
  Accessories: "#94a3b8",
  Labor: "#c084fc",
  Contingency: "#f43f5e",
  Other: "#64748b",
};

export type LoadCategoryKey = "outlets" | "hvac" | "lighting" | "auxiliary" | "threshold";

export interface LoadCategoryMeta {
  key: LoadCategoryKey;
  label: string;
  shortLabel: string;
  color: string;
  dataKey: string;
  icon: string;
  desc: string;
}

export const LOAD_CATEGORIES: LoadCategoryMeta[] = [
  {
    key: "outlets",
    label: "Power Outlets & Appliances",
    shortLabel: "Outlets",
    color: "#4bc8dc", // Cyan
    dataKey: "displayOutletsKw",
    icon: "🔌",
    desc: "Receptacles, kitchen appliances, and plug loads",
  },
  {
    key: "hvac",
    label: "HVAC & Climate Control",
    shortLabel: "HVAC",
    color: "#fb923c", // Orange
    dataKey: "displayHvacKw",
    icon: "❄️",
    desc: "Air conditioners, electric space heaters, and boilers",
  },
  {
    key: "lighting",
    label: "Lighting & Illumination",
    shortLabel: "Lighting",
    color: "#818cf8", // Indigo
    dataKey: "displayLightsKw",
    icon: "💡",
    desc: "Luminaires, spots, chandeliers, and LED tracks",
  },
  {
    key: "auxiliary",
    label: "Auxiliary & Fixed Loads",
    shortLabel: "Auxiliary",
    color: "#37c99b", // Emerald
    dataKey: "displayOtherKw",
    icon: "⚡",
    desc: "Switches, junction points, and automation controls",
  },
  {
    key: "threshold",
    label: "80% Safety Ceiling",
    shortLabel: "Safety Limit",
    color: "#64748b", // Slate
    dataKey: "safeThresholdKw",
    icon: "🛡️",
    desc: "PUE 7.1 / NEC continuous duty circuit limit (80%)",
  },
];

type InspectedDrawer =
  | { type: "cost"; category: string }
  | { type: "room"; roomId: string }
  | null;

export function ProjectOverviewDashboard({
  project,
  onSelectProject,
  allProjects = [],
  compact = false,
}: ProjectOverviewDashboardProps) {
  const { db, theme } = useStore();
  const [activeTab, setActiveTab] = useState<"all" | "costs" | "energy">("all");
  const [exportingPdf, setExportingPdf] = useState(false);
  const [inspectedDrawer, setInspectedDrawer] = useState<InspectedDrawer>(null);

  // Cross-component interactive highlight state
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);
  const [hoveredRoomId, setHoveredRoomId] = useState<string | null>(null);

  // Load category legend toggle state: show/hide individual load classes
  const [visibleLoadCategories, setVisibleLoadCategories] = useState<Record<LoadCategoryKey, boolean>>({
    outlets: true,
    hvac: true,
    lighting: true,
    auxiliary: true,
    threshold: true,
  });

  // Visualization mode: "stacked" (segmented breakdown) or "total" (consolidated bar)
  const [loadChartMode, setLoadChartMode] = useState<"stacked" | "total">("stacked");

  const isLight = theme === "light";
  const currency = project.currency || "UZS";

  // Toggle single load category
  const toggleLoadCategory = (key: LoadCategoryKey) => {
    setVisibleLoadCategories((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Preset: show all categories
  const showAllLoadCategories = () => {
    setVisibleLoadCategories({
      outlets: true,
      hvac: true,
      lighting: true,
      auxiliary: true,
      threshold: true,
    });
  };

  // Close drawer on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setInspectedDrawer(null);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Currency Formatter
  const formatMoney = (val: number) => {
    const formatted = new Intl.NumberFormat("en-US", {
      maximumFractionDigits: currency === "USD" ? 2 : 0,
    }).format(Math.round(val));
    if (currency === "UZS") return `${formatted} so'm`;
    if (currency === "USD") return `$${formatted}`;
    return `${formatted} ₽`;
  };

  // 1. Cost Calculations & Recharts Data
  const costData = useMemo(() => {
    const totals = estimateTotals(project.estimates || [], project.contingency || 0);

    // Panel devices hardware cost
    const panelHardwareCost = (project.panel || []).reduce(
      (sum, d) => sum + (d.unitPrice || 0),
      0
    );

    const categoryMap: Record<string, { material: number; labor: number; count: number }> = {};

    (project.estimates || []).forEach((item) => {
      const cat = item.category || "Other";
      if (!categoryMap[cat]) {
        categoryMap[cat] = { material: 0, labor: 0, count: 0 };
      }
      const mat = item.quantity * item.price * (1 + (item.waste || 0) / 100);
      const lab = item.quantity * (item.labor || 0);
      categoryMap[cat].material += mat;
      categoryMap[cat].labor += lab;
      categoryMap[cat].count += 1;
    });

    // Translate category keys for friendly presentation
    const friendlyName = (raw: string) => {
      if (/cable/i.test(raw)) return "Cables";
      if (/protect|panel/i.test(raw)) return "Protection";
      if (/outlet/i.test(raw)) return "Outlets";
      if (/switch/i.test(raw)) return "Switches";
      if (/light/i.test(raw)) return "Lighting";
      if (/conduit/i.test(raw)) return "Conduits";
      if (/access/i.test(raw)) return "Accessories";
      return "Other";
    };

    const aggregated: Record<string, number> = {
      Cables: 0,
      Protection: panelHardwareCost,
      Outlets: 0,
      Switches: 0,
      Lighting: 0,
      Conduits: 0,
      Accessories: 0,
      Labor: totals.labor,
      Contingency: totals.reserve,
      Other: 0,
    };

    Object.entries(categoryMap).forEach(([rawCat, vals]) => {
      const standard = friendlyName(rawCat);
      aggregated[standard] = (aggregated[standard] || 0) + vals.material;
    });

    const totalProjectBudget =
      totals.material + totals.labor + totals.reserve + panelHardwareCost;

    // Data for Donut Chart
    const pieData = Object.entries(aggregated)
      .filter(([_, val]) => val > 0)
      .map(([name, val]) => ({
        name,
        value: Math.round(val),
        percent: totalProjectBudget > 0 ? (val / totalProjectBudget) * 100 : 0,
        color: COST_COLORS[name] || "#64748b",
      }))
      .sort((a, b) => b.value - a.value);

    // Top Cost Drivers (Top 5 items)
    const topItems = [...(project.estimates || [])]
      .map((item) => {
        const mat = item.quantity * item.price * (1 + (item.waste || 0) / 100);
        const lab = item.quantity * (item.labor || 0);
        return {
          id: item.id,
          name: item.name,
          category: item.category,
          quantity: item.quantity,
          unit: item.unit,
          total: mat + lab,
          share: totalProjectBudget > 0 ? ((mat + lab) / totalProjectBudget) * 100 : 0,
        };
      })
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);

    return {
      totals,
      panelHardwareCost,
      totalProjectBudget,
      pieData,
      topItems,
      friendlyName,
    };
  }, [project]);

  // 2. Energy Load Calculations & Recharts Data
  const energyData = useMemo(() => {
    const roomMetrics = (project.rooms || []).map((room) => {
      const load = calculateRoomLoad(room);
      const area = Math.round(room.length * room.width * 10) / 10;
      const outletsKw = load.breakdown.outletsKw;
      const hvacKw = load.breakdown.hvacKw;
      const lightsKw = load.breakdown.lightsKw;
      const otherKw = load.breakdown.otherKw;
      const safeThresholdKw = Math.round(load.capacityKw * 0.8 * 100) / 100;

      // Active visible load based on legend category toggles
      const visibleLoadKw = Math.round(
        ((visibleLoadCategories.outlets ? outletsKw : 0) +
          (visibleLoadCategories.hvac ? hvacKw : 0) +
          (visibleLoadCategories.lighting ? lightsKw : 0) +
          (visibleLoadCategories.auxiliary ? otherKw : 0)) *
          100
      ) / 100;

      return {
        id: room.id,
        roomName: room.name || "Room",
        areaM2: area,
        connectedLoadKw: load.totalLoadKw,
        visibleLoadKw,
        safeThresholdKw,
        displayOutletsKw: visibleLoadCategories.outlets ? outletsKw : 0,
        displayHvacKw: visibleLoadCategories.hvac ? hvacKw : 0,
        displayLightsKw: visibleLoadCategories.lighting ? lightsKw : 0,
        displayOtherKw: visibleLoadCategories.auxiliary ? otherKw : 0,
        maxCapacityKw: load.capacityKw,
        ratioPercent: load.ratioPercent,
        outletsKw,
        hvacKw,
        lightsKw,
        otherKw,
        pointsCount: room.points?.length || 0,
        status: load.status,
        isOver80: load.isOver80,
        isOver100: load.isOver100,
        fillColor: load.isOver100
          ? "#f47785"
          : load.isOver80
            ? "#e9b663"
            : load.ratioPercent >= 55
              ? "#4bc8dc"
              : "#37c99b",
      };
    });

    const totalAreaM2 = roomMetrics.reduce((sum, r) => sum + r.areaM2, 0);
    const totalConnectedKw = roomMetrics.reduce((sum, r) => sum + r.connectedLoadKw, 0);
    const totalVisibleKw = roomMetrics.reduce((sum, r) => sum + r.visibleLoadKw, 0);
    const diversifiedPeakKw = Math.round(totalConnectedKw * 0.78 * 100) / 100;

    const totalOutletsKw = Math.round(roomMetrics.reduce((sum, r) => sum + r.outletsKw, 0) * 100) / 100;
    const totalHvacKw = Math.round(roomMetrics.reduce((sum, r) => sum + r.hvacKw, 0) * 100) / 100;
    const totalLightsKw = Math.round(roomMetrics.reduce((sum, r) => sum + r.lightsKw, 0) * 100) / 100;
    const totalOtherKw = Math.round(roomMetrics.reduce((sum, r) => sum + r.otherKw, 0) * 100) / 100;

    const categoryTotals: Record<LoadCategoryKey, number> = {
      outlets: totalOutletsKw,
      hvac: totalHvacKw,
      lighting: totalLightsKw,
      auxiliary: totalOtherKw,
      threshold: Math.round(roomMetrics.reduce((sum, r) => sum + r.safeThresholdKw, 0) * 100) / 100,
    };

    const consumerTypeData = [
      { id: "outlets", name: "Power Outlets & Appliances", kw: totalOutletsKw, fill: "#4bc8dc" },
      { id: "hvac", name: "HVAC & Climate Control", kw: totalHvacKw, fill: "#fb923c" },
      { id: "lighting", name: "Lighting & Illumination", kw: totalLightsKw, fill: "#818cf8" },
      { id: "auxiliary", name: "Auxiliary & Fixed Loads", kw: totalOtherKw, fill: "#37c99b" },
    ].filter((x) => x.kw > 0);

    const overloadedRooms = roomMetrics.filter((r) => r.isOver80);
    const criticalRooms = roomMetrics.filter((r) => r.isOver100);

    // Power density (W/m2)
    const wattsPerM2 = totalAreaM2 > 0 ? Math.round((totalConnectedKw * 1000) / totalAreaM2) : 0;

    return {
      roomMetrics,
      totalAreaM2: Math.round(totalAreaM2 * 10) / 10,
      totalConnectedKw: Math.round(totalConnectedKw * 100) / 100,
      totalVisibleKw: Math.round(totalVisibleKw * 100) / 100,
      diversifiedPeakKw,
      wattsPerM2,
      categoryTotals,
      consumerTypeData,
      overloadedRooms,
      criticalRooms,
      hasViolations: overloadedRooms.length > 0,
    };
  }, [project, visibleLoadCategories]);

  // 3. Cross-Component Correlation Engine:
  // Maps a cost category (e.g. Outlets, Lighting, Cables, Protection) to rooms in the energy chart
  const getRoomCorrelation = (room: Room, category: string | null) => {
    if (!category) return { isMatch: false, reason: "", loadShareKw: 0 };

    const catLower = category.toLowerCase();
    const roomLoad = calculateRoomLoad(room);

    if (catLower.includes("hvac") || catLower.includes("klimat") || catLower.includes("ac") || catLower.includes("cool") || catLower.includes("heat")) {
      const isMatch = (roomLoad.breakdown.hvacKw || 0) > 0;
      return {
        isMatch,
        reason: `${roomLoad.breakdown.hvacKw} kW dedicated climate & thermal load (HVAC)`,
        loadShareKw: roomLoad.breakdown.hvacKw || 0,
      };
    }

    if (catLower.includes("outlet")) {
      const outletsCount = (room.points || []).filter((p) => p.kind === "outlet" && !isHvacPoint(p)).length;
      return {
        isMatch: outletsCount > 0 || (roomLoad.breakdown.outletsKw || 0) > 0,
        reason: `${roomLoad.breakdown.outletsKw} kW general power load (${outletsCount} receptacle${outletsCount > 1 ? "s" : ""})`,
        loadShareKw: roomLoad.breakdown.outletsKw,
      };
    }

    if (catLower.includes("light")) {
      const lightsCount = (room.points || []).filter((p) => p.kind === "light").length;
      return {
        isMatch: lightsCount > 0,
        reason: `${roomLoad.breakdown.lightsKw} kW illumination (${lightsCount} fixture${lightsCount > 1 ? "s" : ""})`,
        loadShareKw: roomLoad.breakdown.lightsKw,
      };
    }

    if (catLower.includes("switch")) {
      const switchesCount = (room.points || []).filter((p) => p.kind === "switch").length;
      return {
        isMatch: switchesCount > 0,
        reason: `${switchesCount} wall switch control${switchesCount > 1 ? "s" : ""}`,
        loadShareKw: switchesCount * 0.02,
      };
    }

    if (catLower.includes("cable") || catLower.includes("conduit")) {
      const routesCount = room.routes?.length || 0;
      const pointsCount = room.points?.length || 0;
      const isMatch = routesCount > 0 || pointsCount > 0;
      return {
        isMatch,
        reason: routesCount > 0
          ? `${routesCount} mapped cable route${routesCount > 1 ? "s" : ""}`
          : `${pointsCount} points supplied by conduit runs`,
        loadShareKw: roomLoad.totalLoadKw,
      };
    }

    if (catLower.includes("protect")) {
      const hasPanel = (room.points || []).some((p) => p.kind === "panel");
      const isOver80 = roomLoad.isOver80;
      return {
        isMatch: hasPanel || isOver80,
        reason: hasPanel
          ? "Distribution panelboard physical location"
          : isOver80
            ? "⚠️ Exceeds 80% limit — requires dedicated breaker branch"
            : "",
        loadShareKw: roomLoad.totalLoadKw,
      };
    }

    if (catLower.includes("labor")) {
      const pointsCount = room.points?.length || 0;
      return {
        isMatch: pointsCount > 0,
        reason: `${pointsCount} installation points work scope`,
        loadShareKw: roomLoad.totalLoadKw,
      };
    }

    if (catLower.includes("contingency")) {
      return {
        isMatch: roomLoad.isOver80,
        reason: roomLoad.isOver80
          ? "Thermal load buffer & reserve coverage"
          : "General electrical reserve",
        loadShareKw: roomLoad.totalLoadKw,
      };
    }

    return { isMatch: false, reason: "", loadShareKw: 0 };
  };

  const hoveredRoom = useMemo(() => {
    if (!hoveredRoomId) return null;
    return (project.rooms || []).find((r) => r.id === hoveredRoomId) || null;
  }, [hoveredRoomId, project.rooms]);

  const matchingRoomsForHoveredCategory = useMemo(() => {
    if (!hoveredCategory) return [];
    return (project.rooms || []).filter(
      (r) => getRoomCorrelation(r, hoveredCategory).isMatch
    );
  }, [hoveredCategory, project.rooms]);

  // Handle PDF Export
  const handlePdfExport = () => {
    setExportingPdf(true);
    try {
      downloadItemizedPdfReport(project);
    } finally {
      setTimeout(() => setExportingPdf(false), 800);
    }
  };

  // Recharts styling helpers
  const tooltipBg = isLight ? "#ffffff" : "#0c1a2d";
  const tooltipBorder = isLight ? "#cbd5e1" : "#1e344d";
  const tooltipText = isLight ? "#0f172a" : "#f1f6fc";
  const gridStroke = isLight ? "#e2e8f0" : "#17293d";
  const axisStroke = isLight ? "#94a3b8" : "#5a748f";

  // Data for the side-panel drill-down
  const activeDrawerData = useMemo(() => {
    if (!inspectedDrawer) return null;

    if (inspectedDrawer.type === "cost") {
      const catName = inspectedDrawer.category;
      const slice = costData.pieData.find((s) => s.name === catName);

      // Contributing items from estimates
      const matchingEstimates: EstimateItem[] = (project.estimates || []).filter((item) => {
        if (catName === "Labor") return (item.labor || 0) > 0;
        if (catName === "Contingency") return false;
        return costData.friendlyName(item.category || "") === catName;
      });

      // Contributing items from panel if Protection
      const matchingPanel: PanelDevice[] =
        catName === "Protection" ? project.panel || [] : [];

      const totalValue = slice ? slice.value : 0;
      const percentage = slice ? slice.percent : 0;

      return {
        type: "cost" as const,
        category: catName,
        totalValue,
        percentage,
        color: COST_COLORS[catName] || "#64748b",
        estimates: matchingEstimates,
        panel: matchingPanel,
        contingencyRate: project.contingency || 0,
        totals: costData.totals,
      };
    }

    if (inspectedDrawer.type === "room") {
      const room = (project.rooms || []).find((r) => r.id === inspectedDrawer.roomId);
      if (!room) return null;

      const load = calculateRoomLoad(room);
      const area = Math.round(room.length * room.width * 10) / 10;
      const operatingCurrentAmps = Math.round((load.totalLoadKw * 1000) / 230 * 10) / 10;

      return {
        type: "room" as const,
        room,
        load,
        area,
        operatingCurrentAmps,
        points: room.points || [],
        routes: room.routes || [],
      };
    }

    return null;
  }, [inspectedDrawer, project, costData]);

  return (
    <div className={`project-overview-dashboard ${compact ? "compact" : ""}`}>
      {/* Executive Command Header */}
      <div className="pod-header">
        <div className="pod-title-block">
          <div className="pod-eyebrow">
            <span className="pulse-dot" />
            <span>EXECUTIVE PROJECT OVERVIEW</span>
            <span className="pod-sep">/</span>
            <span className="font-mono text-cyan-400">PUE 7.1 & IEC 60364</span>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <h2 className="pod-main-heading">{project.name}</h2>
            {allProjects.length > 1 && onSelectProject && (
              <select
                aria-label="Switch Active Project"
                className="pod-project-selector"
                value={project.id}
                onChange={(e) => onSelectProject(e.target.value)}
              >
                {allProjects.map((p) => (
                  <option key={p.id} value={p.id}>
                    📁 {p.name} ({p.rooms?.length || 0} rooms)
                  </option>
                ))}
              </select>
            )}
          </div>
          <p className="pod-subtext">
            {project.description ||
              "Visual engineering breakdown of comprehensive cost allocation and multi-zone electrical load distribution. Hover over any chart element for linked cross-component highlighting."}
          </p>
        </div>

        {/* Action Controls & Navigation Shortcuts */}
        <div className="pod-actions">
          <div className="segmented">
            <button
              className={activeTab === "all" ? "active" : ""}
              onClick={() => setActiveTab("all")}
            >
              Overview
            </button>
            <button
              className={activeTab === "costs" ? "active" : ""}
              onClick={() => setActiveTab("costs")}
            >
              Cost Breakdown
            </button>
            <button
              className={activeTab === "energy" ? "active" : ""}
              onClick={() => setActiveTab("energy")}
            >
              Energy Load
            </button>
          </div>

          <button
            className="btn primary"
            onClick={handlePdfExport}
            disabled={exportingPdf}
            title="Export complete itemized engineering PDF dossier"
          >
            <Download size={15} />
            {exportingPdf ? "Generating PDF..." : "Export PDF"}
          </button>
        </div>
      </div>

      {/* Top Level KPI Ribbon */}
      <div className="pod-kpi-grid">
        {/* KPI 1: Total Cost */}
        <div
          className="pod-kpi-card cursor-pointer"
          onClick={() => setInspectedDrawer({ type: "cost", category: "Cables" })}
          title="Click to inspect financial breakdown"
        >
          <div className="pod-kpi-top">
            <span className="pod-kpi-label">TOTAL PROJECT BUDGET</span>
            <CircleDollarSign size={18} className="text-blue-400" />
          </div>
          <div className="pod-kpi-value font-mono">
            {formatMoney(costData.totalProjectBudget)}
          </div>
          <div className="pod-kpi-meta">
            <span>Mat: {formatMoney(costData.totals.material)}</span>
            <span aria-hidden="true">·</span>
            <span>Labor: {formatMoney(costData.totals.labor)}</span>
          </div>
        </div>

        {/* KPI 2: Connected & Peak Load */}
        <div className="pod-kpi-card">
          <div className="pod-kpi-top">
            <span className="pod-kpi-label">CONNECTED LOAD</span>
            <Zap size={18} className="text-amber-400" />
          </div>
          <div className="pod-kpi-value font-mono">
            {energyData.totalConnectedKw} <small className="text-sm font-sans">kW</small>
          </div>
          <div className="pod-kpi-meta">
            <span>Diversified Peak: {energyData.diversifiedPeakKw} kW</span>
            <span aria-hidden="true">·</span>
            <span>{energyData.wattsPerM2} W/m²</span>
          </div>
        </div>

        {/* KPI 3: 80% Capacity Threshold Compliance */}
        <div
          className={`pod-kpi-card ${
            energyData.hasViolations ? "cursor-pointer" : ""
          }`}
          onClick={() => {
            if (energyData.overloadedRooms.length > 0) {
              setInspectedDrawer({
                type: "room",
                roomId: energyData.overloadedRooms[0].id,
              });
            }
          }}
          title={
            energyData.hasViolations
              ? "Click to inspect the first overloaded room"
              : undefined
          }
        >
          <div className="pod-kpi-top">
            <span className="pod-kpi-label">80% LOAD SAFETY (PUE 7.1)</span>
            {energyData.hasViolations ? (
              <AlertTriangle size={18} className="text-amber-400" />
            ) : (
              <ShieldCheck size={18} className="text-emerald-400" />
            )}
          </div>
          <div
            className={`pod-kpi-value font-mono ${
              energyData.hasViolations ? "text-amber-400" : "text-emerald-400"
            }`}
          >
            {energyData.hasViolations
              ? `${energyData.overloadedRooms.length} Warning`
              : "100% Compliant"}
          </div>
          <div className="pod-kpi-meta">
            {energyData.hasViolations ? (
              <span className="text-amber-300">
                {energyData.overloadedRooms.map((r) => r.roomName).join(", ")} exceed 80%
              </span>
            ) : (
              <span>All {project.rooms?.length || 0} rooms stay within continuous duty</span>
            )}
          </div>
        </div>

        {/* KPI 4: Infrastructure Scope */}
        <div className="pod-kpi-card">
          <div className="pod-kpi-top">
            <span className="pod-kpi-label">INFRASTRUCTURE SCOPE</span>
            <Layers size={18} className="text-cyan-400" />
          </div>
          <div className="pod-kpi-value font-mono">
            {project.rooms?.length || 0} <small className="text-sm font-sans">rooms</small>
          </div>
          <div className="pod-kpi-meta">
            <span>{energyData.totalAreaM2} m² area</span>
            <span aria-hidden="true">·</span>
            <span>{project.panel?.length || 0} panel modules</span>
          </div>
        </div>
      </div>

      {/* Main Charts & Visualizations Section */}
      <div className="pod-visuals-grid">
        {/* SECTION A: Visual Breakdown of Project Costs */}
        {(activeTab === "all" || activeTab === "costs") && (
          <div className="pod-chart-panel">
            <div className="pod-chart-header">
              <div>
                <span className="pod-chart-tag">FINANCIAL ARCHITECTURE</span>
                <h3 className="pod-chart-title">Cost Breakdown by Category</h3>
              </div>
              <div className="flex items-center gap-2">
                {hoveredRoom ? (
                  <span className="font-mono text-[11px] text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/60 animate-fadeIn">
                    🔗 Correlated with: {hoveredRoom.name}
                  </span>
                ) : (
                  <span className="font-mono text-[11px] text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                    Hover slice to cross-highlight rooms
                  </span>
                )}
              </div>
            </div>

            <div className="pod-chart-body">
              {costData.pieData.length > 0 ? (
                <div className="pod-donut-wrapper">
                  <div className="h-[280px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Tooltip
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload;
                              const matchingCount = (project.rooms || []).filter(
                                (r) => getRoomCorrelation(r, data.name).isMatch
                              ).length;

                              return (
                                <div
                                  className="pod-custom-tooltip font-mono text-xs"
                                  style={{
                                    backgroundColor: tooltipBg,
                                    borderColor: tooltipBorder,
                                    color: tooltipText,
                                  }}
                                >
                                  <div className="font-sans font-semibold text-sm mb-1 flex items-center gap-2">
                                    <span
                                      className="inline-block w-2.5 h-2.5 rounded-full"
                                      style={{ backgroundColor: data.color }}
                                    />
                                    {data.name}
                                  </div>
                                  <div>Amount: {formatMoney(data.value)}</div>
                                  <div className="text-slate-400">
                                    Share of Budget: {data.percent.toFixed(1)}%
                                  </div>
                                  <div className="mt-1.5 pt-1 border-t border-slate-700/50 text-[11px] text-cyan-300 flex items-center gap-1.5">
                                    <Sparkles size={11} className="text-cyan-400" />
                                    <span>
                                      Cross-highlights {matchingCount} room{matchingCount !== 1 ? "s" : ""} in load chart
                                    </span>
                                  </div>
                                  <div className="text-[10px] text-slate-400 mt-0.5">
                                    👉 Click slice to inspect itemized lines
                                  </div>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Pie
                          data={costData.pieData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={65}
                          outerRadius={95}
                          paddingAngle={3}
                          stroke={isLight ? "#ffffff" : "#0a1829"}
                          strokeWidth={2}
                          onMouseEnter={(_, index) => {
                            const entry = costData.pieData[index];
                            if (entry) setHoveredCategory(entry.name);
                          }}
                          onMouseLeave={() => setHoveredCategory(null)}
                          onClick={(entry) => {
                            if (entry && entry.name) {
                              setInspectedDrawer({
                                type: "cost",
                                category: entry.name,
                              });
                            }
                          }}
                        >
                          {costData.pieData.map((entry, index) => {
                            // Cross-component opacity calculation
                            let cellOpacity = 1;
                            let strokeColor = isLight ? "#ffffff" : "#0a1829";
                            let strokeWidth = 2;

                            if (hoveredCategory) {
                              if (hoveredCategory === entry.name) {
                                cellOpacity = 1;
                                strokeColor = "#ffffff";
                                strokeWidth = 3;
                              } else {
                                cellOpacity = 0.22;
                              }
                            } else if (hoveredRoom) {
                              const correlation = getRoomCorrelation(hoveredRoom, entry.name);
                              if (correlation.isMatch) {
                                cellOpacity = 1;
                                strokeColor = "#ffffff";
                                strokeWidth = 3;
                              } else {
                                cellOpacity = 0.22;
                              }
                            }

                            return (
                              <Cell
                                key={`cell-${index}`}
                                fill={entry.color}
                                opacity={cellOpacity}
                                stroke={strokeColor}
                                strokeWidth={strokeWidth}
                                cursor="pointer"
                                className="cursor-pointer transition-all duration-200"
                                onMouseEnter={() => setHoveredCategory(entry.name)}
                                onMouseLeave={() => setHoveredCategory(null)}
                              />
                            );
                          })}
                        </Pie>
                        <Legend
                          verticalAlign="bottom"
                          height={36}
                          onMouseEnter={(entry: any) => {
                            if (entry && entry.value) setHoveredCategory(entry.value);
                          }}
                          onMouseLeave={() => setHoveredCategory(null)}
                          formatter={(value, entry: any) => {
                            const isHovered = hoveredCategory === value;
                            return (
                              <span
                                className={`text-xs font-sans cursor-pointer transition-all ${
                                  isHovered
                                    ? "text-cyan-300 font-bold underline"
                                    : hoveredCategory
                                      ? "text-slate-500 opacity-60"
                                      : "text-slate-300 hover:text-cyan-400"
                                }`}
                                onMouseEnter={() => setHoveredCategory(value)}
                                onMouseLeave={() => setHoveredCategory(null)}
                                onClick={() =>
                                  setInspectedDrawer({
                                    type: "cost",
                                    category: value,
                                  })
                                }
                              >
                                {value} ({entry.payload.percent.toFixed(0)}%)
                              </span>
                            );
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Summary Bar for Material vs Labor vs Protection */}
                  <div className="pod-cost-bars-summary">
                    <div className="text-xs font-mono text-slate-400 mb-2 flex justify-between">
                      <span>BUDGET COMPOSITION</span>
                      <span>
                        {hoveredCategory
                          ? `HIGHLIGHTING ${hoveredCategory.toUpperCase()}`
                          : "HOVER SLICE TO HIGHLIGHT LOAD BARS"}
                      </span>
                    </div>
                    <div className="pod-stacked-bar-track">
                      {costData.pieData.map((item, idx) => {
                        const isHovered = hoveredCategory === item.name;
                        return (
                          <div
                            key={idx}
                            className={`pod-stacked-bar-fill cursor-pointer transition-all duration-200 ${
                              isHovered
                                ? "brightness-150 ring-2 ring-white z-10 scale-y-125"
                                : hoveredCategory
                                  ? "opacity-30"
                                  : "hover:brightness-125"
                            }`}
                            style={{
                              width: `${item.percent}%`,
                              backgroundColor: item.color,
                            }}
                            onMouseEnter={() => setHoveredCategory(item.name)}
                            onMouseLeave={() => setHoveredCategory(null)}
                            onClick={() =>
                              setInspectedDrawer({
                                type: "cost",
                                category: item.name,
                              })
                            }
                            title={`${item.name}: ${formatMoney(item.value)} (${item.percent.toFixed(1)}%) — Hover to cross-highlight rooms`}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="pod-empty-chart">
                  <CircleDollarSign size={32} className="text-slate-600 mb-2" />
                  <p className="text-sm font-medium">No material estimates added yet</p>
                  <Link href="/estimator" className="text-xs text-blue-400 hover:underline">
                    Add bill of materials in Material Estimator →
                  </Link>
                </div>
              )}

              {/* Top Cost Drivers List */}
              {costData.topItems.length > 0 && (
                <div className="pod-sub-table">
                  <div className="pod-sub-table-title flex justify-between items-center">
                    <span>Top Cost Drivers</span>
                    <span className="text-[10px] text-slate-400">Hover row to filter</span>
                  </div>
                  <div className="pod-sub-table-list">
                    {costData.topItems.map((item) => {
                      const standardCat = costData.friendlyName(item.category || "");
                      const isHovered = hoveredCategory === standardCat;

                      return (
                        <div
                          key={item.id}
                          className={`pod-sub-table-row cursor-pointer transition-colors ${
                            isHovered
                              ? "bg-cyan-950/40 border-cyan-800/60"
                              : hoveredCategory
                                ? "opacity-50"
                                : "hover:bg-slate-800/40"
                          }`}
                          onMouseEnter={() => setHoveredCategory(standardCat)}
                          onMouseLeave={() => setHoveredCategory(null)}
                          onClick={() =>
                            setInspectedDrawer({
                              type: "cost",
                              category: standardCat,
                            })
                          }
                        >
                          <div className="truncate pr-2">
                            <strong className="block text-xs truncate hover:text-cyan-400 transition-colors">
                              {item.name}
                            </strong>
                            <span className="text-[11px] text-slate-400">
                              {item.quantity} {item.unit} · {item.category}
                            </span>
                          </div>
                          <div className="text-right font-mono text-xs whitespace-nowrap">
                            <span>{formatMoney(item.total)}</span>
                            <span className="block text-[10px] text-slate-400">
                              {item.share.toFixed(1)}% of total
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SECTION B: Visual Breakdown of Energy Load Distribution */}
        {(activeTab === "all" || activeTab === "energy") && (
          <div className="pod-chart-panel">
            <div className="pod-chart-header">
              <div>
                <span className="pod-chart-tag">ELECTRICAL CAPACITY AUDIT</span>
                <h3 className="pod-chart-title">Room Load Distribution vs 80% Safety Ceiling</h3>
              </div>
              <div className="flex items-center gap-2">
                {hoveredCategory ? (
                  <span className="font-mono text-[11px] text-cyan-300 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/60 animate-fadeIn">
                    🔗 Cross-Filtering: {hoveredCategory}
                  </span>
                ) : (
                  <span className="font-mono text-[11px] text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40">
                    PUE 7.1 / NEC 210.19 Benchmarks
                  </span>
                )}
              </div>
            </div>

            <div className="pod-chart-body">
              {/* Dynamic Cross-Highlight Notification Banner */}
              {hoveredCategory && (
                <div className="pod-cross-highlight-strip animate-fadeIn">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full flex-none animate-pulse"
                      style={{ backgroundColor: COST_COLORS[hoveredCategory] || "#3b8cff" }}
                    />
                    <span className="text-xs text-slate-200">
                      Cross-filtering for <strong>{hoveredCategory}</strong>:{" "}
                      <span className="text-cyan-300 font-mono font-semibold">
                        {matchingRoomsForHoveredCategory.length} of {project.rooms?.length || 0} room
                        {matchingRoomsForHoveredCategory.length !== 1 ? "s" : ""} highlighted below
                      </span>
                    </span>
                  </div>
                  <button
                    className="text-[11px] text-slate-400 hover:text-slate-100 underline font-mono"
                    onClick={() => setHoveredCategory(null)}
                  >
                    Clear
                  </button>
                </div>
              )}

              {energyData.roomMetrics.length > 0 ? (
                <>
                  {/* Interactive Legend Toggle Control Strip */}
                  <div className="pod-legend-toggle-container">
                    <div className="pod-legend-toggle-header">
                      <div className="flex items-center gap-2">
                        <Filter size={13} className="text-cyan-400" />
                        <span className="text-[11px] font-mono font-semibold tracking-wider text-slate-300 uppercase">
                          Load Category Filters
                        </span>
                        {Object.values(visibleLoadCategories).filter((v) => !v).length > 0 && (
                          <span className="text-[10px] font-mono text-amber-300 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/50">
                            {Object.values(visibleLoadCategories).filter((v) => !v).length} hidden
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 flex-wrap">
                        {/* Quick Filter Presets */}
                        <button
                          type="button"
                          className={`pod-pill-btn ${
                            visibleLoadCategories.outlets &&
                            visibleLoadCategories.hvac &&
                            visibleLoadCategories.lighting &&
                            visibleLoadCategories.auxiliary &&
                            visibleLoadCategories.threshold
                              ? "active"
                              : ""
                          }`}
                          onClick={showAllLoadCategories}
                          title="Show all load categories"
                        >
                          All
                        </button>
                        <button
                          type="button"
                          className={`pod-pill-btn ${
                            visibleLoadCategories.outlets &&
                            !visibleLoadCategories.hvac &&
                            !visibleLoadCategories.lighting &&
                            !visibleLoadCategories.auxiliary
                              ? "active"
                              : ""
                          }`}
                          onClick={() =>
                            setVisibleLoadCategories({
                              outlets: true,
                              hvac: false,
                              lighting: false,
                              auxiliary: false,
                              threshold: visibleLoadCategories.threshold,
                            })
                          }
                          title="Show only outlets & appliances"
                        >
                          Outlets
                        </button>
                        <button
                          type="button"
                          className={`pod-pill-btn ${
                            visibleLoadCategories.hvac &&
                            !visibleLoadCategories.outlets &&
                            !visibleLoadCategories.lighting &&
                            !visibleLoadCategories.auxiliary
                              ? "active"
                              : ""
                          }`}
                          onClick={() =>
                            setVisibleLoadCategories({
                              outlets: false,
                              hvac: true,
                              lighting: false,
                              auxiliary: false,
                              threshold: visibleLoadCategories.threshold,
                            })
                          }
                          title="Show only HVAC & climate control loads"
                        >
                          HVAC
                        </button>
                        <button
                          type="button"
                          className={`pod-pill-btn ${
                            visibleLoadCategories.lighting &&
                            !visibleLoadCategories.outlets &&
                            !visibleLoadCategories.hvac &&
                            !visibleLoadCategories.auxiliary
                              ? "active"
                              : ""
                          }`}
                          onClick={() =>
                            setVisibleLoadCategories({
                              outlets: false,
                              hvac: false,
                              lighting: true,
                              auxiliary: false,
                              threshold: visibleLoadCategories.threshold,
                            })
                          }
                          title="Show only lighting loads"
                        >
                          Lighting
                        </button>

                        <div className="h-3 w-px bg-slate-700/60 mx-1 hidden sm:block" />

                        {/* Chart Breakdown Mode */}
                        <button
                          type="button"
                          className={`pod-pill-btn ${loadChartMode === "stacked" ? "active" : ""}`}
                          onClick={() => setLoadChartMode("stacked")}
                          title="View segmented load category breakdown for each room"
                        >
                          Stacked
                        </button>
                        <button
                          type="button"
                          className={`pod-pill-btn ${loadChartMode === "total" ? "active" : ""}`}
                          onClick={() => setLoadChartMode("total")}
                          title="View single combined active load bar"
                        >
                          Total
                        </button>
                      </div>
                    </div>

                    {/* Interactive Legend Toggle Chips */}
                    <div className="pod-legend-chips-grid">
                      {LOAD_CATEGORIES.map((cat) => {
                        const isVisible = visibleLoadCategories[cat.key];
                        const kw = energyData.categoryTotals[cat.key] || 0;

                        return (
                          <button
                            key={cat.key}
                            type="button"
                            className={`pod-legend-chip ${isVisible ? "active" : "inactive"}`}
                            onClick={(e) => {
                              if (e.altKey) {
                                // Alt+Click isolates this single category
                                setVisibleLoadCategories({
                                  outlets: cat.key === "outlets",
                                  hvac: cat.key === "hvac",
                                  lighting: cat.key === "lighting",
                                  auxiliary: cat.key === "auxiliary",
                                  threshold:
                                    cat.key === "threshold" ? true : visibleLoadCategories.threshold,
                                });
                              } else {
                                toggleLoadCategory(cat.key);
                              }
                            }}
                            title={`${isVisible ? "Click to hide" : "Click to show"} ${cat.label} (Alt+Click to isolate)`}
                          >
                            <span
                              className="pod-chip-checkbox"
                              style={{
                                backgroundColor: isVisible ? cat.color : "transparent",
                                borderColor: cat.color,
                              }}
                            >
                              {isVisible ? <Check size={10} className="text-slate-900 stroke-[3]" /> : null}
                            </span>
                            <span className="pod-chip-label">{cat.shortLabel}</span>
                            <span className="pod-chip-kw font-mono">
                              {kw > 0 ? `${kw.toFixed(1)} kW` : "0 kW"}
                            </span>
                            <span className="pod-chip-eye">
                              {isVisible ? (
                                <Eye size={12} className="text-slate-400" />
                              ) : (
                                <EyeOff size={12} className="text-slate-500" />
                              )}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Empty State when all categories are toggled off */}
                  {!visibleLoadCategories.outlets &&
                  !visibleLoadCategories.hvac &&
                  !visibleLoadCategories.lighting &&
                  !visibleLoadCategories.auxiliary &&
                  !visibleLoadCategories.threshold ? (
                    <div className="py-12 text-center text-xs text-slate-400 bg-slate-900/30 rounded-lg border border-slate-800 my-4">
                      <Filter size={24} className="mx-auto mb-2 text-slate-500" />
                      <p className="font-semibold text-slate-200">All load categories are currently hidden</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Click any category in the legend toggle above to show its load.
                      </p>
                      <button
                        type="button"
                        className="btn sm outline mt-3 font-mono text-xs inline-flex items-center gap-1.5"
                        onClick={showAllLoadCategories}
                      >
                        <RotateCcw size={13} /> Restore All Categories
                      </button>
                    </div>
                  ) : (
                    <div className="h-[280px] w-full mt-2">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={energyData.roomMetrics}
                          margin={{ top: 15, right: 15, left: -10, bottom: 25 }}
                          onMouseLeave={() => setHoveredRoomId(null)}
                          onClick={(state: any) => {
                            if (state && state.activePayload && state.activePayload[0]) {
                              const data = state.activePayload[0].payload;
                              if (data && data.id) {
                                setInspectedDrawer({
                                  type: "room",
                                  roomId: data.id,
                                });
                              }
                            }
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" stroke={gridStroke} />
                          <XAxis
                            dataKey="roomName"
                            stroke={axisStroke}
                            fontSize={11}
                            tickLine={false}
                            angle={-15}
                            textAnchor="end"
                            interval={0}
                          />
                          <YAxis
                            stroke={axisStroke}
                            fontSize={11}
                            tickLine={false}
                            unit=" kW"
                          />
                          <Tooltip
                            content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const data = payload[0].payload;
                                const room = (project.rooms || []).find((r) => r.id === data.id);
                                const correlation = room
                                  ? getRoomCorrelation(room, hoveredCategory)
                                  : { isMatch: false, reason: "" };

                                const activeHiddenCount = [
                                  !visibleLoadCategories.outlets,
                                  !visibleLoadCategories.hvac,
                                  !visibleLoadCategories.lighting,
                                  !visibleLoadCategories.auxiliary,
                                ].filter(Boolean).length;

                                return (
                                  <div
                                    className="pod-custom-tooltip font-mono text-xs"
                                    style={{
                                      backgroundColor: tooltipBg,
                                      borderColor: tooltipBorder,
                                      color: tooltipText,
                                    }}
                                  >
                                    <div className="font-sans font-semibold text-sm mb-1 flex items-center justify-between gap-3">
                                      <span>
                                        {data.roomName} ({data.areaM2} m²)
                                      </span>
                                      <span
                                        className="text-[10px] font-mono px-1.5 py-0.5 rounded"
                                        style={{
                                          backgroundColor: `${data.fillColor}25`,
                                          color: data.fillColor,
                                        }}
                                      >
                                        {data.status.toUpperCase()}
                                      </span>
                                    </div>

                                    <div className="flex justify-between gap-4">
                                      <span>Visible Active Load:</span>
                                      <strong className="text-amber-400">
                                        {data.visibleLoadKw} kW
                                      </strong>
                                    </div>

                                    {activeHiddenCount > 0 && (
                                      <div className="flex justify-between gap-4 text-slate-400 text-[11px]">
                                        <span>Total Full Load:</span>
                                        <span>{data.connectedLoadKw} kW</span>
                                      </div>
                                    )}

                                    {visibleLoadCategories.threshold && (
                                      <div className="flex justify-between gap-4 text-slate-400">
                                        <span>80% Safety Ceiling:</span>
                                        <span>{data.safeThresholdKw} kW</span>
                                      </div>
                                    )}

                                    <div className="flex justify-between gap-4 text-slate-400">
                                      <span>Breaker Rating:</span>
                                      <span>{data.maxCapacityKw} kW</span>
                                    </div>

                                    {/* Itemized Categories in Tooltip */}
                                    <div className="mt-2 pt-1.5 border-t border-slate-700/50 space-y-0.5">
                                      <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider mb-1">
                                        Active Category Breakdown:
                                      </div>
                                      <div
                                        className={`flex justify-between text-[11px] ${
                                          visibleLoadCategories.outlets
                                            ? "text-cyan-300"
                                            : "text-slate-500 line-through opacity-60"
                                        }`}
                                      >
                                        <span>🔌 Outlets:</span>
                                        <span>
                                          {data.outletsKw} kW{" "}
                                          {!visibleLoadCategories.outlets ? "(hidden)" : ""}
                                        </span>
                                      </div>
                                      <div
                                        className={`flex justify-between text-[11px] ${
                                          visibleLoadCategories.hvac
                                            ? "text-orange-300"
                                            : "text-slate-500 line-through opacity-60"
                                        }`}
                                      >
                                        <span>❄️ HVAC & Climate:</span>
                                        <span>
                                          {data.hvacKw} kW{" "}
                                          {!visibleLoadCategories.hvac ? "(hidden)" : ""}
                                        </span>
                                      </div>
                                      <div
                                        className={`flex justify-between text-[11px] ${
                                          visibleLoadCategories.lighting
                                            ? "text-indigo-300"
                                            : "text-slate-500 line-through opacity-60"
                                        }`}
                                      >
                                        <span>💡 Lighting:</span>
                                        <span>
                                          {data.lightsKw} kW{" "}
                                          {!visibleLoadCategories.lighting ? "(hidden)" : ""}
                                        </span>
                                      </div>
                                      <div
                                        className={`flex justify-between text-[11px] ${
                                          visibleLoadCategories.auxiliary
                                            ? "text-emerald-300"
                                            : "text-slate-500 line-through opacity-60"
                                        }`}
                                      >
                                        <span>⚡ Auxiliary:</span>
                                        <span>
                                          {data.otherKw} kW{" "}
                                          {!visibleLoadCategories.auxiliary ? "(hidden)" : ""}
                                        </span>
                                      </div>
                                    </div>

                                    {/* Cross-component highlight detail */}
                                    {hoveredCategory && (
                                      <div
                                        className={`mt-2 pt-1.5 border-t text-[11px] font-mono ${
                                          correlation.isMatch
                                            ? "border-cyan-500/40 text-cyan-300 bg-cyan-950/40 p-1.5 rounded"
                                            : "border-slate-800 text-slate-500"
                                        }`}
                                      >
                                        <div className="font-bold flex items-center gap-1">
                                          <span
                                            className="w-1.5 h-1.5 rounded-full inline-block"
                                            style={{
                                              backgroundColor:
                                                COST_COLORS[hoveredCategory] || "#3b8cff",
                                            }}
                                          />
                                          <span>{hoveredCategory} Contribution:</span>
                                        </div>
                                        <div>
                                          {correlation.isMatch
                                            ? correlation.reason
                                            : "No direct load allocated from this category"}
                                        </div>
                                      </div>
                                    )}

                                    <div className="mt-1.5 pt-1 border-t border-slate-700/40 text-[10px] text-amber-400">
                                      👉 Click bar to inspect contributing electrical points
                                    </div>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          <Legend
                            verticalAlign="top"
                            height={30}
                            onClick={(entry: any) => {
                              if (!entry) return;
                              const name = (entry.value || "").toLowerCase();
                              if (name.includes("outlet")) toggleLoadCategory("outlets");
                              else if (name.includes("hvac") || name.includes("climate"))
                                toggleLoadCategory("hvac");
                              else if (name.includes("light")) toggleLoadCategory("lighting");
                              else if (name.includes("aux") || name.includes("fixed"))
                                toggleLoadCategory("auxiliary");
                              else if (name.includes("safe") || name.includes("80%"))
                                toggleLoadCategory("threshold");
                            }}
                            formatter={(value) => {
                              const name = (value || "").toLowerCase();
                              let isCatVisible = true;
                              if (name.includes("outlet")) isCatVisible = visibleLoadCategories.outlets;
                              else if (name.includes("hvac") || name.includes("climate"))
                                isCatVisible = visibleLoadCategories.hvac;
                              else if (name.includes("light"))
                                isCatVisible = visibleLoadCategories.lighting;
                              else if (name.includes("aux") || name.includes("fixed"))
                                isCatVisible = visibleLoadCategories.auxiliary;
                              else if (name.includes("safe") || name.includes("80%"))
                                isCatVisible = visibleLoadCategories.threshold;

                              return (
                                <span
                                  className={`text-xs font-sans cursor-pointer transition-all ${
                                    isCatVisible
                                      ? "text-slate-200 hover:text-white"
                                      : "text-slate-500 line-through opacity-45"
                                  }`}
                                  title={`${isCatVisible ? "Click to hide" : "Click to show"} ${value}`}
                                >
                                  {value}
                                </span>
                              );
                            }}
                          />

                          {/* Render Stacked Segments vs Consolidated Bar */}
                          {loadChartMode === "stacked" ? (
                            <>
                              {visibleLoadCategories.outlets && (
                                <Bar
                                  dataKey="displayOutletsKw"
                                  name="Outlets & Appliances"
                                  stackId="load"
                                  fill="#4bc8dc"
                                  radius={[0, 0, 0, 0]}
                                  onMouseEnter={(entry: any) => {
                                    if (entry && entry.id) setHoveredRoomId(entry.id);
                                  }}
                                  onMouseLeave={() => setHoveredRoomId(null)}
                                  onClick={(entry) => {
                                    if (entry && entry.id) {
                                      setInspectedDrawer({
                                        type: "room",
                                        roomId: entry.id,
                                      });
                                    }
                                  }}
                                >
                                  {energyData.roomMetrics.map((entry, index) => {
                                    const room = (project.rooms || []).find((r) => r.id === entry.id);
                                    const correlation = room
                                      ? getRoomCorrelation(room, hoveredCategory)
                                      : { isMatch: false, reason: "" };

                                    let cellOpacity = 1;
                                    let strokeColor = "transparent";
                                    let strokeWidth = 0;

                                    if (hoveredCategory) {
                                      if (correlation.isMatch) {
                                        cellOpacity = 1;
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2.5;
                                      } else {
                                        cellOpacity = 0.22;
                                      }
                                    } else if (hoveredRoomId) {
                                      cellOpacity = hoveredRoomId === entry.id ? 1 : 0.35;
                                      if (hoveredRoomId === entry.id) {
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2;
                                      }
                                    }

                                    return (
                                      <Cell
                                        key={`bar-outlets-${index}`}
                                        fill="#4bc8dc"
                                        opacity={cellOpacity}
                                        stroke={strokeColor}
                                        strokeWidth={strokeWidth}
                                        cursor="pointer"
                                        className="cursor-pointer transition-all duration-200"
                                        onMouseEnter={() => setHoveredRoomId(entry.id)}
                                        onMouseLeave={() => setHoveredRoomId(null)}
                                      />
                                    );
                                  })}
                                </Bar>
                              )}

                              {visibleLoadCategories.hvac && (
                                <Bar
                                  dataKey="displayHvacKw"
                                  name="HVAC & Climate"
                                  stackId="load"
                                  fill="#fb923c"
                                  radius={[0, 0, 0, 0]}
                                  onMouseEnter={(entry: any) => {
                                    if (entry && entry.id) setHoveredRoomId(entry.id);
                                  }}
                                  onMouseLeave={() => setHoveredRoomId(null)}
                                  onClick={(entry) => {
                                    if (entry && entry.id) {
                                      setInspectedDrawer({
                                        type: "room",
                                        roomId: entry.id,
                                      });
                                    }
                                  }}
                                >
                                  {energyData.roomMetrics.map((entry, index) => {
                                    const room = (project.rooms || []).find((r) => r.id === entry.id);
                                    const correlation = room
                                      ? getRoomCorrelation(room, hoveredCategory)
                                      : { isMatch: false, reason: "" };

                                    let cellOpacity = 1;
                                    let strokeColor = "transparent";
                                    let strokeWidth = 0;

                                    if (hoveredCategory) {
                                      if (correlation.isMatch) {
                                        cellOpacity = 1;
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2.5;
                                      } else {
                                        cellOpacity = 0.22;
                                      }
                                    } else if (hoveredRoomId) {
                                      cellOpacity = hoveredRoomId === entry.id ? 1 : 0.35;
                                      if (hoveredRoomId === entry.id) {
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2;
                                      }
                                    }

                                    return (
                                      <Cell
                                        key={`bar-hvac-${index}`}
                                        fill="#fb923c"
                                        opacity={cellOpacity}
                                        stroke={strokeColor}
                                        strokeWidth={strokeWidth}
                                        cursor="pointer"
                                        className="cursor-pointer transition-all duration-200"
                                        onMouseEnter={() => setHoveredRoomId(entry.id)}
                                        onMouseLeave={() => setHoveredRoomId(null)}
                                      />
                                    );
                                  })}
                                </Bar>
                              )}

                              {visibleLoadCategories.lighting && (
                                <Bar
                                  dataKey="displayLightsKw"
                                  name="Lighting"
                                  stackId="load"
                                  fill="#818cf8"
                                  radius={[0, 0, 0, 0]}
                                  onMouseEnter={(entry: any) => {
                                    if (entry && entry.id) setHoveredRoomId(entry.id);
                                  }}
                                  onMouseLeave={() => setHoveredRoomId(null)}
                                  onClick={(entry) => {
                                    if (entry && entry.id) {
                                      setInspectedDrawer({
                                        type: "room",
                                        roomId: entry.id,
                                      });
                                    }
                                  }}
                                >
                                  {energyData.roomMetrics.map((entry, index) => {
                                    const room = (project.rooms || []).find((r) => r.id === entry.id);
                                    const correlation = room
                                      ? getRoomCorrelation(room, hoveredCategory)
                                      : { isMatch: false, reason: "" };

                                    let cellOpacity = 1;
                                    let strokeColor = "transparent";
                                    let strokeWidth = 0;

                                    if (hoveredCategory) {
                                      if (correlation.isMatch) {
                                        cellOpacity = 1;
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2.5;
                                      } else {
                                        cellOpacity = 0.22;
                                      }
                                    } else if (hoveredRoomId) {
                                      cellOpacity = hoveredRoomId === entry.id ? 1 : 0.35;
                                      if (hoveredRoomId === entry.id) {
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2;
                                      }
                                    }

                                    return (
                                      <Cell
                                        key={`bar-lights-${index}`}
                                        fill="#818cf8"
                                        opacity={cellOpacity}
                                        stroke={strokeColor}
                                        strokeWidth={strokeWidth}
                                        cursor="pointer"
                                        className="cursor-pointer transition-all duration-200"
                                        onMouseEnter={() => setHoveredRoomId(entry.id)}
                                        onMouseLeave={() => setHoveredRoomId(null)}
                                      />
                                    );
                                  })}
                                </Bar>
                              )}

                              {visibleLoadCategories.auxiliary && (
                                <Bar
                                  dataKey="displayOtherKw"
                                  name="Auxiliary & Fixed"
                                  stackId="load"
                                  fill="#37c99b"
                                  radius={[4, 4, 0, 0]}
                                  onMouseEnter={(entry: any) => {
                                    if (entry && entry.id) setHoveredRoomId(entry.id);
                                  }}
                                  onMouseLeave={() => setHoveredRoomId(null)}
                                  onClick={(entry) => {
                                    if (entry && entry.id) {
                                      setInspectedDrawer({
                                        type: "room",
                                        roomId: entry.id,
                                      });
                                    }
                                  }}
                                >
                                  {energyData.roomMetrics.map((entry, index) => {
                                    const room = (project.rooms || []).find((r) => r.id === entry.id);
                                    const correlation = room
                                      ? getRoomCorrelation(room, hoveredCategory)
                                      : { isMatch: false, reason: "" };

                                    let cellOpacity = 1;
                                    let strokeColor = "transparent";
                                    let strokeWidth = 0;

                                    if (hoveredCategory) {
                                      if (correlation.isMatch) {
                                        cellOpacity = 1;
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2.5;
                                      } else {
                                        cellOpacity = 0.22;
                                      }
                                    } else if (hoveredRoomId) {
                                      cellOpacity = hoveredRoomId === entry.id ? 1 : 0.35;
                                      if (hoveredRoomId === entry.id) {
                                        strokeColor = "#ffffff";
                                        strokeWidth = 2;
                                      }
                                    }

                                    return (
                                      <Cell
                                        key={`bar-other-${index}`}
                                        fill="#37c99b"
                                        opacity={cellOpacity}
                                        stroke={strokeColor}
                                        strokeWidth={strokeWidth}
                                        cursor="pointer"
                                        className="cursor-pointer transition-all duration-200"
                                        onMouseEnter={() => setHoveredRoomId(entry.id)}
                                        onMouseLeave={() => setHoveredRoomId(null)}
                                      />
                                    );
                                  })}
                                </Bar>
                              )}
                            </>
                          ) : (
                            /* Consolidated Total Active Bar Mode */
                            <Bar
                              dataKey="visibleLoadKw"
                              name="Visible Active Load"
                              radius={[4, 4, 0, 0]}
                              onMouseEnter={(entry: any) => {
                                if (entry && entry.id) setHoveredRoomId(entry.id);
                              }}
                              onMouseLeave={() => setHoveredRoomId(null)}
                              onClick={(entry) => {
                                if (entry && entry.id) {
                                  setInspectedDrawer({
                                    type: "room",
                                    roomId: entry.id,
                                  });
                                }
                              }}
                            >
                              {energyData.roomMetrics.map((entry, index) => {
                                const room = (project.rooms || []).find((r) => r.id === entry.id);
                                const correlation = room
                                  ? getRoomCorrelation(room, hoveredCategory)
                                  : { isMatch: false, reason: "" };

                                let cellOpacity = 1;
                                let strokeColor = "transparent";
                                let strokeWidth = 0;

                                if (hoveredCategory) {
                                  if (correlation.isMatch) {
                                    cellOpacity = 1;
                                    strokeColor = "#ffffff";
                                    strokeWidth = 2.5;
                                  } else {
                                    cellOpacity = 0.22;
                                  }
                                } else if (hoveredRoomId) {
                                  cellOpacity = hoveredRoomId === entry.id ? 1 : 0.35;
                                  if (hoveredRoomId === entry.id) {
                                    strokeColor = "#ffffff";
                                    strokeWidth = 2;
                                  }
                                }

                                return (
                                  <Cell
                                    key={`bar-total-${index}`}
                                    fill={entry.fillColor}
                                    opacity={cellOpacity}
                                    stroke={strokeColor}
                                    strokeWidth={strokeWidth}
                                    cursor="pointer"
                                    className="cursor-pointer transition-all duration-200"
                                    onMouseEnter={() => setHoveredRoomId(entry.id)}
                                    onMouseLeave={() => setHoveredRoomId(null)}
                                  />
                                );
                              })}
                            </Bar>
                          )}

                          {/* 80% Safety Ceiling Reference Bar */}
                          {visibleLoadCategories.threshold && (
                            <Bar
                              dataKey="safeThresholdKw"
                              name="80% Safety Ceiling"
                              radius={[4, 4, 0, 0]}
                            >
                              {energyData.roomMetrics.map((entry, index) => {
                                const room = (project.rooms || []).find((r) => r.id === entry.id);
                                const correlation = room
                                  ? getRoomCorrelation(room, hoveredCategory)
                                  : { isMatch: false };
                                const barOpacity = hoveredCategory
                                  ? correlation.isMatch
                                    ? 0.45
                                    : 0.08
                                  : 0.35;

                                return (
                                  <Cell
                                    key={`safe-bar-${index}`}
                                    fill="#64748b"
                                    opacity={barOpacity}
                                    className="transition-all duration-200"
                                  />
                                );
                              })}
                            </Bar>
                          )}
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  )}

                  {/* Room Compliance Callouts */}
                  <div className="pod-compliance-list">
                    {energyData.hasViolations ? (
                      <div className="pod-warning-banner">
                        <div className="flex items-start gap-2">
                          <AlertTriangle size={17} className="text-amber-400 flex-none mt-0.5" />
                          <div>
                            <strong className="text-xs text-amber-300 block">
                              Continuous Duty Overload Warning
                            </strong>
                            <p className="text-[11px] text-amber-200/80 m-0 mt-0.5">
                              {energyData.overloadedRooms
                                .map(
                                  (r) =>
                                    `${r.roomName} (${r.ratioPercent.toFixed(1)}% of ${r.maxCapacityKw} kW)`
                                )
                                .join("; ")}{" "}
                              exceed the 80% continuous safety limit. Click on any room bar to inspect its contributing points.
                            </p>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="pod-success-banner">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 size={16} className="text-emerald-400 flex-none" />
                          <span className="text-xs text-emerald-300">
                            All monitored spaces satisfy PUE 7.1 / NEC continuous electrical load ratings (under 80% circuit capacity).
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="pod-empty-chart">
                  <Zap size={32} className="text-slate-600 mb-2" />
                  <p className="text-sm font-medium">No room dimensions or points added yet</p>
                  <Link href="/room" className="text-xs text-blue-400 hover:underline">
                    Create rooms in 3D Room Planner →
                  </Link>
                </div>
              )}

              {/* Energy Consumers Distribution */}
              {energyData.consumerTypeData.length > 0 && (
                <div className="pod-sub-table">
                  <div className="pod-sub-table-title flex justify-between items-center">
                    <span>Load Breakdown by Consumer Category</span>
                    <span className="text-[10px] text-slate-400">Hover to highlight</span>
                  </div>
                  <div className="pod-sub-table-list">
                    {energyData.consumerTypeData.map((item, idx) => {
                      const matchedCategory = item.id === "hvac"
                        ? "HVAC"
                        : item.name.includes("Outlets")
                          ? "Outlets"
                          : item.name.includes("Lighting")
                            ? "Lighting"
                            : "Accessories";
                      const isHovered = hoveredCategory === matchedCategory;
                      const catKey = (item.id as LoadCategoryKey) || "outlets";
                      const isVisible = visibleLoadCategories[catKey] ?? true;

                      return (
                        <div
                          key={idx}
                          className={`pod-sub-table-row cursor-pointer transition-colors ${
                            isHovered
                              ? "bg-cyan-950/40 border-cyan-800/60"
                              : !isVisible
                                ? "opacity-35"
                                : hoveredCategory
                                  ? "opacity-50"
                                  : "hover:bg-slate-800/40"
                          }`}
                          onMouseEnter={() => setHoveredCategory(matchedCategory)}
                          onMouseLeave={() => setHoveredCategory(null)}
                          onClick={() => {
                            if (catKey in visibleLoadCategories) {
                              toggleLoadCategory(catKey);
                            }
                          }}
                          title={`Click to toggle ${item.name} in chart`}
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className="w-2.5 h-2.5 rounded-full flex-none"
                              style={{ backgroundColor: item.fill }}
                            />
                            <span className="text-xs">{item.name}</span>
                          </div>
                          <div className="font-mono text-xs text-right">
                            <strong>{item.kw} kW</strong>
                            <span className="text-slate-400 ml-2">
                              {energyData.totalConnectedKw > 0
                                ? ((item.kw / energyData.totalConnectedKw) * 100).toFixed(0)
                                : 0}
                              %
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Engineering Quick Navigation Footbar */}
      <div className="pod-quick-links">
        <div className="pod-quick-item">
          <Link href="/estimator">
            <div className="pod-quick-icon">
              <CircleDollarSign size={16} />
            </div>
            <div>
              <strong>Material Estimator</strong>
              <small>Edit pricing, labor & contingency</small>
            </div>
            <ChevronRight size={15} className="pod-quick-arrow" />
          </Link>
        </div>

        <div className="pod-quick-item">
          <Link href="/room">
            <div className="pod-quick-icon">
              <Maximize2 size={16} />
            </div>
            <div>
              <strong>3D Room Planner</strong>
              <small>View 80% color-coded capacity indicators</small>
            </div>
            <ChevronRight size={15} className="pod-quick-arrow" />
          </Link>
        </div>

        <div className="pod-quick-item">
          <Link href="/panel">
            <div className="pod-quick-icon">
              <Boxes size={16} />
            </div>
            <div>
              <strong>DIN Rail Switchgear</strong>
              <small>MCBs, RCDs & distribution board layout</small>
            </div>
            <ChevronRight size={15} className="pod-quick-arrow" />
          </Link>
        </div>

        <div className="pod-quick-item">
          <Link href="/reports">
            <div className="pod-quick-icon">
              <TrendingUp size={16} />
            </div>
            <div>
              <strong>Reports & PDF Takeoff</strong>
              <small>Printable itemized cables & room load audit</small>
            </div>
            <ChevronRight size={15} className="pod-quick-arrow" />
          </Link>
        </div>
      </div>

      {/* =========================================================================
          INTERACTIVE SIDE-PANEL DRAWER (Drill-down for clicked chart elements)
          ========================================================================= */}
      {activeDrawerData && (
        <div className="pod-drawer-overlay" onClick={() => setInspectedDrawer(null)}>
          <div
            className="pod-drawer-panel"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby="pod-drawer-title"
          >
            {/* Drawer Header */}
            <div className="pod-drawer-header">
              <div className="flex items-center gap-2.5">
                {activeDrawerData.type === "cost" ? (
                  <span
                    className="w-3.5 h-3.5 rounded-full flex-none"
                    style={{ backgroundColor: activeDrawerData.color }}
                  />
                ) : (
                  <Zap size={18} className="text-amber-400 flex-none" />
                )}
                <div>
                  <span className="pod-drawer-tag font-mono">
                    {activeDrawerData.type === "cost"
                      ? "BUDGET LINE ITEMS BREAKDOWN"
                      : "ROOM ELECTRICAL AUDIT"}
                  </span>
                  <h3 id="pod-drawer-title" className="pod-drawer-title">
                    {activeDrawerData.type === "cost"
                      ? activeDrawerData.category
                      : activeDrawerData.room.name}
                  </h3>
                </div>
              </div>

              <button
                className="pod-drawer-close"
                onClick={() => setInspectedDrawer(null)}
                aria-label="Close side-panel"
              >
                <X size={18} />
              </button>
            </div>

            {/* Drawer Body */}
            <div className="pod-drawer-body">
              {/* CASE 1: COST SLICE DRILL-DOWN */}
              {activeDrawerData.type === "cost" && (
                <>
                  {/* Summary Bar */}
                  <div className="pod-drawer-summary-card">
                    <div className="flex justify-between items-baseline mb-2">
                      <span className="text-xs text-slate-400 font-mono">CATEGORY TOTAL</span>
                      <strong className="text-xl font-mono text-cyan-400">
                        {formatMoney(activeDrawerData.totalValue)}
                      </strong>
                    </div>
                    <div className="flex justify-between text-xs text-slate-400 font-mono">
                      <span>Share of Project Budget:</span>
                      <strong className="text-slate-200">
                        {activeDrawerData.percentage.toFixed(1)}%
                      </strong>
                    </div>
                  </div>

                  {/* If Contingency Category */}
                  {activeDrawerData.category === "Contingency" && (
                    <div className="pod-drawer-section">
                      <div className="pod-drawer-section-head">
                        Contingency Reserve Calculation
                      </div>
                      <div className="pod-drawer-card-box p-3 text-xs leading-relaxed text-slate-300">
                        <p className="mb-2">
                          Contingency rate is set at{" "}
                          <strong className="text-rose-400 font-mono">
                            {activeDrawerData.contingencyRate}%
                          </strong>{" "}
                          of direct expenses (materials and labor).
                        </p>
                        <div className="font-mono text-[11px] p-2 bg-slate-900/60 rounded border border-slate-800 text-slate-400">
                          Reserve = (Material {formatMoney(activeDrawerData.totals.material)} + Labor{" "}
                          {formatMoney(activeDrawerData.totals.labor)}) ×{" "}
                          {activeDrawerData.contingencyRate}% ={" "}
                          <strong className="text-rose-400">
                            {formatMoney(activeDrawerData.totalValue)}
                          </strong>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* If Protection Hardware */}
                  {activeDrawerData.panel.length > 0 && (
                    <div className="pod-drawer-section">
                      <div className="pod-drawer-section-head">
                        DIN-Rail Protective Devices ({activeDrawerData.panel.length})
                      </div>
                      <div className="pod-drawer-items-list">
                        {activeDrawerData.panel.map((dev) => (
                          <div key={dev.id} className="pod-drawer-item-row">
                            <div className="truncate pr-2">
                              <strong className="block text-xs truncate text-slate-200">
                                {dev.name}
                              </strong>
                              <span className="text-[11px] text-slate-400">
                                {dev.kind} · {dev.modules} module{dev.modules > 1 ? "s" : ""}{" "}
                                {dev.poles ? `· ${dev.poles}P` : ""}
                              </span>
                            </div>
                            <div className="text-right font-mono text-xs whitespace-nowrap">
                              <strong className="text-amber-400">
                                {formatMoney(dev.unitPrice || 0)}
                              </strong>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Itemized Materials & Labor Lines */}
                  {activeDrawerData.estimates.length > 0 ? (
                    <div className="pod-drawer-section">
                      <div className="pod-drawer-section-head">
                        Contributing Estimate Lines ({activeDrawerData.estimates.length})
                      </div>
                      <div className="pod-drawer-items-list">
                        {activeDrawerData.estimates.map((item) => {
                          const mat = item.quantity * item.price * (1 + (item.waste || 0) / 100);
                          const lab = item.quantity * (item.labor || 0);
                          const lineTotal =
                            activeDrawerData.category === "Labor" ? lab : mat + lab;

                          return (
                            <div key={item.id} className="pod-drawer-item-row">
                              <div className="truncate pr-3">
                                <strong className="block text-xs truncate text-slate-200">
                                  {item.name}
                                </strong>
                                <span className="text-[11px] text-slate-400">
                                  {item.quantity} {item.unit} @ {formatMoney(item.price)}
                                  {item.waste > 0 ? ` (+${item.waste}% waste)` : ""}
                                  {item.labor > 0
                                    ? ` · Labor: ${formatMoney(item.labor)}/${item.unit}`
                                    : ""}
                                </span>
                              </div>
                              <div className="text-right font-mono text-xs whitespace-nowrap flex-none">
                                <strong className="text-cyan-400">
                                  {formatMoney(lineTotal)}
                                </strong>
                                <span className="block text-[10px] text-slate-400">
                                  {activeDrawerData.totalValue > 0
                                    ? ((lineTotal / activeDrawerData.totalValue) * 100).toFixed(1)
                                    : 0}
                                  % of slice
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : activeDrawerData.category !== "Contingency" &&
                    activeDrawerData.panel.length === 0 ? (
                    <div className="pod-drawer-empty">
                      No specific line items assigned under {activeDrawerData.category}.
                    </div>
                  ) : null}

                  {/* Drawer Footer Shortcut */}
                  <div className="pod-drawer-footer">
                    <Link href="/estimator" className="btn outline w-full justify-center">
                      <SlidersHorizontal size={14} /> Open Material Estimator
                      <ExternalLink size={13} className="ml-1" />
                    </Link>
                  </div>
                </>
              )}

              {/* CASE 2: ROOM / ENERGY LOAD DRILL-DOWN */}
              {activeDrawerData.type === "room" && (
                <>
                  {/* Room Overview Strip */}
                  <div className="pod-drawer-summary-card">
                    <div className="flex justify-between items-baseline mb-2">
                      <span className="text-xs text-slate-400 font-mono">ROOM METRICS</span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded font-mono uppercase font-semibold ${
                          activeDrawerData.load.isOver100
                            ? "bg-rose-950 text-rose-300 border border-rose-800/60"
                            : activeDrawerData.load.isOver80
                              ? "bg-amber-950 text-amber-300 border border-amber-800/60"
                              : "bg-emerald-950 text-emerald-300 border border-emerald-800/60"
                        }`}
                      >
                        {activeDrawerData.load.ratioPercent.toFixed(1)}% Capacity (
                        {activeDrawerData.load.status.toUpperCase()})
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                      <div>
                        <span className="text-slate-400 block text-[11px]">CONNECTED LOAD</span>
                        <strong className="text-amber-400 text-sm">
                          {activeDrawerData.load.totalLoadKw} kW
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">80% SAFETY CEILING</span>
                        <strong className="text-slate-200 text-sm">
                          {(activeDrawerData.load.capacityKw * 0.8).toFixed(2)} kW
                        </strong>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">ROOM DIMENSIONS</span>
                        <span className="text-slate-300">
                          {activeDrawerData.room.length} × {activeDrawerData.room.width} m (
                          {activeDrawerData.area} m²)
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">EST. CURRENT (230V)</span>
                        <span className="text-slate-300">
                          ~{activeDrawerData.operatingCurrentAmps} A
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar with 80% line */}
                    <div className="mt-3">
                      <div className="flex justify-between text-[10px] text-slate-400 mb-1 font-mono">
                        <span>Load Ratio</span>
                        <span>Max Breaker: {activeDrawerData.load.capacityKw} kW</span>
                      </div>
                      <div className="h-2 bg-slate-900 rounded overflow-hidden relative">
                        <div
                          className="h-full transition-all"
                          style={{
                            width: `${Math.min(100, activeDrawerData.load.ratioPercent)}%`,
                            backgroundColor: activeDrawerData.load.colorHex,
                          }}
                        />
                        <div
                          className="absolute top-0 bottom-0 w-0.5 bg-amber-400 z-10"
                          style={{ left: "80%" }}
                          title="80% continuous duty safety ceiling"
                        />
                      </div>
                    </div>
                  </div>

                  {/* PUE Compliance Evaluation */}
                  <div className="pod-drawer-section">
                    <div className="pod-drawer-section-head">
                      PUE 7.1 / NEC 210.19 Compliance Status
                    </div>
                    {activeDrawerData.load.isOver80 ? (
                      <div className="pod-warning-banner">
                        <strong className="block text-xs text-amber-300 mb-1">
                          ⚠️ Exceeds 80% Continuous Duty Rating
                        </strong>
                        <p className="text-[11px] text-amber-200/80 leading-relaxed m-0">
                          Active electrical load ({activeDrawerData.load.totalLoadKw} kW) exceeds 80%
                          of the 16A circuit breaker rating (
                          {(activeDrawerData.load.capacityKw * 0.8).toFixed(2)} kW).
                          <br />
                          <strong>Recommended action:</strong> Split high-draw appliances (e.g.,
                          heaters, ovens, air conditioners) onto a dedicated 16A or 20A branch
                          line with 3×2.5 mm² or 3×4.0 mm² copper cable.
                        </p>
                      </div>
                    ) : (
                      <div className="pod-success-banner">
                        <strong className="block text-xs text-emerald-300 mb-0.5">
                          ✓ Continuous Thermal Load Compliant
                        </strong>
                        <p className="text-[11px] text-emerald-200/80 leading-relaxed m-0">
                          Load is within safe margins. Headroom remaining before the 80% limit:{" "}
                          <strong className="font-mono">
                            {(
                              activeDrawerData.load.capacityKw * 0.8 -
                              activeDrawerData.load.totalLoadKw
                            ).toFixed(2)}{" "}
                            kW
                          </strong>
                          .
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Points List Contributing to Load */}
                  <div className="pod-drawer-section">
                    <div className="pod-drawer-section-head flex justify-between items-center">
                      <span>Installation Points ({activeDrawerData.points.length})</span>
                      <span className="text-[10px] font-mono text-slate-400">
                        Outlets: {activeDrawerData.load.breakdown.outletsKw} kW
                        {activeDrawerData.load.breakdown.hvacKw > 0
                          ? ` · HVAC: ${activeDrawerData.load.breakdown.hvacKw} kW`
                          : ""}
                        {" "}· Lights: {activeDrawerData.load.breakdown.lightsKw} kW
                      </span>
                    </div>

                    {activeDrawerData.points.length > 0 ? (
                      <div className="pod-drawer-items-list">
                        {activeDrawerData.points.map((pt, idx) => {
                          const kw = getPointPowerKw(pt);
                          return (
                            <div key={pt.id || idx} className="pod-drawer-item-row">
                              <div className="flex items-center gap-2.5 truncate pr-2">
                                <span className="pod-point-icon-badge font-mono text-[10px] uppercase">
                                  {pt.kind.slice(0, 3)}
                                </span>
                                <div className="truncate">
                                  <strong className="block text-xs truncate text-slate-200">
                                    {pt.label || `${pt.kind} #${idx + 1}`}
                                  </strong>
                                  <span className="text-[10px] text-slate-400 font-mono">
                                    Coord: ({pt.x.toFixed(2)}, {pt.y.toFixed(2)})
                                  </span>
                                </div>
                              </div>
                              <div className="text-right font-mono text-xs whitespace-nowrap flex-none">
                                <strong
                                  className={
                                    kw >= 1.5
                                      ? "text-amber-400 font-bold"
                                      : "text-slate-300"
                                  }
                                >
                                  {kw.toFixed(2)} kW
                                </strong>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="pod-drawer-empty">
                        No installation points placed in this room yet.
                      </div>
                    )}
                  </div>

                  {/* Drawer Footer Shortcut */}
                  <div className="pod-drawer-footer">
                    <Link href="/room" className="btn outline w-full justify-center">
                      <Maximize2 size={14} /> Open in 3D Room Planner
                      <ExternalLink size={13} className="ml-1" />
                    </Link>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
