import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { calculateRoomLoad, type Room, type RoomLoadStatus, type WallSide } from "../model/project";
import { routePath } from "../model/geometry";

export type CameraView = "iso" | "top" | "front" | "side" | "inside";

const pointColors = {
  outlet: 0x49c4e4,
  switch: 0xf0bd76,
  light: 0xffe2a6,
  panel: 0x5c98f5,
  junction: 0x92d0bd,
};

function createLoadBillboardTexture(status: RoomLoadStatus, isLight: boolean): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 160;
  const ctx = canvas.getContext("2d");
  if (!ctx) return new THREE.CanvasTexture(canvas);

  // Background rounded rect
  const r = 20;
  const w = 496;
  const h = 144;
  const x = 8;
  const y = 8;

  ctx.fillStyle = isLight ? "rgba(245, 248, 252, 0.96)" : "rgba(8, 20, 32, 0.94)";
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fill();

  // Border with status color (thicker when over 80%)
  ctx.lineWidth = status.isOver80 ? 6 : 3;
  ctx.strokeStyle = status.colorHex;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.stroke();

  // Status icon and header text
  ctx.fillStyle = status.colorHex;
  ctx.font = "bold 22px 'IBM Plex Mono', monospace, sans-serif";
  const icon = status.isOver100
    ? "🚨 OVERLOAD EXCEEDED"
    : status.isOver80
      ? "⚠️ LOAD > 80% LIMIT"
      : "⚡ LOAD NORMAL";
  ctx.fillText(icon, 28, 44);

  // Main Ratio
  ctx.fillStyle = isLight ? "#0f1f30" : "#f1f6fc";
  ctx.font = "bold 44px 'IBM Plex Mono', monospace, sans-serif";
  ctx.fillText(`${status.ratioPercent.toFixed(1)}%`, 28, 94);

  // Power breakdown subtitle
  ctx.font = "20px 'IBM Plex Mono', monospace, sans-serif";
  ctx.fillStyle = isLight ? "#385068" : "#98b0c8";
  ctx.fillText(
    `${status.totalLoadKw.toFixed(2)} kW / ${status.capacityKw.toFixed(2)} kW`,
    28,
    130,
  );

  // Status badge on right side
  const badgeText = status.isOver100 ? "CRITICAL" : status.isOver80 ? "WARNING" : "OPTIMAL";
  ctx.fillStyle = status.colorHex;
  ctx.beginPath();
  ctx.roundRect(335, 22, 145, 34, 8);
  ctx.fill();
  ctx.fillStyle = status.isOver80 || status.isOver100 ? "#0d1b2a" : "#ffffff";
  ctx.font = "bold 16px 'IBM Plex Mono', monospace, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(badgeText, 407, 45);
  ctx.textAlign = "left";

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function Room3D({
  room,
  view = "iso",
  transparentWalls = true,
  ceiling = false,
  nightMode = false,
  showLoadIndicator = true,
}: {
  room: Room;
  view?: CameraView;
  transparentWalls?: boolean;
  ceiling?: boolean;
  nightMode?: boolean;
  showLoadIndicator?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const camRef = useRef<{ key: string; pos: THREE.Vector3; target: THREE.Vector3 } | null>(null);

  useEffect(() => {
    const host = ref.current;
    if (!host) return;

    const isLight = document.documentElement.getAttribute("data-theme") === "light";
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(
      nightMode ? "#040b16" : isLight ? "#e8edf5" : "#0b1b2c",
    );

    const camera = new THREE.PerspectiveCamera(42, 1, 0.05, 200);
    const centerY = (room.floorElevation ?? 0) + room.height * 0.42;
    const span = Math.max(room.length, room.width, room.height, 2);
    const distance = span * 1.8;

    if (view === "inside") {
      camera.position.set(0, 1.6, 0.2);
    } else {
      camera.position.set(
        view === "top" ? 0 : view === "front" ? 0 : view === "side" ? distance : distance * 0.85,
        view === "top" ? centerY + distance : view === "iso" ? centerY + distance * 0.68 : centerY,
        view === "front" ? distance : view === "side" ? 0 : distance * 0.9,
      );
    }

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    host.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.target.set(0, centerY, 0);
    controls.minDistance = view === "inside" ? 0.2 : Math.max(1, span * 0.45);
    controls.maxDistance = span * 6;

    const camKey = `${room.id}:${view}`;
    const saved = camRef.current;
    if (saved && saved.key === camKey) {
      camera.position.copy(saved.pos);
      controls.target.copy(saved.target);
    }
    controls.update();

    // Lighting setup
    if (nightMode) {
      // Dark evening atmosphere
      scene.add(new THREE.HemisphereLight(0x1a2e46, 0x050c14, 0.5));
      const moon = new THREE.DirectionalLight(0x5c88b8, 0.3);
      moon.position.set(span, span * 2, span);
      scene.add(moon);
    } else {
      scene.add(
        new THREE.HemisphereLight(
          isLight ? 0xffffff : 0xb9dbff,
          isLight ? 0xa8bccc : 0x283f53,
          isLight ? 2.2 : 1.8,
        ),
      );
      const sunlight = new THREE.DirectionalLight(0xffffff, isLight ? 2.4 : 2.2);
      sunlight.position.set(span, span * 2, span);
      sunlight.castShadow = true;
      sunlight.shadow.mapSize.set(1024, 1024);
      sunlight.shadow.camera.left = -span * 1.5;
      sunlight.shadow.camera.right = span * 1.5;
      sunlight.shadow.camera.top = span * 1.5;
      sunlight.shadow.camera.bottom = -span * 1.5;
      scene.add(sunlight);
    }

    const group = new THREE.Group();
    group.position.y = room.floorElevation ?? 0;
    scene.add(group);

    const material = (color: number, roughness = 0.72, opacity = 1) =>
      new THREE.MeshStandardMaterial({
        color,
        roughness,
        transparent: opacity < 1,
        opacity,
        side: THREE.DoubleSide,
        depthWrite: opacity === 1,
      });

    const wallMat = material(0x7496aa, 0.78, transparentWalls ? (nightMode ? 0.25 : 0.32) : 1);
    const floorMat = material(nightMode ? 0x122435 : 0x1d3c56, 0.9);
    const metal = material(0x6a8496, 0.45);
    const glass = material(0x94cde9, 0.13, 0.34);

    function box(
      w: number,
      h: number,
      d: number,
      x: number,
      y: number,
      z: number,
      mat: THREE.Material,
      parent = group,
    ) {
      if (w <= 0 || h <= 0 || d <= 0) return;
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      mesh.position.set(x, y, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      parent.add(mesh);
      return mesh;
    }

    const thick = room.wallThickness ?? 0.16;
    box(room.length, 0.12, room.width, 0, -0.06, 0, floorMat);

    const floorLines = new THREE.GridHelper(
      Math.max(room.length, room.width) * 1.3,
      Math.max(4, Math.round(span * 2)),
      0x5484a5,
      0x2d506a,
    );
    floorLines.position.y = 0.009;
    group.add(floorLines);

    function wallAxis(side: WallSide) {
      return side === "north" || side === "south" ? room.length : room.width;
    }

    function segment(
      side: WallSide,
      start: number,
      end: number,
      low: number,
      high: number,
      mat: THREE.Material,
    ) {
      if (end - start < 0.005 || high - low < 0.005) return;
      const horizontal = side === "north" || side === "south";
      const along = (start + end) / 2 - wallAxis(side) / 2;
      const wallPosition = horizontal
        ? side === "north"
          ? -room.width / 2
          : room.width / 2
        : side === "west"
          ? -room.length / 2
          : room.length / 2;

      box(
        horizontal ? end - start : thick,
        high - low,
        horizontal ? thick : end - start,
        horizontal ? along : wallPosition,
        (low + high) / 2,
        horizontal ? wallPosition : along,
        mat,
      );
    }

    // Build walls with openings
    for (const side of ["north", "south", "east", "west"] as WallSide[]) {
      let cursor = 0;
      const openings = [...(room.openings ?? [])]
        .filter((o) => o.wall === side)
        .sort((a, b) => a.offset - b.offset);

      for (const opening of openings) {
        segment(side, cursor, opening.offset, 0, room.height, wallMat);
        segment(side, opening.offset, opening.offset + opening.width, 0, opening.sill, wallMat);
        segment(
          side,
          opening.offset,
          opening.offset + opening.width,
          opening.sill + opening.height,
          room.height,
          wallMat,
        );

        const frame = 0.045;
        segment(
          side,
          opening.offset - frame,
          opening.offset,
          opening.sill,
          opening.sill + opening.height,
          metal,
        );
        segment(
          side,
          opening.offset + opening.width,
          opening.offset + opening.width + frame,
          opening.sill,
          opening.sill + opening.height,
          metal,
        );
        segment(
          side,
          opening.offset,
          opening.offset + opening.width,
          opening.sill + opening.height,
          opening.sill + opening.height + frame,
          metal,
        );

        if (opening.kind === "window") {
          segment(
            side,
            opening.offset,
            opening.offset + opening.width,
            opening.sill,
            opening.sill + frame,
            metal,
          );
          const horizontal = side === "north" || side === "south";
          const along = opening.offset + opening.width / 2 - wallAxis(side) / 2;
          const fixed = horizontal
            ? side === "north"
              ? -room.width / 2
              : room.width / 2
            : side === "west"
              ? -room.length / 2
              : room.length / 2;

          box(
            horizontal ? opening.width : 0.018,
            opening.height,
            horizontal ? 0.018 : opening.width,
            horizontal ? along : fixed,
            opening.sill + opening.height / 2,
            horizontal ? fixed : along,
            glass,
          );
        }

        if (opening.kind === "door") {
          const horizontal = side === "north" || side === "south";
          const along = opening.offset + opening.width * 0.38 - wallAxis(side) / 2;
          const fixed = horizontal
            ? side === "north"
              ? -room.width / 2
              : room.width / 2
            : side === "west"
              ? -room.length / 2
              : room.length / 2;

          box(
            horizontal ? opening.width * 0.76 : 0.035,
            opening.height * 0.95,
            horizontal ? 0.035 : opening.width * 0.76,
            horizontal ? along : fixed,
            opening.height * 0.475,
            horizontal ? fixed : along,
            material(0x375b72, 0.73, 0.82),
          );
        }

        cursor = opening.offset + opening.width;
      }
      segment(side, cursor, wallAxis(side), 0, room.height, wallMat);
    }

    if (ceiling) {
      box(room.length, 0.08, room.width, 0, room.height + 0.04, 0, material(0x8cb3c9, 0.8, 0.38));
    }

    // Points rendering (realistic sockets, switches, glowing fixtures)
    room.points.forEach((p) => {
      const color = pointColors[p.kind];
      const posX = (p.x - 0.5) * room.length;
      const posZ = (p.y - 0.5) * room.width;

      if (p.kind === "light") {
        const height = room.height - 0.12;
        // Chandelier / ceiling light fixture
        const fixture = new THREE.Mesh(
          new THREE.CylinderGeometry(0.18, 0.22, 0.08, 24),
          new THREE.MeshStandardMaterial({
            color: 0xffffff,
            emissive: nightMode ? 0xffeaae : 0xffeecc,
            emissiveIntensity: nightMode ? 1.8 : 0.8,
          }),
        );
        fixture.position.set(posX, height, posZ);
        group.add(fixture);

        // Cord / stem
        const stem = new THREE.Mesh(
          new THREE.CylinderGeometry(0.015, 0.015, 0.2, 8),
          material(0x1a2e46, 0.4),
        );
        stem.position.set(posX, height + 0.1, posZ);
        group.add(stem);

        // Add real point light in night mode or subtle in day mode
        const pLight = new THREE.PointLight(
          0xffecd0,
          nightMode ? 2.4 : 0.8,
          room.length * 1.8,
          1.2,
        );
        pLight.position.set(posX, height - 0.1, posZ);
        pLight.castShadow = true;
        group.add(pLight);
      } else if (p.kind === "outlet") {
        // Socket Faceplate at 0.35m
        const faceplate = new THREE.Mesh(
          new THREE.BoxGeometry(0.12, 0.12, 0.03),
          new THREE.MeshStandardMaterial({
            color: 0xdde6ed,
            roughness: 0.3,
          }),
        );
        faceplate.position.set(posX, 0.36, posZ);
        group.add(faceplate);

        // Core pin indicator
        const pin = new THREE.Mesh(
          new THREE.CylinderGeometry(0.035, 0.035, 0.035, 12),
          new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.5 }),
        );
        pin.rotation.x = Math.PI / 2;
        pin.position.set(posX, 0.36, posZ);
        group.add(pin);
      } else if (p.kind === "switch") {
        // Switch plate at 0.95m
        const faceplate = new THREE.Mesh(
          new THREE.BoxGeometry(0.11, 0.11, 0.03),
          new THREE.MeshStandardMaterial({ color: 0xdde6ed, roughness: 0.3 }),
        );
        faceplate.position.set(posX, 1.05, posZ);
        group.add(faceplate);

        const rocker = new THREE.Mesh(
          new THREE.BoxGeometry(0.06, 0.06, 0.035),
          new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.6 }),
        );
        rocker.position.set(posX, 1.05, posZ);
        group.add(rocker);
      } else if (p.kind === "panel") {
        // Distribution panel enclosure at 1.5m
        const panelBox = new THREE.Mesh(
          new THREE.BoxGeometry(0.3, 0.38, 0.12),
          new THREE.MeshStandardMaterial({
            color: 0x223a52,
            metalness: 0.4,
            roughness: 0.5,
          }),
        );
        panelBox.position.set(posX, 1.5, posZ);
        group.add(panelBox);

        // Panel glass / door trim
        const panelDoor = new THREE.Mesh(
          new THREE.BoxGeometry(0.26, 0.34, 0.02),
          new THREE.MeshStandardMaterial({
            color: 0x4bc8dc,
            transparent: true,
            opacity: 0.45,
          }),
        );
        panelDoor.position.set(posX, 1.5, posZ + 0.06);
        group.add(panelDoor);
      } else {
        // Junction box
        const junction = new THREE.Mesh(
          new THREE.CylinderGeometry(0.08, 0.08, 0.04, 16),
          new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.4 }),
        );
        junction.position.set(posX, room.height - 0.35, posZ);
        group.add(junction);
      }
    });

    // Render 3D Cable Routes along ceiling / floor conduits
    (room.routes ?? []).forEach((route) => {
      const points = routePath(room, route);
      if (!points || points.length < 2) return;

      const pathVecs = points.map(
        (pt) =>
          new THREE.Vector3(
            (pt.x - 0.5) * room.length,
            0.04, // conduit run on floor/wall level
            (pt.y - 0.5) * room.width,
          ),
      );

      const curve = new THREE.CatmullRomCurve3(pathVecs);
      const tubeGeom = new THREE.TubeGeometry(curve, 32, 0.018, 8, false);
      const tubeMat = new THREE.MeshStandardMaterial({
        color: 0x3b8cff,
        emissive: 0x3b8cff,
        emissiveIntensity: 0.5,
      });
      const tubeMesh = new THREE.Mesh(tubeGeom, tubeMat);
      group.add(tubeMesh);
    });

    // 3D Electrical Load Indicators (>80% Capacity Warning)
    let hazardMat: THREE.MeshStandardMaterial | null = null;
    let beaconMat: THREE.MeshStandardMaterial | null = null;
    let billboardTex: THREE.CanvasTexture | null = null;

    if (showLoadIndicator) {
      const loadStatus = calculateRoomLoad(room);
      const statusColorHexInt = parseInt(loadStatus.colorHex.replace("#", "0x"), 16);

      // 1. Perimeter Hazard Ribbon and Corner Beacons (when load >= 80%)
      if (loadStatus.isOver80) {
        const hazardBorderGroup = new THREE.Group();
        group.add(hazardBorderGroup);

        hazardMat = new THREE.MeshStandardMaterial({
          color: statusColorHexInt,
          emissive: statusColorHexInt,
          emissiveIntensity: 0.9,
          roughness: 0.3,
        });

        beaconMat = new THREE.MeshStandardMaterial({
          color: statusColorHexInt,
          emissive: statusColorHexInt,
          emissiveIntensity: 1.0,
          metalness: 0.5,
          roughness: 0.2,
        });

        const stripeThickness = 0.08;
        const stripeHeight = 0.02;

        // North & South perimeter hazard strips
        const nsGeo = new THREE.BoxGeometry(
          room.length + stripeThickness,
          stripeHeight,
          stripeThickness,
        );
        const northStrip = new THREE.Mesh(nsGeo, hazardMat);
        northStrip.position.set(0, stripeHeight / 2 + 0.015, -room.width / 2);
        hazardBorderGroup.add(northStrip);

        const southStrip = new THREE.Mesh(nsGeo, hazardMat);
        southStrip.position.set(0, stripeHeight / 2 + 0.015, room.width / 2);
        hazardBorderGroup.add(southStrip);

        // East & West perimeter hazard strips
        const ewGeo = new THREE.BoxGeometry(
          stripeThickness,
          stripeHeight,
          room.width,
        );
        const eastStrip = new THREE.Mesh(ewGeo, hazardMat);
        eastStrip.position.set(room.length / 2, stripeHeight / 2 + 0.015, 0);
        hazardBorderGroup.add(eastStrip);

        const westStrip = new THREE.Mesh(ewGeo, hazardMat);
        westStrip.position.set(-room.length / 2, stripeHeight / 2 + 0.015, 0);
        hazardBorderGroup.add(westStrip);

        // 4 Corner Alert Beacons
        const cornerBeaconGeo = new THREE.CylinderGeometry(0.05, 0.07, 0.2, 16);
        const corners = [
          [-room.length / 2, -room.width / 2],
          [room.length / 2, -room.width / 2],
          [room.length / 2, room.width / 2],
          [-room.length / 2, room.width / 2],
        ];
        corners.forEach(([cx, cz]) => {
          const beacon = new THREE.Mesh(cornerBeaconGeo, beaconMat!);
          beacon.position.set(cx, 0.1, cz);
          hazardBorderGroup.add(beacon);
        });

        // Ambient overload illumination
        const overloadLight = new THREE.PointLight(
          statusColorHexInt,
          loadStatus.isOver100 ? 1.6 : 0.9,
          span * 1.6,
        );
        overloadLight.position.set(0, room.height * 0.6, 0);
        group.add(overloadLight);
      }

      // 2. 3D Floating Overhead Billboard HUD Sprite
      billboardTex = createLoadBillboardTexture(loadStatus, isLight);
      const billboardAspect = 512 / 160;
      const billboardHeight = Math.max(0.62, Math.min(1.15, span * 0.17));
      const billboardWidth = billboardHeight * billboardAspect;

      const billboardMat = new THREE.SpriteMaterial({
        map: billboardTex,
        transparent: true,
        depthTest: false,
      });
      const billboard = new THREE.Sprite(billboardMat);
      billboard.scale.set(billboardWidth, billboardHeight, 1);
      billboard.position.set(0, room.height + 0.58, 0);
      billboard.renderOrder = 999;
      group.add(billboard);
    }

    const observer = new ResizeObserver(() => {
      const w = host.clientWidth,
        h = host.clientHeight;
      if (!w || !h) return;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    observer.observe(host);

    let frame = 0;
    const tick = () => {
      frame = requestAnimationFrame(tick);
      controls.update();

      // Pulsing effect for hazard warning border & beacons if room exceeds 80%
      if (hazardMat) {
        const pulse = 0.5 + 0.5 * Math.sin(performance.now() * 0.005);
        hazardMat.emissiveIntensity = 0.4 + pulse * 1.2;
        if (beaconMat) beaconMat.emissiveIntensity = 0.5 + pulse * 1.4;
      }

      renderer.render(scene, camera);
    };
    tick();

    return () => {
      cancelAnimationFrame(frame);
      camRef.current = { key: camKey, pos: camera.position.clone(), target: controls.target.clone() };
      observer.disconnect();
      controls.dispose();
      if (billboardTex) billboardTex.dispose();
      scene.traverse((object) => {
        if (
          object instanceof THREE.Mesh ||
          object instanceof THREE.LineSegments ||
          object instanceof THREE.Sprite
        ) {
          if (object instanceof THREE.Mesh || object instanceof THREE.LineSegments) {
            object.geometry?.dispose();
          }
          if (Array.isArray(object.material)) object.material.forEach((m) => m?.dispose());
          else object.material?.dispose();
        }
      });
      renderer.dispose();
      host.removeChild(renderer.domElement);
    };
  }, [room, view, transparentWalls, ceiling, nightMode, showLoadIndicator]);

  return (
    <div
      className="three-canvas engineering-viewport"
      ref={ref}
      aria-label={`Three-dimensional room model of ${room.name}`}
    />
  );
}
