import { useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { NumberField } from "./number-field";
import { routeLength } from "../model/geometry";
import { newId, type CableRoute, type Room } from "../model/project";

export function RoutesEditor({
  room,
  onChange,
}: {
  room: Room;
  onChange: (routes: CableRoute[]) => void;
}) {
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const routes = room.routes ?? [];
  const change = (id: string, patch: Partial<CableRoute>) =>
    onChange(routes.map((route) => (route.id === id ? { ...route, ...patch } : route)));
  const options = room.points.map((point) => (
    <option key={point.id} value={point.id}>
      {point.label} · {point.kind}
    </option>
  ));
  return (
    <div className="routes-editor">
      <p className="help-text">
        Connect two saved points. Add bends as normalized plan coordinates (0–100%); the displayed
        length follows the drawn path plus allowance. This is a 2D takeoff only—no cable sizing,
        vertical runs, obstacle avoidance or compliance check.
      </p>
      {room.points.length < 2 ? (
        <p className="muted">Place at least two points on the plan to create a route.</p>
      ) : (
        <div className="route-add">
          <label>
            From
            <select
              aria-label="Route start"
              value={start}
              onChange={(e) => setStart(e.target.value)}
            >
              <option value="">Choose point</option>
              {options}
            </select>
          </label>
          <label>
            To
            <select aria-label="Route end" value={end} onChange={(e) => setEnd(e.target.value)}>
              <option value="">Choose point</option>
              {options}
            </select>
          </label>
          <button
            className="btn primary"
            disabled={!start || !end || start === end}
            onClick={() => {
              onChange([
                ...routes,
                {
                  id: newId(),
                  name: `Route ${routes.length + 1}`,
                  pointIds: [start, end],
                  waypoints: [],
                  allowance: 10,
                },
              ]);
              setStart("");
              setEnd("");
            }}
          >
            <Plus size={15} /> Add route
          </button>
        </div>
      )}
      {routes.map((route) => {
        const length = routeLength(room, route);
        return (
          <div className="route-record" key={route.id}>
            <div className="route-heading">
              <strong>{route.name || "Unnamed route"}</strong>
              <span>
                {length === null
                  ? "Disconnected · choose valid endpoints"
                  : `${length.toFixed(2)} m estimated`}
              </span>
              <button
                className="icon-button"
                aria-label={`Delete route ${route.name}`}
                onClick={() => onChange(routes.filter((r) => r.id !== route.id))}
              >
                <Trash2 size={15} />
              </button>
            </div>
            <div className="route-fields">
              <label>
                Name
                <input
                  aria-label="Route name"
                  value={route.name}
                  onChange={(e) => change(route.id, { name: e.target.value })}
                />
              </label>
              <label>
                From
                <select
                  aria-label={`${route.name} start`}
                  value={route.pointIds[0] ?? ""}
                  onChange={(e) =>
                    change(route.id, { pointIds: [e.target.value, ...route.pointIds.slice(1)] })
                  }
                >
                  <option value="">Missing point</option>
                  {options}
                </select>
              </label>
              <label>
                To
                <select
                  aria-label={`${route.name} end`}
                  value={route.pointIds[route.pointIds.length - 1] ?? ""}
                  onChange={(e) =>
                    change(route.id, { pointIds: [...route.pointIds.slice(0, -1), e.target.value] })
                  }
                >
                  <option value="">Missing point</option>
                  {options}
                </select>
              </label>
              <label>
                Allowance (%)
                <NumberField
                  label={`${route.name} allowance`}
                  min={0}
                  max={100}
                  step={1}
                  value={route.allowance}
                  commit={(n) => void change(route.id, { allowance: n })}
                />
              </label>
            </div>
            {(route.waypoints ?? []).map((bend, index) => (
              <div className="route-bend" key={index}>
                <span>BEND {index + 1}</span>
                {(["x", "y"] as const).map((axis) => (
                  <label key={axis}>
                    {axis === "x" ? "Across length" : "Across width"} (%)
                    <NumberField
                      label={`${route.name} bend ${index + 1} ${axis}`}
                      min={0}
                      max={100}
                      step={1}
                      decimals={0}
                      value={bend[axis] * 100}
                      commit={(n) =>
                        void change(route.id, {
                          waypoints: (route.waypoints ?? []).map((p, i) =>
                            i === index ? { ...p, [axis]: n / 100 } : p,
                          ),
                        })
                      }
                    />
                  </label>
                ))}
                <button
                  className="icon-button"
                  aria-label={`Remove bend ${index + 1}`}
                  onClick={() =>
                    change(route.id, {
                      waypoints: (route.waypoints ?? []).filter((_, i) => i !== index),
                    })
                  }
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}
            <button
              className="btn outline"
              onClick={() => {
                const a = room.points.find((p) => p.id === route.pointIds[0]);
                const b = room.points.find(
                  (p) => p.id === route.pointIds[route.pointIds.length - 1],
                );
                const previous = route.waypoints ?? [];
                const from = previous.at(-1) ?? a;
                if (from && b)
                  change(route.id, {
                    waypoints: [...previous, { x: (from.x + b.x) / 2, y: (from.y + b.y) / 2 }],
                  });
              }}
              disabled={!length || (route.waypoints?.length ?? 0) >= 20}
            >
              <Plus size={14} /> Add bend
            </button>
          </div>
        );
      })}
    </div>
  );
}
