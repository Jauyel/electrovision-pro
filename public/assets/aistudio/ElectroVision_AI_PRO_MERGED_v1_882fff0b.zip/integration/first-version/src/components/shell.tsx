import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Activity,
  Archive,
  Boxes,
  Calculator,
  ChartNoAxesCombined,
  ChevronDown,
  CircleHelp,
  FolderKanban,
  LayoutDashboard,
  Menu,
  Plus,
  ScanLine,
  Settings,
  ShieldCheck,
  Users,
  X,
  Zap,
  Sparkles,
  Bot,
  Sun,
  Moon,
  type LucideIcon,
} from "lucide-react";
import { useStore } from "../model/store";
import type { Word } from "../model/i18n";
import { AiCopilotModal } from "./ai-copilot-modal";

const groups: { label: string; items: { key: Word; path: string; icon: LucideIcon }[] }[] = [
  {
    label: "WORKSPACE",
    items: [
      { key: "dashboard", path: "/", icon: LayoutDashboard },
      { key: "projects", path: "/projects", icon: FolderKanban },
    ],
  },
  {
    label: "DESIGN TOOLS",
    items: [
      { key: "scanner", path: "/room", icon: ScanLine },
      { key: "installation", path: "/installation", icon: Zap },
      { key: "panel", path: "/panel", icon: Boxes },
      { key: "cad", path: "/calculations", icon: Activity },
      { key: "estimator", path: "/estimator", icon: Calculator },
      { key: "validation", path: "/validation", icon: ShieldCheck },
    ],
  },
  {
    label: "MANAGEMENT",
    items: [
      { key: "work", path: "/work", icon: Users },
      { key: "reports", path: "/reports", icon: ChartNoAxesCombined },
      { key: "library", path: "/library", icon: Archive },
      { key: "settings", path: "/settings", icon: Settings },
    ],
  },
];

export const navigation = groups.flatMap((g) => g.items);

export function Shell({ children }: { children: React.ReactNode }) {
  const { db, t, choose, addProject, setLanguage, warning, saved, theme, setTheme } = useStore();
  const [path, navigate] = useLocation();
  const [menu, setMenu] = useState(false);
  const [modal, setModal] = useState(false);
  const [name, setName] = useState("");

  const [aiModal, setAiModal] = useState(false);
  const [aiTab, setAiTab] = useState<"audit" | "scan" | "generate" | "chat">("audit");

  useEffect(() => {
    const open = () => setModal(true);
    window.addEventListener("electrovision:create", open);
    return () => window.removeEventListener("electrovision:create", open);
  }, []);

  useEffect(() => {
    const openAi = (e: any) => {
      if (e.detail?.tab) setAiTab(e.detail.tab);
      setAiModal(true);
    };
    window.addEventListener("electrovision:ai", openAi);
    return () => window.removeEventListener("electrovision:ai", openAi);
  }, []);

  const current = navigation.find((x) => x.path === path);
  const pageTitle = current ? t(current.key) : "404";

  useEffect(() => {
    document.title = `${pageTitle} · ElectroVision AI PRO`;
    document.documentElement.lang = db.language;
  }, [pageTitle, db.language]);

  useEffect(() => {
    if (!modal && !menu && !aiModal) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      setModal(false);
      setMenu(false);
      setAiModal(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [modal, menu, aiModal]);

  function create() {
    if (!name.trim()) return;
    addProject(name);
    setName("");
    setModal(false);
    setMenu(false);
    navigate("/projects");
  }

  return (
    <div className="app-frame">
      {menu && (
        <button
          className="mobile-scrim"
          aria-label="Close navigation"
          onClick={() => setMenu(false)}
        />
      )}
      <aside className={`sidebar ${menu ? "open" : ""}`}>
        <div className="brand">
          <div className="brand-mark">
            <Zap size={22} fill="currentColor" />
          </div>
          <div>
            <strong>
              ELECTRO<span>VISION</span>
            </strong>
            <small>
              AI PRO <i>·</i> ENGINEERING SUITE
            </small>
          </div>
          <button
            className="mobile-close icon-button"
            aria-label="Close menu"
            onClick={() => setMenu(false)}
          >
            <X size={19} />
          </button>
        </div>

        <div className="workspace-tag">
          <span className="online-dot" />
          <span>{t("local")}</span>
          <span className="tag-right">PRO 2026</span>
        </div>

        {/* AI Co-Pilot Quick Launcher Box */}
        <div className="p-3 mx-3 my-2 rounded-xl bg-gradient-to-b from-[#102137] to-[#0a1829] border border-[#3b8cff]/40 shadow-lg shadow-[#3b8cff]/10">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <Sparkles size={15} className="text-[#3b8cff] animate-pulse" />
              <span className="text-xs font-bold text-white tracking-wide">AI CO-PILOT</span>
            </div>
            <span className="text-[10px] font-mono font-bold text-[#4bc8dc] px-1.5 py-0.5 rounded bg-[#4bc8dc]/15">
              GEMINI
            </span>
          </div>
          <p className="text-[11px] text-[#9bb0c8] mb-2 leading-tight">
            {db.language === "uz"
              ? "PUE xavfsizlik auditi, chizma skaneri va muhandis chat."
              : "Аудит ПУЭ, сканер чертежей и инженерный чат."}
          </p>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={() => {
                setAiTab("audit");
                setAiModal(true);
                setMenu(false);
              }}
              className="text-[10px] font-semibold py-1.5 px-2 rounded-lg bg-[#1a2d45] hover:bg-[#3b8cff] text-[#f1f6fc] transition truncate flex items-center justify-center gap-1"
            >
              <ShieldCheck size={12} /> Audit
            </button>
            <button
              onClick={() => {
                setAiTab("scan");
                setAiModal(true);
                setMenu(false);
              }}
              className="text-[10px] font-semibold py-1.5 px-2 rounded-lg bg-[#1a2d45] hover:bg-[#3b8cff] text-[#f1f6fc] transition truncate flex items-center justify-center gap-1"
            >
              <ScanLine size={12} /> Skaner
            </button>
            <button
              onClick={() => {
                setAiTab("generate");
                setAiModal(true);
                setMenu(false);
              }}
              className="text-[10px] font-semibold py-1.5 px-2 rounded-lg bg-[#1a2d45] hover:bg-[#3b8cff] text-[#f1f6fc] transition truncate flex items-center justify-center gap-1"
            >
              <Sparkles size={12} /> Loyiha
            </button>
            <button
              onClick={() => {
                setAiTab("chat");
                setAiModal(true);
                setMenu(false);
              }}
              className="text-[10px] font-semibold py-1.5 px-2 rounded-lg bg-[#1a2d45] hover:bg-[#3b8cff] text-[#f1f6fc] transition truncate flex items-center justify-center gap-1"
            >
              <Bot size={12} /> Chat
            </button>
          </div>
        </div>

        <div className="nav-scroll">
          {groups.map((group) => (
            <div className="nav-group" key={group.label}>
              <p>{group.label}</p>
              {group.items.map((item) => (
                <Link
                  href={item.path}
                  key={item.path}
                  onClick={() => setMenu(false)}
                  className={`nav-item ${path === item.path ? "active" : ""}`}
                >
                  <item.icon size={18} strokeWidth={1.8} />
                  <span>{t(item.key)}</span>
                  {path === item.path && <span className="nav-indicator" />}
                </Link>
              ))}
            </div>
          ))}
        </div>

        <div className="sidebar-bottom">
          <div className="support-icon">
            <CircleHelp size={19} />
          </div>
          <div>
            <strong>O'zbekiston PUE / GOST</strong>
            <span>Standartlar bo'yicha hisoblangan.</span>
          </div>
        </div>
      </aside>

      <div className="main-column">
        <header className="topbar">
          <div className="top-left">
            <button
              aria-label="Open navigation"
              className="icon-button menu-trigger"
              onClick={() => setMenu(true)}
            >
              <Menu size={21} />
            </button>
            <div className="breadcrumbs">
              WORKSPACE <span>/</span> <b>{pageTitle}</b>
            </div>
          </div>

          <div className="top-actions">
            {/* Direct AI Co-Pilot Topbar Button */}
            <button
              onClick={() => {
                setAiTab("audit");
                setAiModal(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#3b8cff] to-[#4bc8dc] hover:from-[#2f75db] hover:to-[#38b1c4] text-white font-bold text-xs transition shadow-md shadow-[#3b8cff]/20 cursor-pointer"
            >
              <Sparkles size={14} className="animate-pulse" />
              <span>AI Muhandis</span>
            </button>

            <div className="project-select-wrap">
              <FolderKanban size={15} />
              <select
                aria-label={t("project")}
                value={db.activeId ?? ""}
                onChange={(e) => choose(e.target.value || null)}
              >
                <option value="">{t("project")}: —</option>
                {db.projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
              <ChevronDown size={14} />
            </div>

            <div className="top-divider" />

            {/* Theme Switcher Toggle */}
            <button
              type="button"
              className={`theme-toggle-btn flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition text-xs font-semibold cursor-pointer ${
                theme === "light"
                  ? "bg-amber-500/15 border-amber-600/40 text-amber-800 hover:bg-amber-500/25 shadow-sm"
                  : "bg-[#102137] border-[#23374f] text-[#69acff] hover:bg-[#1a2d45] hover:text-white"
              }`}
              onClick={() => setTheme(theme === "light" ? "dark" : "light")}
              title={
                theme === "light"
                  ? "Light Engineering faol · Deep Space (qorong'i) rejimiga o'tish"
                  : "Deep Space faol · Light Engineering (yuqori kontrastli maydon) rejimiga o'tish"
              }
              aria-label="Toggle theme between Deep Space and Light Engineering"
            >
              {theme === "light" ? (
                <>
                  <Sun size={15} className="text-amber-600" />
                  <span className="font-mono text-[11px] font-bold">Light Eng.</span>
                </>
              ) : (
                <>
                  <Moon size={15} className="text-[#3b8cff]" />
                  <span className="font-mono text-[11px] font-bold">Deep Space</span>
                </>
              )}
            </button>

            <select
              className="language-select"
              aria-label="Language"
              value={db.language}
              onChange={(e) => changeLanguage(e.target.value)}
            >
              <option value="uz">UZ (O'zbek)</option>
              <option value="ru">RU (Русский)</option>
              <option value="en">EN (English)</option>
            </select>

            <button
              className="avatar cursor-pointer"
              title="AI Studio Pro"
              onClick={() => {
                setAiTab("chat");
                setAiModal(true);
              }}
            >
              AI
            </button>
          </div>
        </header>

        <main className="content">
          {warning && <div className="alert danger">{warning}</div>}
          {!saved && (
            <div className="alert danger">
              Local save failed. Export a backup before closing this tab.
            </div>
          )}
          {children}
        </main>
      </div>

      {/* New Project Modal */}
      {modal && (
        <div
          className="modal-backdrop"
          role="presentation"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setModal(false);
          }}
        >
          <form
            className="modal-panel"
            role="dialog"
            aria-modal="true"
            aria-label={t("create")}
            onSubmit={(e) => {
              e.preventDefault();
              create();
            }}
          >
            <div className="modal-head">
              <div>
                <span className="eyebrow">NEW WORKSPACE</span>
                <h2>{t("create")}</h2>
              </div>
              <button
                type="button"
                className="icon-button"
                aria-label="Close"
                onClick={() => setModal(false)}
              >
                <X size={20} />
              </button>
            </div>
            <label>
              {t("name")}
              <input
                autoFocus
                required
                maxLength={100}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Masalan: Toshkent · Yangi ofis yoki Hovli uy"
              />
            </label>
            <div className="modal-actions">
              <button type="button" className="btn ghost" onClick={() => setModal(false)}>
                {t("cancel")}
              </button>
              <button className="btn primary" type="submit">
                <Plus size={17} />
                {t("create")}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* AI Copilot Modal */}
      <AiCopilotModal
        isOpen={aiModal}
        onClose={() => setAiModal(false)}
        defaultTab={aiTab}
      />

      <button className="floating-create" onClick={() => setModal(true)} aria-label={t("create")}>
        <Plus size={21} />
      </button>
    </div>
  );

  function changeLanguage(value: string) {
    if (value === "uz" || value === "ru" || value === "en") setLanguage(value);
  }
}

export function ProjectGate({ children }: { children: React.ReactNode }) {
  const { project, t } = useStore();
  return project ? (
    <>{children}</>
  ) : (
    <div className="empty-state tall">
      <div className="empty-icon">
        <FolderKanban size={26} />
      </div>
      <h2>{t("noProject")}</h2>
      <p>{t("start")} Yangi loyiha yaratish yoki ro'yxatdan ochish uchun Loyihalar bo'limiga o'ting.</p>
      <Link href="/projects" className="btn primary">
        {t("projects")} <span>→</span>
      </Link>
    </div>
  );
}

export function SectionHead({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="section-head">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {action && <div className="section-actions">{action}</div>}
    </div>
  );
}

export function Panel({
  title,
  label,
  children,
  className = "",
  action,
}: {
  title?: string;
  label?: string;
  children: React.ReactNode;
  className?: string;
  action?: React.ReactNode;
}) {
  return (
    <section className={`panel ${className}`}>
      <div className="panel-heading">
        <div>
          {label && <span className="eyebrow">{label}</span>}
          {title && <h2>{title}</h2>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

export function LocalNotice() {
  return (
    <div className="notice">
      <ShieldCheck size={16} />
      <span>
        Ma'lumotlar ushbu brauzerda ishonchli saqlanadi. PUE va GOST me'yorlariga rioya qiling.
      </span>
    </div>
  );
}
