import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";

/** One DIN module is 17.5 mm wide; every imported device is scaled so its width equals modules × this pitch. */
export const MODULE_MM = 17.5;

const BASE = "/models";
const loader = new GLTFLoader();
let manifest: Set<string> | null = null;
let manifestPromise: Promise<Set<string>> | null = null;
const templates = new Map<string, THREE.Object3D | null>();
const pending = new Map<string, Promise<THREE.Object3D | null>>();

/** Name of the device file, e.g. mcb-2m -> /models/devices/mcb-2m.glb */
export const deviceModelName = (kind: string, modules: number) =>
  `${kind.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${modules}m`;

function loadManifest(): Promise<Set<string>> {
  manifestPromise ??= fetch(`${BASE}/manifest.json`, { cache: "no-cache" })
    .then((r) => (r.ok ? r.json() : null))
    .then((json) => {
      const list = Array.isArray(json?.devices) ? json.devices.filter((n: unknown) => typeof n === "string") : [];
      manifest = new Set<string>(list);
      return manifest;
    })
    .catch(() => (manifest = new Set<string>()));
  return manifestPromise;
}

/** Synchronous lookup: a ready template, or null when none is available (yet). */
export function peekDeviceModel(name: string): THREE.Object3D | null {
  return templates.get(name) ?? null;
}

/** Loads /models/devices/<name>.glb only if it is listed in manifest.json; resolves null when unavailable or invalid. */
export async function ensureDeviceModel(name: string): Promise<THREE.Object3D | null> {
  if (templates.has(name)) return templates.get(name) ?? null;
  const listed = await loadManifest();
  if (!listed.has(name)) {
    templates.set(name, null);
    return null;
  }
  const running = pending.get(name);
  if (running) return running;
  const job: Promise<THREE.Object3D | null> = loader
    .loadAsync(`${BASE}/devices/${name}.glb`)
    .then((gltf) => {
      gltf.scene.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          o.userData.sharedAsset = true; // geometry/materials are shared between clones: never dispose them per scene
          o.castShadow = true;
          o.receiveShadow = true;
        }
      });
      return gltf.scene as THREE.Object3D;
    })
    .catch((error) => {
      console.warn(`[models] ${name}.glb could not be loaded; using the generic shape.`, error);
      return null;
    })
    .then((scene) => {
      templates.set(name, scene);
      pending.delete(name);
      return scene;
    });
  pending.set(name, job);
  return job;
}

export type FittedModel = { wrap: THREE.Group; width: number; height: number; depth: number };

/**
 * Clones the template, centres it on its bounding box and scales it uniformly so its X width equals
 * `targetWidth` (scene units). Units inside the GLB do not matter; the model must be modelled with
 * Y up, front face towards +Z, and a width equal to the real module width.
 */
export function fitToWidth(template: THREE.Object3D, targetWidth: number): FittedModel | null {
  const model = template.clone(true);
  const box = new THREE.Box3().setFromObject(model);
  const size = box.getSize(new THREE.Vector3());
  if (!Number.isFinite(size.x) || size.x <= 1e-9 || size.y <= 1e-9 || size.z <= 1e-9) return null;
  const center = box.getCenter(new THREE.Vector3());
  model.position.sub(center);
  const wrap = new THREE.Group();
  wrap.add(model);
  const scale = targetWidth / size.x;
  wrap.scale.setScalar(scale);
  return { wrap, width: size.x * scale, height: size.y * scale, depth: size.z * scale };
}
