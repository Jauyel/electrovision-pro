import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  calculateRoomLoad,
  getPointPowerKw,
  slug,
  type Project,
  type Room,
} from "../model/project";
import { routeLength } from "../model/geometry";

export interface ItemizedCableRun {
  roomName: string;
  routeName: string;
  pointsDesc: string;
  pointsCount: number;
  planLengthM: number;
  allowancePercent: number;
  cutLengthM: number;
  estimatedLoadKw: number;
  recommendedCable: string;
}

export interface ItemizedRoomLoad {
  roomName: string;
  areaM2: number;
  dimensionsStr: string;
  pointsCount: number;
  outletsKw: number;
  lightsKw: number;
  totalLoadKw: number;
  capacityKw: number;
  ratioPercent: number;
  status: "optimal" | "moderate" | "warning" | "critical";
  statusText: string;
  complianceRule: string;
}

export function compileItemizedCableRuns(project: Project): {
  runs: ItemizedCableRun[];
  totalLengthM: number;
  roomTotals: { roomName: string; lengthM: number; routesCount: number }[];
} {
  const runs: ItemizedCableRun[] = [];
  const roomTotals: { roomName: string; lengthM: number; routesCount: number }[] = [];

  for (const room of project.rooms) {
    let roomLen = 0;
    const routes = room.routes ?? [];

    for (const route of routes) {
      const len = routeLength(room, route) ?? 0;
      roomLen += len;

      const points = route.pointIds
        .map((id) => room.points.find((p) => p.id === id))
        .filter((p): p is NonNullable<typeof p> => p !== undefined);

      const pointsDesc = points.map((p) => p.label || p.kind).join(" → ") || "No points linked";
      const estimatedLoadKw = points.reduce((sum, p) => sum + getPointPowerKw(p), 0);

      // Determine recommended cable specification based on connected appliances and load
      const hasOutlets = points.some((p) => p.kind === "outlet");
      const hasHeavy = points.some(
        (p) => /plita|pech|duxovka|oven|stove|boiler|heater/i.test(p.label) || (p.powerKw ?? 0) >= 2.0,
      );

      let recommendedCable = "3×1.5 mm² Cu (ВВГнг-LS)";
      if (hasHeavy || estimatedLoadKw >= 3.5) {
        recommendedCable = "3×4.0 mm² Cu (ВВГнг-LS)";
      } else if (hasOutlets || estimatedLoadKw >= 1.5) {
        recommendedCable = "3×2.5 mm² Cu (ВВГнг-LS)";
      }

      const planLengthM = route.allowance > 0 ? len / (1 + route.allowance / 100) : len;

      runs.push({
        roomName: room.name,
        routeName: route.name,
        pointsDesc,
        pointsCount: points.length,
        planLengthM: Math.round(planLengthM * 100) / 100,
        allowancePercent: route.allowance,
        cutLengthM: Math.round(len * 100) / 100,
        estimatedLoadKw: Math.round(estimatedLoadKw * 100) / 100,
        recommendedCable,
      });
    }

    if (routes.length > 0) {
      roomTotals.push({
        roomName: room.name,
        lengthM: Math.round(roomLen * 100) / 100,
        routesCount: routes.length,
      });
    }
  }

  const totalLengthM = runs.reduce((sum, r) => sum + r.cutLengthM, 0);
  return { runs, totalLengthM: Math.round(totalLengthM * 100) / 100, roomTotals };
}

export function compileItemizedRoomLoads(project: Project): {
  loads: ItemizedRoomLoad[];
  totalConnectedKw: number;
  overloadedCount: number;
  buildingAreaM2: number;
} {
  const loads: ItemizedRoomLoad[] = [];
  let totalRawLoad = 0;
  let buildingAreaM2 = 0;
  let overloadedCount = 0;

  for (const room of project.rooms) {
    const status = calculateRoomLoad(room);
    const area = room.length * room.width;
    buildingAreaM2 += area;
    totalRawLoad += status.totalLoadKw;
    if (status.isOver80) overloadedCount++;

    let complianceRule = "PASS (Continuous load < 80%)";
    if (status.isOver100) {
      complianceRule = "FAIL: OVERLOAD (> 100% Breaker rating)";
    } else if (status.isOver80) {
      complianceRule = "WARNING: EXCEEDS 80% CONTINUOUS LIMIT (PUE 7.1 / NEC)";
    }

    loads.push({
      roomName: room.name,
      areaM2: Math.round(area * 100) / 100,
      dimensionsStr: `${room.length} × ${room.width} × ${room.height} m`,
      pointsCount: room.points.length,
      outletsKw: status.breakdown.outletsKw,
      lightsKw: status.breakdown.lightsKw,
      totalLoadKw: status.totalLoadKw,
      capacityKw: status.capacityKw,
      ratioPercent: status.ratioPercent,
      status: status.status,
      statusText: `${status.ratioPercent.toFixed(1)}% (${status.status.toUpperCase()})`,
      complianceRule,
    });
  }

  return {
    loads,
    totalConnectedKw: Math.round(totalRawLoad * 100) / 100,
    overloadedCount,
    buildingAreaM2: Math.round(buildingAreaM2 * 100) / 100,
  };
}

export function generateItemizedPdfReport(project: Project): jsPDF {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;

  const cableData = compileItemizedCableRuns(project);
  const loadData = compileItemizedRoomLoads(project);

  // --------------------------------------------------------------------------
  // Header & Title Block
  // --------------------------------------------------------------------------
  // Deep Space Top Brand Ribbon
  doc.setFillColor(13, 27, 42); // #0d1b2a
  doc.rect(0, 0, pageWidth, 28, "F");

  // Cyan Accent Strip
  doc.setFillColor(75, 200, 220); // #4bc8dc
  doc.rect(0, 27, pageWidth, 1.5, "F");

  // Logo / Product Name
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text("ELECTROVISION AI PRO", margin, 12);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(150, 185, 215);
  doc.text("ELECTRICAL ENGINEERING SUITE · PUE 7.1 / NEC COMPLIANT REPORT", margin, 18);

  // Document Date & Meta on Top Right
  doc.setFontSize(8);
  doc.setTextColor(200, 225, 245);
  const now = new Date();
  const dateStr = now.toLocaleDateString("en-GB", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
  doc.text(`REPORT DATE: ${dateStr}`, pageWidth - margin, 12, { align: "right" });
  doc.text(`REF ID: #${project.id.slice(0, 8).toUpperCase()}`, pageWidth - margin, 18, {
    align: "right",
  });

  // Project Info Card
  let currentY = 36;
  doc.setTextColor(15, 23, 42);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text(project.name || "Untitled Electrical Project", margin, currentY);

  currentY += 5;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  const projectSub = [
    project.site ? `Site: ${project.site}` : null,
    project.customer ? `Client: ${project.customer}` : null,
    project.workOrder ? `Work Order: ${project.workOrder}` : null,
  ]
    .filter(Boolean)
    .join(" · ");
  doc.text(
    projectSub || "Itemized Engineering Report: Cable Runs Takeoff & Electrical Load Calculations",
    margin,
    currentY,
  );

  // --------------------------------------------------------------------------
  // Executive Summary KPI Tiles
  // --------------------------------------------------------------------------
  currentY += 8;
  const cardWidth = (pageWidth - margin * 2 - 9) / 4;
  const cardHeight = 17;

  const kpis = [
    {
      label: "TOTAL CABLE RUNS",
      value: `${cableData.totalLengthM.toFixed(1)} m`,
      sub: `${cableData.runs.length} routes recorded`,
      color: [59, 140, 255],
    },
    {
      label: "CONNECTED LOAD",
      value: `${loadData.totalConnectedKw.toFixed(2)} kW`,
      sub: `Across ${project.rooms.length} rooms`,
      color: [14, 116, 144],
    },
    {
      label: "FLOOR SURFACE",
      value: `${loadData.buildingAreaM2.toFixed(1)} m²`,
      sub: `${project.rooms.reduce((s, r) => s + r.points.length, 0)} points placed`,
      color: [100, 116, 139],
    },
    {
      label: "80% CAPACITY AUDIT",
      value: loadData.overloadedCount === 0 ? "100% OK" : `${loadData.overloadedCount} ROOMS >80%`,
      sub: loadData.overloadedCount === 0 ? "PUE 7.1 Compliant" : "Mitigation Required",
      color: loadData.overloadedCount === 0 ? [22, 163, 74] : [217, 119, 6],
    },
  ];

  kpis.forEach((kpi, idx) => {
    const cardX = margin + idx * (cardWidth + 3);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(cardX, currentY, cardWidth, cardHeight, 2, 2, "FD");

    // Indicator pill bar
    doc.setFillColor(kpi.color[0], kpi.color[1], kpi.color[2]);
    doc.rect(cardX, currentY, 2.5, cardHeight, "F");

    doc.setFont("helvetica", "bold");
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(kpi.label, cardX + 5, currentY + 4.5);

    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text(kpi.value, cardX + 5, currentY + 10.5);

    doc.setFontSize(6);
    doc.setTextColor(140, 150, 165);
    doc.text(kpi.sub, cardX + 5, currentY + 14.5);
  });

  currentY += cardHeight + 8;

  // --------------------------------------------------------------------------
  // SECTION 1: Itemized Room Load & Capacity Calculations
  // --------------------------------------------------------------------------
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(13, 27, 42);
  doc.text("1. ELECTRICAL LOAD & CIRCUIT CAPACITY AUDIT", margin, currentY);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(
    "Continuous load limit: 80% of circuit breaker rating per PUE 7.1 / NEC 210.19. Diversity factor Kc = 0.85 applied for multi-outlet runs.",
    margin,
    currentY + 4,
  );

  currentY += 6;

  const loadRows = loadData.loads.map((r) => [
    r.roomName,
    r.dimensionsStr,
    `${r.areaM2.toFixed(1)} m²`,
    String(r.pointsCount),
    `${r.outletsKw.toFixed(2)} kW`,
    `${r.lightsKw.toFixed(2)} kW`,
    `${r.totalLoadKw.toFixed(2)} kW`,
    `${r.capacityKw.toFixed(2)} kW`,
    `${r.ratioPercent.toFixed(1)}%`,
    r.complianceRule,
  ]);

  autoTable(doc, {
    startY: currentY,
    head: [
      [
        "Room Name",
        "Dimensions",
        "Area",
        "Pts",
        "Outlets",
        "Lights",
        "Total Load",
        "Breaker",
        "Load %",
        "Compliance Status (PUE 7.1)",
      ],
    ],
    body: loadRows,
    theme: "grid",
    headStyles: {
      fillColor: [16, 33, 55],
      textColor: [255, 255, 255],
      fontSize: 7.5,
      fontStyle: "bold",
      halign: "left",
      cellPadding: 2.2,
    },
    bodyStyles: {
      fontSize: 7,
      textColor: [30, 41, 59],
      cellPadding: 2,
    },
    columnStyles: {
      0: { cellWidth: 26, fontStyle: "bold" },
      1: { cellWidth: 24 },
      2: { cellWidth: 15, halign: "right" },
      3: { cellWidth: 10, halign: "center" },
      4: { cellWidth: 15, halign: "right" },
      5: { cellWidth: 14, halign: "right" },
      6: { cellWidth: 18, halign: "right", fontStyle: "bold" },
      7: { cellWidth: 16, halign: "right" },
      8: { cellWidth: 15, halign: "right", fontStyle: "bold" },
      9: { cellWidth: "auto", fontSize: 6.5 },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    didParseCell: (data) => {
      if (data.section === "body" && data.column.index === 8) {
        const text = String(data.cell.raw);
        const val = parseFloat(text);
        if (val >= 100) {
          data.cell.styles.textColor = [220, 38, 38]; // Red
        } else if (val >= 80) {
          data.cell.styles.textColor = [217, 119, 6]; // Amber
        } else {
          data.cell.styles.textColor = [22, 163, 74]; // Green
        }
      }
      if (data.section === "body" && data.column.index === 9) {
        const text = String(data.cell.raw);
        if (text.startsWith("FAIL")) {
          data.cell.styles.textColor = [220, 38, 38];
          data.cell.styles.fontStyle = "bold";
        } else if (text.startsWith("WARNING")) {
          data.cell.styles.textColor = [217, 119, 6];
          data.cell.styles.fontStyle = "bold";
        } else {
          data.cell.styles.textColor = [22, 163, 74];
        }
      }
    },
    margin: { left: margin, right: margin },
  });

  // --------------------------------------------------------------------------
  // SECTION 2: Itemized Cable Runs & Takeoff Table
  // --------------------------------------------------------------------------
  // Get Y position after previous table
  const lastTable = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable;
  currentY = (lastTable?.finalY ?? currentY) + 9;

  // Check if we need a page break before Section 2
  if (currentY > pageHeight - 65) {
    doc.addPage();
    currentY = 20;
  }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(13, 27, 42);
  doc.text("2. ITEMIZED CABLE RUNS & CONDUCTOR SIZING", margin, currentY);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(
    "Accurate routing takeoff with corner & elevation allowance. Minimum cross-sections specified per PUE 2.1.",
    margin,
    currentY + 4,
  );

  currentY += 6;

  const cableRows =
    cableData.runs.length > 0
      ? cableData.runs.map((r, i) => [
          String(i + 1).padStart(2, "0"),
          r.roomName,
          r.routeName,
          r.pointsDesc,
          `${r.planLengthM.toFixed(2)} m`,
          `+${r.allowancePercent}%`,
          `${r.cutLengthM.toFixed(2)} m`,
          `${r.estimatedLoadKw.toFixed(2)} kW`,
          r.recommendedCable,
        ])
      : [
          [
            "-",
            "No routes defined",
            "-",
            "Use Installation / Plan Takeoff editor to draw cable routes.",
            "-",
            "-",
            "0.00 m",
            "0.00 kW",
            "-",
          ],
        ];

  autoTable(doc, {
    startY: currentY,
    head: [
      [
        "#",
        "Room",
        "Route Name",
        "Linked Points Sequence",
        "Plan Run",
        "Allow.",
        "Cut Length",
        "Est. Load",
        "Recommended Cable Spec",
      ],
    ],
    body: cableRows,
    theme: "grid",
    headStyles: {
      fillColor: [16, 33, 55],
      textColor: [255, 255, 255],
      fontSize: 7.5,
      fontStyle: "bold",
      halign: "left",
      cellPadding: 2.2,
    },
    bodyStyles: {
      fontSize: 7,
      textColor: [30, 41, 59],
      cellPadding: 2,
    },
    columnStyles: {
      0: { cellWidth: 8, halign: "center" },
      1: { cellWidth: 22, fontStyle: "bold" },
      2: { cellWidth: 22 },
      3: { cellWidth: "auto", fontSize: 6.5 },
      4: { cellWidth: 16, halign: "right" },
      5: { cellWidth: 12, halign: "center" },
      6: { cellWidth: 18, halign: "right", fontStyle: "bold" },
      7: { cellWidth: 16, halign: "right" },
      8: { cellWidth: 38, fontStyle: "bold", textColor: [14, 116, 144] },
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    margin: { left: margin, right: margin },
  });

  // --------------------------------------------------------------------------
  // SECTION 3: Saved Engineering Calculations (if present)
  // --------------------------------------------------------------------------
  const lastTable2 = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable;
  currentY = (lastTable2?.finalY ?? currentY) + 9;

  if (project.calculations && project.calculations.length > 0) {
    if (currentY > pageHeight - 55) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(13, 27, 42);
    doc.text("3. SAVED ENGINEERING & CODE COMPLIANCE CALCULATIONS", margin, currentY);

    currentY += 6;

    const calcRows = project.calculations.map((c, i) => [
      String(i + 1).padStart(2, "0"),
      c.kind,
      c.expression,
      c.result,
      new Date(c.createdAt).toLocaleDateString(),
    ]);

    autoTable(doc, {
      startY: currentY,
      head: [["#", "Calculation Kind", "Formula & Input Expression", "Result", "Timestamp"]],
      body: calcRows,
      theme: "grid",
      headStyles: {
        fillColor: [16, 33, 55],
        textColor: [255, 255, 255],
        fontSize: 7.5,
        fontStyle: "bold",
        cellPadding: 2.2,
      },
      bodyStyles: {
        fontSize: 7,
        cellPadding: 2,
      },
      columnStyles: {
        0: { cellWidth: 8, halign: "center" },
        1: { cellWidth: 35, fontStyle: "bold" },
        2: { cellWidth: "auto" },
        3: { cellWidth: 32, fontStyle: "bold", textColor: [14, 116, 144] },
        4: { cellWidth: 22, halign: "right" },
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
      margin: { left: margin, right: margin },
    });
  }

  // --------------------------------------------------------------------------
  // Footer, Page Numbers, and Legal Disclaimer on all pages
  // --------------------------------------------------------------------------
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);

    // Bottom hairline separator
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 12, pageWidth - margin, pageHeight - 12);

    // Disclaimer
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      "ElectroVision AI PRO · Certified for preliminary field takeoff & estimation. All installations must be inspected by licensed electrical engineers.",
      margin,
      pageHeight - 8,
    );

    // Page Number
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, pageHeight - 8, { align: "right" });
  }

  return doc;
}

export function downloadItemizedPdfReport(project: Project): void {
  const doc = generateItemizedPdfReport(project);
  const fileName = `ElectroVision-Report-${slug(project.name)}-${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(fileName);
}
