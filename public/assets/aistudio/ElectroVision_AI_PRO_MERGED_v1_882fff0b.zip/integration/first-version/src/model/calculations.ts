export type CalcKind = "single" | "three" | "energy" | "drop" | "earthing" | "shortcircuit" | "imbalance";

export type CalcInput = {
  voltage: number;
  current: number;
  powerFactor: number;
  hours: number;
  days: number;
  length: number;
  area: number;
  material: "copper" | "aluminium";
  // Advanced fields
  soilResistivity?: number; // Ohm*m
  rodLength?: number; // m
  rodDiameter?: number; // mm
  networkPhase?: "single" | "three";
  loadPhaseA?: number; // kW or A
  loadPhaseB?: number;
  loadPhaseC?: number;
};

export type CalcOutput = {
  value: number;
  unit: string;
  formula: string;
  assumption: string;
  pueCompliance?: {
    status: "pass" | "warning" | "fail";
    text: string;
    recommendation: string;
  };
  details?: Array<{ label: string; value: string }>;
};

export function calculate(kind: CalcKind, v: CalcInput): CalcOutput {
  const positive = (n: number | undefined) => typeof n === "number" && Number.isFinite(n) && n > 0;

  if (kind === "single") {
    if (!positive(v.voltage) || !positive(v.current)) {
      throw Error("Kuchlanish va tok 0 dan katta bo'lishi kerak.");
    }
    const pf = v.powerFactor || 0.9;
    const pKw = (v.voltage * v.current * pf) / 1000;
    const sKva = (v.voltage * v.current) / 1000;
    const qKvar = Math.sqrt(Math.max(0, sKva * sKva - pKw * pKw));

    return {
      value: pKw,
      unit: "kW",
      formula: "P = V × I × cos φ ÷ 1000",
      assumption: "Bir fazali aktiv quvvat (220V/230V RMS). cos φ = " + pf,
      details: [
        { label: "Aktiv quvvat (P)", value: `${pKw.toFixed(2)} kW` },
        { label: "To'liq quvvat (S)", value: `${sKva.toFixed(2)} kVA` },
        { label: "Reaktiv quvvat (Q)", value: `${qKvar.toFixed(2)} kVAr` },
        { label: "Tavsiya etilgan avtomat", value: `${Math.ceil(v.current * 1.15)}A (C yoki B xarakteristika)` },
      ],
    };
  }

  if (kind === "three") {
    if (!positive(v.voltage) || !positive(v.current)) {
      throw Error("Chiziqli kuchlanish (380V/400V) va tok 0 dan katta bo'lishi kerak.");
    }
    const pf = v.powerFactor || 0.85;
    const pKw = (Math.sqrt(3) * v.voltage * v.current * pf) / 1000;
    const sKva = (Math.sqrt(3) * v.voltage * v.current) / 1000;

    return {
      value: pKw,
      unit: "kW",
      formula: "P = √3 × V_chiziqli × I × cos φ ÷ 1000",
      assumption: "Simmetrik uch fazali yuklama (380V/400V). cos φ = " + pf,
      details: [
        { label: "Aktiv quvvat (P)", value: `${pKw.toFixed(2)} kW` },
        { label: "To'liq quvvat (S)", value: `${sKva.toFixed(2)} kVA` },
        { label: "Fazadagi tok (I)", value: `${v.current.toFixed(1)} A` },
        { label: "Tavsiya etilgan 3P avtomat", value: `${Math.ceil(v.current * 1.2)}A (3 qutbli)` },
      ],
    };
  }

  if (kind === "energy") {
    if (!positive(v.hours) || !positive(v.days) || v.hours > 24 || v.days > 366) {
      throw Error("0–24 soat/kun va 1–366 kun oraliqda kiriting.");
    }
    const energyKwh = (v.voltage * v.current * v.hours * v.days * (v.powerFactor || 0.9)) / 1000;
    return {
      value: energyKwh,
      unit: "kWh",
      formula: "E = V × I × cos φ × soat/kun × kunlar ÷ 1000",
      assumption: "Davr davomidagi umumiy elektr energiya sarfi (kVt·soat).",
      details: [
        { label: "Kunlik sarf", value: `${(energyKwh / v.days).toFixed(2)} kWh/kun` },
        { label: "Oylik o'rtacha (30 kun)", value: `${((energyKwh / v.days) * 30).toFixed(1)} kWh` },
      ],
    };
  }

  if (kind === "drop") {
    if (!positive(v.length) || !positive(v.area)) {
      throw Error("Kabel uzunligi va kesimi 0 dan katta bo'lishi kerak.");
    }
    const rho = v.material === "copper" ? 0.0175 : 0.0282; // Ohm * mm^2 / m
    const pf = v.powerFactor || 0.95;
    const factor = v.networkPhase === "three" ? Math.sqrt(3) : 2;
    const dropV = (factor * rho * v.length * v.current * pf) / v.area;
    const dropPercent = (dropV / v.voltage) * 100;

    const status: "pass" | "warning" | "fail" =
      dropPercent <= 3.5 ? "pass" : dropPercent <= 5.0 ? "warning" : "fail";

    return {
      value: dropV,
      unit: "V",
      formula:
        v.networkPhase === "three"
          ? "ΔV = √3 × ρ × L × I × cos φ ÷ S"
          : "ΔV = 2 × ρ × L × I × cos φ ÷ S",
      assumption: `${v.material === "copper" ? "Mis (Cu)" : "Alyuminiy (Al)"} o'tkazgich, 20°C haroratda. Ruxsat etilgan PUE me'yori: ≤5.0%`,
      pueCompliance: {
        status,
        text: `Kuchlanish pasayishi: ${dropPercent.toFixed(2)}% (${dropV.toFixed(2)}V)`,
        recommendation:
          status === "pass"
            ? "PUE talablariga to'liq javob beradi (5% dan kam)."
            : status === "warning"
              ? "Chegara darajasida (3.5% - 5.0%). Kabel kesimini bir pog'ona kattalashtirish tavsiya etiladi."
              : "PUE 7.1. normasi buzilgan (>5%). Zudlik bilan kabel kesimini kattalashtiring!",
      },
      details: [
        { label: "Kuchlanish tushishi (V)", value: `${dropV.toFixed(2)} V` },
        { label: "Kuchlanish tushishi (%)", value: `${dropPercent.toFixed(2)} %` },
        { label: "Iste'molchidagi kuchlanish", value: `${(v.voltage - dropV).toFixed(1)} V` },
        { label: "Solishtirma qarshilik (ρ)", value: `${rho} Ω·mm²/m` },
      ],
    };
  }

  if (kind === "earthing") {
    const rho = v.soilResistivity || 100; // Ohm*m (loam)
    const L = v.rodLength || 2.5; // m
    const d = (v.rodDiameter || 16) / 1000; // m
    const tDepth = 0.8; // bury depth to rod top (m)

    // Formula for single vertical rod: R = (rho / (2 * pi * L)) * (ln(2L/d) + 0.5 * ln((4T + L)/(4T - L)))
    const T = tDepth + L / 2;
    const term1 = Math.log((2 * L) / d);
    const term2 = 0.5 * Math.log((4 * T + L) / (4 * T - L));
    const rSingle = (rho / (2 * Math.PI * L)) * (term1 + term2);

    const target = 4.0; // PUE standard for 220/380V <= 4 Ohm
    const rodsNeeded = Math.max(1, Math.ceil(rSingle / (target * 0.85))); // accounting for screening factor

    return {
      value: rSingle,
      unit: "Ω",
      formula: "R = (ρ ÷ 2πL) × [ln(2L/d) + 0.5 ln((4T+L)/(4T-L))]",
      assumption: `Grunt: ρ = ${rho} Ω·m, L = ${L} m, Ø = ${v.rodDiameter || 16} mm. PUE talabi: R ≤ 4.0 Om`,
      pueCompliance: {
        status: rSingle <= 4.0 ? "pass" : "warning",
        text: `1 ta elektrod qarshiligi: ${rSingle.toFixed(1)} Ω`,
        recommendation:
          rSingle <= 4.0
            ? "1 ta elektrod 4 Om lik PUE me'yorini ta'minlaydi."
            : `4 Om ga erishish uchun kamida ${rodsNeeded} ta elektrodni 3 metr masofada uchburchak qilib ulash zarur.`,
      },
      details: [
        { label: "1 ta elektrod qarshiligi", value: `${rSingle.toFixed(2)} Ω` },
        { label: "PUE me'yori (220/380V)", value: "≤ 4.0 Ω" },
        { label: "Tavsiya etilgan elektrodlar soni", value: `${rodsNeeded} dona` },
        { label: "Ulanish polosasi", value: "Po'lat lenta 40x4 mm" },
      ],
    };
  }

  if (kind === "shortcircuit") {
    // Single phase short circuit at the end of line
    const rho = v.material === "copper" ? 0.0175 : 0.0282;
    const rLoop = (2 * rho * (v.length || 20)) / (v.area || 2.5); // Ohms
    const rTransformer = 0.05; // ~0.05 ohm typical upstream grid impedance
    const zTotal = Math.hypot(rLoop + rTransformer, 0.04);
    const ikz = v.voltage / zTotal;

    const bTrip = v.current * 5; // B curve trips at 3-5 In
    const cTrip = v.current * 10; // C curve trips at 5-10 In
    const safeForC = ikz >= cTrip;
    const safeForB = ikz >= bTrip;

    return {
      value: ikz,
      unit: "A",
      formula: "I_kz = V ÷ Z_halqa",
      assumption: `L = ${v.length} m, S = ${v.area} mm², V = ${v.voltage} V. Halqa qarshiligi: ${zTotal.toFixed(3)} Ω`,
      pueCompliance: {
        status: safeForC ? "pass" : safeForB ? "warning" : "fail",
        text: `Bir fazali qisqa tutashuv toki: ${ikz.toFixed(0)} A`,
        recommendation: safeForC
          ? `Tok C${v.current} avtomati lahzali o'chirish chegarasidan (${cTrip}A) yuqori. Avtomat ishonchli o'chadi.`
          : safeForB
            ? `C${v.current} avtomat uchun tok yetarli emas. B${v.current} avtomat o'rnatish lozim.`
            : `Xavfli! Qisqa tutashuv toki past (${ikz.toFixed(0)}A). Kabel kesimini oshiring yoki UZO qo'ying.`,
      },
      details: [
        { label: "Qisqa tutashuv toki (Ik.z)", value: `${ikz.toFixed(0)} A` },
        { label: "Kabel halqa qarshiligi", value: `${rLoop.toFixed(3)} Ω` },
        { label: "B xarakteristika chegarasi", value: `${bTrip} A` },
        { label: "C xarakteristika chegarasi", value: `${cTrip} A` },
      ],
    };
  }

  // Fallback
  return {
    value: 0,
    unit: "",
    formula: "",
    assumption: "",
  };
}
