import type { CableRoute, Opening, Room, WallSide } from "./project";
export const wallLength = (room: Room, wall: WallSide) =>
  wall === "north" || wall === "south" ? room.length : room.width;
export function openingError(room: Room, opening: Opening, ignoreId?: string): string {
  const length = wallLength(room, opening.wall);
  if (![opening.offset, opening.width, opening.height, opening.sill].every(Number.isFinite))
    return "Enter finite measurements.";
  if (opening.width <= 0 || opening.height <= 0 || opening.offset < 0 || opening.sill < 0)
    return "Opening width and height must be positive; offset and sill cannot be negative.";
  if (opening.offset + opening.width > length + 1e-6)
    return `Opening exceeds the ${opening.wall} wall (${length} m).`;
  if (opening.sill + opening.height > room.height + 1e-6) return "Opening exceeds the wall height.";
  if (
    (room.openings ?? []).some(
      (other) =>
        other.id !== ignoreId &&
        other.wall === opening.wall &&
        opening.offset < other.offset + other.width - 1e-6 &&
        other.offset < opening.offset + opening.width - 1e-6,
    )
  )
    return "This opening overlaps another on the same wall.";
  return "";
}
export function routeLength(room: Room, route: CableRoute): number | null {
  const points = routePath(room, route);
  if (!points) return null;
  let length = 0;
  for (let i = 1; i < points.length; i++) {
    const previous = points[i - 1]!,
      current = points[i]!;
    length += Math.hypot(
      (current.x - previous.x) * room.length,
      (current.y - previous.y) * room.width,
    );
  }
  return length * (1 + route.allowance / 100);
}

export function routePath(room: Room, route: CableRoute): { x: number; y: number }[] | null {
  const points = route.pointIds.map((id) => room.points.find((p) => p.id === id));
  if (points.length < 2 || points.some((p) => !p)) return null;
  if (!route.waypoints?.length) return points as { x: number; y: number }[];
  return [points[0]!, ...route.waypoints, ...points.slice(1)] as { x: number; y: number }[];
}
/** First offset (0.1 m steps) where an opening of `width` fits on the wall without overlapping others; null if none. */
export function firstFreeOffset(room: Room, wall: WallSide, width: number): number | null {
  const length = wallLength(room, wall);
  for (let step = 0; step * 0.1 + width <= length + 1e-6; step++) {
    const offset = Math.round(step * 10) / 100;
    const clash = (room.openings ?? []).some(
      (o) => o.wall === wall && offset < o.offset + o.width - 1e-6 && o.offset < offset + width - 1e-6,
    );
    if (!clash) return offset;
  }
  return null;
}
/** Total plan length of all valid cable routes in a room, in metres. */
export const totalRouteLength = (room: Room) =>
  (room.routes ?? []).reduce((sum, route) => sum + (routeLength(room, route) ?? 0), 0);
