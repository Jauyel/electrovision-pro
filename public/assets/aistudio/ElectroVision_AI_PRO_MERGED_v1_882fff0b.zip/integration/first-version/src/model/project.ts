export type PointKind = "outlet" | "switch" | "light" | "panel" | "junction";
export type Point = {
  id: string;
  kind: PointKind;
  x: number;
  y: number;
  label: string;
  powerKw?: number;
};
export type WallSide = "north" | "south" | "east" | "west";
export type Opening = {
  id: string;
  kind: "door" | "window";
  wall: WallSide;
  offset: number;
  width: number;
  height: number;
  sill: number;
  label: string;
};
export type RoomPhoto = {
  id: string;
  image: string;
  capturedAt: string;
  note: string;
  source: "camera" | "upload";
};
export type CableRoute = {
  id: string;
  name: string;
  pointIds: string[];
  allowance: number;
  waypoints?: { x: number; y: number }[];
};
export type Room = {
  id: string;
  name: string;
  length: number;
  width: number;
  height: number;
  points: Point[];
  note: string;
  wallThickness?: number;
  floorElevation?: number;
  openings?: Opening[];
  photos?: RoomPhoto[];
  routes?: CableRoute[];
  maxCapacityKw?: number;
};

export type RoomLoadStatus = {
  totalLoadKw: number;
  capacityKw: number;
  ratioPercent: number;
  isOver80: boolean;
  isOver100: boolean;
  status: "optimal" | "moderate" | "warning" | "critical";
  colorHex: string;
  colorName: string;
  statusLabel: { uz: string; ru: string; en: string };
  breakdown: {
    outletsKw: number;
    hvacKw: number;
    lightsKw: number;
    otherKw: number;
    pointsCount: number;
  };
};

export function isHvacPoint(point: Point): boolean {
  const label = (point.label || "").toLowerCase();
  return /konditsioner|konditsaner|ac|air|klimat|boiler|boyler|isitgich|heater|fan|vent|radiator|cooling|heating|ventilyatsiya/i.test(
    label
  );
}

export function getPointPowerKw(point: Point): number {
  if (typeof point.powerKw === "number" && point.powerKw >= 0) {
    return point.powerKw;
  }
  const label = (point.label || "").toLowerCase();
  if (point.kind === "outlet") {
    if (/plita|pech|duxovka|oven|cooktop|stove/i.test(label)) return 2.5;
    if (/konditsioner|konditsaner|ac|air|klimat/i.test(label)) return 1.8;
    if (/boiler|boyler|isitgich|heater/i.test(label)) return 2.0;
    if (/kir|stiral|washer/i.test(label)) return 1.5;
    if (/muzlatgich|xolodilnik|fridge/i.test(label)) return 0.5;
    return 0.6; // standard duplex outlet (0.6 kW)
  }
  if (point.kind === "light") {
    if (/lyustra|asosiy|chandelier/i.test(label)) return 0.25;
    return 0.12; // LED fixture / spot
  }
  if (point.kind === "switch") {
    return 0.02;
  }
  if (point.kind === "junction") {
    return 0.05;
  }
  return 0; // panel
}

export function calculateRoomLoad(room: Room): RoomLoadStatus {
  // Standard residential 16A circuit breaker at 230V provides 3.68 kW max continuous capacity
  const capacityKw = room.maxCapacityKw && room.maxCapacityKw > 0 ? room.maxCapacityKw : 3.68;
  let outletsKw = 0;
  let hvacKw = 0;
  let lightsKw = 0;
  let otherKw = 0;
  let generalOutletCount = 0;

  for (const pt of room.points) {
    const power = getPointPowerKw(pt);
    if (isHvacPoint(pt)) {
      hvacKw += power;
    } else if (pt.kind === "outlet") {
      outletsKw += power;
      generalOutletCount++;
    } else if (pt.kind === "light") {
      lightsKw += power;
    } else {
      otherKw += power;
    }
  }

  // Electrical diversity / demand factor (PUE / IEC standard: outlets have diversity factor Kc = 0.85 when >2 outlets)
  const diversifiedOutlets = outletsKw > 0 ? outletsKw * (generalOutletCount > 2 ? 0.85 : 1.0) : 0;
  const rawTotal = diversifiedOutlets + hvacKw + lightsKw + otherKw;
  const totalLoadKw = Math.round(rawTotal * 100) / 100;

  const ratioPercent = Math.round((totalLoadKw / capacityKw) * 1000) / 10;
  const isOver80 = ratioPercent >= 80;
  const isOver100 = ratioPercent >= 100;

  let status: "optimal" | "moderate" | "warning" | "critical" = "optimal";
  let colorHex = "#37c99b"; // Green / Emerald
  let colorName = "emerald";

  if (isOver100) {
    status = "critical";
    colorHex = "#f47785"; // Red / Danger
    colorName = "danger";
  } else if (isOver80) {
    status = "warning";
    colorHex = "#e9b663"; // Amber
    colorName = "amber";
  } else if (ratioPercent >= 55) {
    status = "moderate";
    colorHex = "#4bc8dc"; // Cyan
    colorName = "cyan";
  }

  return {
    totalLoadKw,
    capacityKw,
    ratioPercent,
    isOver80,
    isOver100,
    status,
    colorHex,
    colorName,
    statusLabel: {
      uz: isOver100
        ? "O'ta yuklama (>100%)"
        : isOver80
          ? "Yuqori yuklama (>80%)"
          : ratioPercent >= 55
            ? "O'rtacha yuklama"
            : "Optimal yuklama",
      ru: isOver100
        ? "Перегрузка (>100%)"
        : isOver80
          ? "Высокая нагрузка (>80%)"
          : ratioPercent >= 55
            ? "Умеренная нагрузка"
            : "Оптимальная нагрузка",
      en: isOver100
        ? "Overload (>100%)"
        : isOver80
          ? "High Load (>80%)"
          : ratioPercent >= 55
            ? "Moderate Load"
            : "Optimal Load",
    },
    breakdown: {
      outletsKw: Math.round(outletsKw * 100) / 100,
      hvacKw: Math.round(hvacKw * 100) / 100,
      lightsKw: Math.round(lightsKw * 100) / 100,
      otherKw: Math.round(otherKw * 100) / 100,
      pointsCount: room.points.length,
    },
  };
}
export type EstimateItem = {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  price: number;
  waste: number;
  labor: number;
};
export type Calculation = {
  id: string;
  kind: string;
  expression: string;
  result: string;
  createdAt: string;
};
export type PanelDevice = {
  id: string;
  name: string;
  modules: number;
  kind: string;
  poles?: number;
  manufacturer?: string;
  model?: string;
  unitPrice?: number;
};
export type Project = {
  id: string;
  name: string;
  description: string;
  type: string;
  status: "planning" | "in-progress" | "completed";
  createdAt: string;
  updatedAt: string;
  rooms: Room[];
  estimates: EstimateItem[];
  calculations: Calculation[];
  panel: PanelDevice[];
  notes: string;
  customer: string;
  site: string;
  workOrder: string;
  currency: "UZS" | "USD" | "RUB";
  contingency: number;
};
export type Theme = "dark" | "light";

export type Database = {
  version: 1;
  projects: Project[];
  activeId: string | null;
  language: "uz" | "ru" | "en";
  theme?: Theme;
};
/** crypto.randomUUID needs a secure context (HTTPS/localhost); fall back so plain-HTTP LAN use still works. */
export function newId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function")
    return crypto.randomUUID();
  const bytes = new Uint8Array(16);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) crypto.getRandomValues(bytes);
  else for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  bytes[6] = (bytes[6]! & 0x0f) | 0x40;
  bytes[8] = (bytes[8]! & 0x3f) | 0x80;
  const hex = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
/** File-name safe slug that keeps Cyrillic/Latin letters and digits. */
export const slug = (text: string, fallback = "project") =>
  text.trim().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-+|-+$/g, "").slice(0, 60) || fallback;
/** One CSV cell, quoted, with spreadsheet formula injection neutralised. */
export function csvCell(value: string | number): string {
  let text = String(value);
  if (/^[=+\-@\t\r]/.test(text) && typeof value === "string") text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}
export const makeProject = (name: string): Project => ({
  id: newId(),
  name: name.trim(),
  description: "",
  type: "Residential",
  status: "planning",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  rooms: [],
  estimates: [],
  calculations: [],
  panel: [],
  notes: "",
  customer: "",
  site: "",
  workOrder: "",
  currency: "UZS",
  contingency: 0,
});
export const makeRoom = (name: string): Room => ({
  id: newId(),
  name: name.trim(),
  length: 5,
  width: 4,
  height: 2.8,
  points: [],
  note: "",
  wallThickness: 0.16,
  floorElevation: 0,
  openings: [],
  photos: [],
  routes: [],
});
const KEY = "electrovision.projects.v1";
export const emptyDatabase = (): Database => ({
  version: 1,
  projects: [],
  activeId: null,
  language: "uz",
  theme: "dark",
});
export function validDatabase(value: unknown): value is Database {
  if (!value || typeof value !== "object") return false;
  const v = value as Partial<Database>;
  const text = (input: unknown) => typeof input === "string";
  const nonnegative = (input: unknown) =>
    typeof input === "number" && Number.isFinite(input) && input >= 0;
  const positive = (input: unknown) => nonnegative(input) && (input as number) > 0;
  return (
    v.version === 1 &&
    ["uz", "ru", "en"].includes(v.language ?? "") &&
    (v.theme === undefined || ["dark", "light"].includes(v.theme)) &&
    (v.activeId === null || typeof v.activeId === "string") &&
    Array.isArray(v.projects) &&
    v.projects.length <= 10000 &&
    v.projects.every(
      (p) =>
        p !== null &&
        typeof p === "object" &&
        typeof p.id === "string" &&
        text(p.name) &&
        text(p.description) &&
        text(p.type) &&
        text(p.createdAt) &&
        text(p.updatedAt) &&
        ["planning", "in-progress", "completed"].includes(p.status) &&
        text(p.notes) &&
        text(p.customer) &&
        text(p.site) &&
        text(p.workOrder) &&
        ["UZS", "USD", "RUB"].includes(p.currency) &&
        nonnegative(p.contingency) &&
        p.contingency <= 100 &&
        Array.isArray(p.rooms) &&
        p.rooms.every(
          (r) =>
            r !== null &&
            typeof r === "object" &&
            typeof r.id === "string" &&
            text(r.name) &&
            text(r.note) &&
            positive(r.length) &&
            positive(r.width) &&
            positive(r.height) &&
            (r.wallThickness === undefined ||
              (positive(r.wallThickness) && r.wallThickness <= 0.6)) &&
            (r.floorElevation === undefined || nonnegative(r.floorElevation)) &&
            (r.maxCapacityKw === undefined ||
              (positive(r.maxCapacityKw) && r.maxCapacityKw <= 100)) &&
            (r.openings === undefined ||
              (Array.isArray(r.openings) &&
                r.openings.every(
                  (o) =>
                    o !== null &&
                    typeof o === "object" &&
                    text(o.id) &&
                    text(o.label) &&
                    ["door", "window"].includes(o.kind) &&
                    ["north", "south", "east", "west"].includes(o.wall) &&
                    nonnegative(o.offset) &&
                    positive(o.width) &&
                    positive(o.height) &&
                    nonnegative(o.sill) &&
                    o.offset + o.width <=
                      (["north", "south"].includes(o.wall) ? r.length : r.width) + 0.00001 &&
                    o.sill + o.height <= r.height + 0.00001,
                ))) &&
            (r.photos === undefined ||
              (Array.isArray(r.photos) &&
                r.photos.length <= 8 &&
                r.photos.every(
                  (photo) =>
                    photo !== null &&
                    typeof photo === "object" &&
                    text(photo.id) &&
                    text(photo.capturedAt) &&
                    text(photo.note) &&
                    ["camera", "upload"].includes(photo.source) &&
                    typeof photo.image === "string" &&
                    /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(photo.image) &&
                    photo.image.length < 450000,
                ))) &&
            (r.routes === undefined ||
              (Array.isArray(r.routes) &&
                r.routes.every(
                  (route) =>
                    route !== null &&
                    typeof route === "object" &&
                    text(route.id) &&
                    text(route.name) &&
                    Array.isArray(route.pointIds) &&
                    route.pointIds.every(text) &&
                    (route.waypoints === undefined ||
                      (Array.isArray(route.waypoints) &&
                        route.waypoints.every(
                          (w) =>
                            w !== null &&
                            typeof w === "object" &&
                            nonnegative(w.x) &&
                            w.x <= 1 &&
                            nonnegative(w.y) &&
                            w.y <= 1,
                        ))) &&
                    nonnegative(route.allowance) &&
                    route.allowance <= 100,
                ))) &&
            Array.isArray(r.points) &&
            r.points.every(
              (point) =>
                point !== null &&
                typeof point === "object" &&
                text(point.id) &&
                text(point.label) &&
                ["outlet", "switch", "light", "panel", "junction"].includes(point.kind) &&
                nonnegative(point.x) &&
                point.x <= 1 &&
                nonnegative(point.y) &&
                point.y <= 1 &&
                (point.powerKw === undefined ||
                  (nonnegative(point.powerKw) && point.powerKw <= 50)),
            ),
        ) &&
        Array.isArray(p.estimates) &&
        p.estimates.every(
          (item) =>
            item !== null &&
            typeof item === "object" &&
            text(item.id) &&
            text(item.name) &&
            text(item.category) &&
            text(item.unit) &&
            nonnegative(item.quantity) &&
            nonnegative(item.price) &&
            nonnegative(item.waste) &&
            nonnegative(item.labor),
        ) &&
        Array.isArray(p.calculations) &&
        p.calculations.every(
          (c) =>
            c !== null &&
            typeof c === "object" &&
            text(c.id) &&
            text(c.kind) &&
            text(c.expression) &&
            text(c.result) &&
            text(c.createdAt),
        ) &&
        Array.isArray(p.panel) &&
        p.panel.every(
          (d) =>
            d !== null &&
            typeof d === "object" &&
            text(d.id) &&
            text(d.name) &&
            text(d.kind) &&
            positive(d.modules) &&
            (d.poles === undefined || positive(d.poles)) &&
            (d.manufacturer === undefined || text(d.manufacturer)) &&
            (d.model === undefined || text(d.model)) &&
            (d.unitPrice === undefined || nonnegative(d.unitPrice)),
        ),
    )
  );
}
export function loadDatabase(): { data: Database; warning: string } {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { data: emptyDatabase(), warning: "" };
    const parsed: unknown = JSON.parse(raw);
    if (validDatabase(parsed)) return { data: parsed, warning: "" };
    const kept = keepUnreadable(raw);
    return {
      data: emptyDatabase(),
      warning: kept
        ? "Saved data could not be validated. The original was kept separately; open Settings → Recover unreadable data to download it."
        : "Saved data could not be validated and a recovery copy could not be made. Do not edit before copying browser storage manually.",
    };
  } catch {
    const raw = readRaw();
    if (raw) keepUnreadable(raw);
    return {
      data: emptyDatabase(),
      warning:
        "Browser storage is unavailable or the saved data is damaged. Changes may not persist.",
    };
  }
}
const RECOVERY_PREFIX = `${KEY}.unreadable.`;
function readRaw(): string | null {
  try {
    return localStorage.getItem(KEY);
  } catch {
    return null;
  }
}
/** Copies unreadable saved data to a separate key so the next save cannot destroy it. */
function keepUnreadable(raw: string): boolean {
  try {
    localStorage.setItem(`${RECOVERY_PREFIX}${Date.now()}`, raw);
    return true;
  } catch {
    return false;
  }
}
export function recoveryDumps(): { key: string; size: number; savedAt: string }[] {
  try {
    const found: { key: string; size: number; savedAt: string }[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key?.startsWith(RECOVERY_PREFIX)) continue;
      const stamp = Number(key.slice(RECOVERY_PREFIX.length));
      found.push({
        key,
        size: localStorage.getItem(key)?.length ?? 0,
        savedAt: Number.isFinite(stamp) ? new Date(stamp).toISOString() : "",
      });
    }
    return found.sort((a, b) => b.savedAt.localeCompare(a.savedAt));
  } catch {
    return [];
  }
}
export const readRecovery = (key: string) => {
  try {
    return key.startsWith(RECOVERY_PREFIX) ? localStorage.getItem(key) : null;
  } catch {
    return null;
  }
};
export function saveDatabase(data: Database) {
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
    return true;
  } catch {
    return false;
  }
}
export function downloadFile(name: string, contents: string, mime = "application/json") {
  const url = URL.createObjectURL(new Blob([contents], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function safeNumber(text: string, min = 0, max = 1e12) {
  const n = Number(text);
  return text.trim() !== "" && Number.isFinite(n) && n >= min && n <= max ? n : null;
}
export function estimateTotals(items: EstimateItem[], contingency: number) {
  const material = items.reduce((sum, x) => sum + x.quantity * x.price * (1 + x.waste / 100), 0);
  const labor = items.reduce((sum, x) => sum + x.quantity * x.labor, 0);
  const reserve = ((material + labor) * contingency) / 100;
  return { material, labor, reserve, total: material + labor + reserve };
}
/**
 * Adds suggested lines to an estimate without duplicating earlier suggestions: a line with the same name
 * and category has its quantity (and price when given) refreshed instead of being added again.
 */
export function mergeEstimateItems(existing: EstimateItem[], incoming: EstimateItem[]): EstimateItem[] {
  const result = [...existing];
  for (const item of incoming) {
    const at = result.findIndex((x) => x.name === item.name && x.category === item.category);
    if (at < 0) result.push(item);
    else
      result[at] = {
        ...result[at]!,
        quantity: item.quantity,
        unit: item.unit,
        price: item.price > 0 ? item.price : result[at]!.price,
      };
  }
  return result;
}
