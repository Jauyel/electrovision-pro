import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { makeProject, loadDatabase, saveDatabase, type Database, type Project, type Theme } from "./project";
import { words, type Word } from "./i18n";

type Store = {
  db: Database;
  project: Project | null;
  warning: string;
  saved: boolean;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  t: (key: Word) => string;
  setLanguage: (lang: Database["language"]) => void;
  choose: (id: string | null) => void;
  addProject: (name: string) => Project;
  update: (id: string, edit: (p: Project) => Project) => void;
  remove: (id: string) => void;
  replace: (db: Database) => void;
};

const Context = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [initial] = useState(loadDatabase);
  const [db, setDb] = useState(initial.data);
  const [warning, setWarning] = useState(initial.warning);
  const [saved, setSaved] = useState(true);

  // Several updates can run inside one event (add + edit, duplicate...). Reading `db` from the render
  // closure would drop all but the last one, so every change is applied to this always-current copy.
  const latest = useRef(initial.data);

  const activeTheme: Theme = db.theme || "dark";

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", activeTheme);
    document.documentElement.className = activeTheme === "light" ? "theme-light" : "theme-dark";
    document.body.className =
      activeTheme === "light"
        ? "theme-light bg-[#f4f7fb] text-[#0f172a] antialiased selection:bg-[#0066cc] selection:text-white"
        : "theme-dark bg-[#07111f] text-[#f1f6fc] antialiased selection:bg-[#3b8cff] selection:text-white";
  }, [activeTheme]);

  const commit = (next: Database) => {
    latest.current = next;
    setDb(next);
    setSaved(saveDatabase(next));
    setWarning("");
  };

  const setTheme = (theme: Theme) => {
    commit({ ...latest.current, theme });
  };

  const addProject = (name: string) => {
    const project = makeProject(name);
    const base = latest.current;
    commit({ ...base, projects: [project, ...base.projects], activeId: project.id });
    return project;
  };

  const update = (id: string, edit: (p: Project) => Project) => {
    const base = latest.current;
    commit({
      ...base,
      projects: base.projects.map((p) =>
        p.id === id ? { ...edit(p), updatedAt: new Date().toISOString() } : p,
      ),
    });
  };

  const remove = (id: string) => {
    const base = latest.current;
    commit({
      ...base,
      projects: base.projects.filter((p) => p.id !== id),
      activeId: base.activeId === id ? null : base.activeId,
    });
  };

  return (
    <Context.Provider
      value={{
        db,
        project: db.projects.find((p) => p.id === db.activeId) ?? null,
        warning,
        saved,
        theme: activeTheme,
        setTheme,
        t: (key) => words[db.language][key],
        setLanguage: (lang) => commit({ ...latest.current, language: lang }),
        choose: (id) => commit({ ...latest.current, activeId: id }),
        addProject,
        update,
        remove,
        replace: (next) => commit(next),
      }}
    >
      {children}
    </Context.Provider>
  );
}

export function useStore() {
  const value = useContext(Context);
  if (!value) throw Error("StoreProvider missing");
  return value;
}
