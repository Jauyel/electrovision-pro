import { useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Calculator,
  CheckCircle2,
  FileText,
  Save,
  ShieldCheck,
  Trash2,
  Zap,
} from "lucide-react";
import { Panel, ProjectGate, SectionHead } from "../components/shell";
import { calculate, type CalcKind, type CalcInput, type CalcOutput } from "../model/calculations";
import { downloadItemizedPdfReport } from "../lib/pdf-report";
import { newId } from "../model/project";
import { useStore } from "../model/store";

const kinds: { key: CalcKind; name: string; sub: string; icon: string }[] = [
  { key: "drop", name: "Kuchlanish tushishi & Kabel kesimi", sub: "PUE 7.1 · ΔV% va kabel tekshiruvi", icon: "⚡" },
  { key: "single", name: "1 fazali quvvat & Tok", sub: "P = V × I × cos φ", icon: "🔌" },
  { key: "three", name: "3 fazali quvvat (380V)", sub: "P = √3 × V × I × cos φ", icon: "🏢" },
  { key: "earthing", name: "Yerga ulash (Zazemleniye)", sub: "PUE 1.7 · R ≤ 4.0 Om konturi", icon: "🌱" },
  { key: "shortcircuit", name: "Qisqa tutashuv toki (Ik.z)", sub: "Avtomat o'chish tezligi va xavfsizlik", icon: "💥" },
  { key: "energy", name: "Elektr energiya sarfi", sub: "E = P × t (kVt·soat)", icon: "📊" },
];

const soilTypes = [
  { name: "Qoratuproq / Botqoqlik (30 Ω·m)", value: 30 },
  { name: "Qumloq tuproq / Gil (100 Ω·m)", value: 100 },
  { name: "Oddiy loytuproq (150 Ω·m)", value: 150 },
  { name: "Qumloq quruq tuproq (300 Ω·m)", value: 300 },
  { name: "Toshloq / Qoyatosh (1000 Ω·m)", value: 1000 },
];

export default function Calculations() {
  const { project, update, t } = useStore();
  const [kind, setKind] = useState<CalcKind>("drop");
  const [values, setValues] = useState<Record<string, any>>({
    voltage: "230",
    current: "16",
    powerFactor: "0.95",
    hours: "8",
    days: "30",
    length: "25",
    area: "2.5",
    material: "copper",
    soilResistivity: 100,
    rodLength: "2.5",
    rodDiameter: "16",
    networkPhase: "single",
  });
  const [result, setResult] = useState<CalcOutput | null>(null);
  const [error, setError] = useState("");

  function run() {
    setError("");
    try {
      const parsed: CalcInput = {
        voltage: Number(values.voltage) || 230,
        current: Number(values.current) || 10,
        powerFactor: Number(values.powerFactor) || 0.95,
        hours: Number(values.hours) || 8,
        days: Number(values.days) || 30,
        length: Number(values.length) || 20,
        area: Number(values.area) || 2.5,
        material: values.material as "copper" | "aluminium",
        soilResistivity: Number(values.soilResistivity) || 100,
        rodLength: Number(values.rodLength) || 2.5,
        rodDiameter: Number(values.rodDiameter) || 16,
        networkPhase: values.networkPhase as "single" | "three",
      };

      const out = calculate(kind, parsed);
      setResult(out);
    } catch (e: any) {
      setError(e.message || "Hisoblashda xatolik yuz berdi");
      setResult(null);
    }
  }

  function saveToProject() {
    if (!project || !result) return;
    const calcItem = {
      id: newId(),
      kind: kinds.find((k) => k.key === kind)?.name || kind,
      expression: result.formula,
      result: `${result.value.toFixed(2)} ${result.unit}`,
      createdAt: new Date().toISOString(),
    };
    update(project.id, (p) => ({
      ...p,
      calculations: [calcItem, ...p.calculations],
    }));
  }

  return (
    <>
      <SectionHead
        eyebrow="ENGINEERING SUITE / 04"
        title={t("cad")}
        description="PUE (ПУЭ), GOST va IEC 60364 standartlariga mos elektrotexnik hisob-kitoblar. Barcha natijalarni loyiha pasportiga saqlashingiz mumkin."
        action={
          project ? (
            <button
              className="btn outline"
              onClick={() => downloadItemizedPdfReport(project)}
              title="Kabel marshrutlari va yuklama hisobotini PDF formatida yuklab olish"
            >
              <FileText size={16} /> Itemized PDF
            </button>
          ) : undefined
        }
      />
      <ProjectGate>
        <div className="workspace-grid calc-layout">
          <Panel title="Hisoblash usuli" label="01 / USULLAR">
            <div className="method-list space-y-2">
              {kinds.map((k) => (
                <button
                  key={k.key}
                  className={`method-row flex items-start gap-3 p-3 rounded-xl border text-left transition w-full ${
                    kind === k.key
                      ? "bg-[#102137] border-[#3b8cff] text-white shadow-md shadow-[#3b8cff]/10"
                      : "bg-[#0a1829] border-[#23374f] text-[#9bb0c8] hover:text-white hover:border-[#3b8cff]/40"
                  }`}
                  onClick={() => {
                    setKind(k.key);
                    setResult(null);
                    setError("");
                  }}
                >
                  <span className="text-xl">{k.icon}</span>
                  <div>
                    <strong className="text-xs font-semibold block text-white">{k.name}</strong>
                    <span className="text-[11px] text-[#6e849d] font-mono">{k.sub}</span>
                  </div>
                </button>
              ))}
            </div>
          </Panel>

          <Panel title="Boshlang'ich parametrlar" label="02 / PARAMETRLAR">
            <div className="calc-form space-y-4">
              {/* Conditional Inputs based on kind */}
              {kind === "drop" && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Kabel materiali
                      <select
                        value={values.material}
                        onChange={(e) => setValues({ ...values, material: e.target.value })}
                        className="w-full p-2.5 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                      >
                        <option value="copper">Mis (Cu) · VVGng-LS</option>
                        <option value="aluminium">Alyuminiy (Al) · AVVG</option>
                      </select>
                    </label>

                    <label>
                      Tarmoq turi
                      <select
                        value={values.networkPhase}
                        onChange={(e) => setValues({ ...values, networkPhase: e.target.value })}
                        className="w-full p-2.5 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                      >
                        <option value="single">1 fazali (220V/230V)</option>
                        <option value="three">3 fazali (380V/400V)</option>
                      </select>
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Kabel kesimi (S)
                      <div className="input-unit">
                        <select
                          value={values.area}
                          onChange={(e) => setValues({ ...values, area: e.target.value })}
                          className="w-full p-2.5 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                        >
                          <option value="1.5">1.5 mm² (Yoritish liniyasi)</option>
                          <option value="2.5">2.5 mm² (Rozetkalar)</option>
                          <option value="4.0">4.0 mm² (Konditsioner, plita)</option>
                          <option value="6.0">6.0 mm² (Kuchli iste'molchi)</option>
                          <option value="10.0">10.0 mm² (Kirish kabeli)</option>
                          <option value="16.0">16.0 mm² (Asosiy kiritish)</option>
                        </select>
                      </div>
                    </label>

                    <label>
                      Liniya uzunligi (L)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.length}
                          onChange={(e) => setValues({ ...values, length: e.target.value })}
                        />
                        <span>m</span>
                      </div>
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Hisobiy tok (I)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.current}
                          onChange={(e) => setValues({ ...values, current: e.target.value })}
                        />
                        <span>A</span>
                      </div>
                    </label>

                    <label>
                      Quvvat koeffitsienti (cos φ)
                      <div className="input-unit">
                        <input
                          type="number"
                          step="0.01"
                          max="1.0"
                          value={values.powerFactor}
                          onChange={(e) => setValues({ ...values, powerFactor: e.target.value })}
                        />
                      </div>
                    </label>
                  </div>
                </>
              )}

              {kind === "single" && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Kuchlanish (V)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.voltage}
                          onChange={(e) => setValues({ ...values, voltage: e.target.value })}
                        />
                        <span>V</span>
                      </div>
                    </label>
                    <label>
                      Tok (I)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.current}
                          onChange={(e) => setValues({ ...values, current: e.target.value })}
                        />
                        <span>A</span>
                      </div>
                    </label>
                  </div>
                  <label>
                    Quvvat koeffitsienti (cos φ)
                    <div className="input-unit">
                      <input
                        type="number"
                        step="0.01"
                        value={values.powerFactor}
                        onChange={(e) => setValues({ ...values, powerFactor: e.target.value })}
                      />
                    </div>
                  </label>
                </>
              )}

              {kind === "three" && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Chiziqli kuchlanish
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.voltage}
                          onChange={(e) => setValues({ ...values, voltage: e.target.value })}
                        />
                        <span>V</span>
                      </div>
                    </label>
                    <label>
                      Fazadagi tok (I)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.current}
                          onChange={(e) => setValues({ ...values, current: e.target.value })}
                        />
                        <span>A</span>
                      </div>
                    </label>
                  </div>
                  <label>
                    Quvvat koeffitsienti (cos φ)
                    <div className="input-unit">
                      <input
                        type="number"
                        step="0.01"
                        value={values.powerFactor}
                        onChange={(e) => setValues({ ...values, powerFactor: e.target.value })}
                      />
                    </div>
                  </label>
                </>
              )}

              {kind === "earthing" && (
                <>
                  <label>
                    Tuproq / Grunt turi (Solishtirma qarshilik ρ)
                    <select
                      value={values.soilResistivity}
                      onChange={(e) => setValues({ ...values, soilResistivity: Number(e.target.value) })}
                      className="w-full p-2.5 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                    >
                      {soilTypes.map((s, idx) => (
                        <option key={idx} value={s.value}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </label>

                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Elektrod uzunligi (L)
                      <div className="input-unit">
                        <input
                          type="number"
                          step="0.1"
                          value={values.rodLength}
                          onChange={(e) => setValues({ ...values, rodLength: e.target.value })}
                        />
                        <span>m</span>
                      </div>
                    </label>

                    <label>
                      Elektrod diametri (Ø)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.rodDiameter}
                          onChange={(e) => setValues({ ...values, rodDiameter: e.target.value })}
                        />
                        <span>mm</span>
                      </div>
                    </label>
                  </div>
                </>
              )}

              {kind === "shortcircuit" && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Kabel uzunligi (L)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.length}
                          onChange={(e) => setValues({ ...values, length: e.target.value })}
                        />
                        <span>m</span>
                      </div>
                    </label>
                    <label>
                      Kabel kesimi (S)
                      <div className="input-unit">
                        <input
                          type="number"
                          step="0.5"
                          value={values.area}
                          onChange={(e) => setValues({ ...values, area: e.target.value })}
                        />
                        <span>mm²</span>
                      </div>
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Avtomat nominal toki (In)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.current}
                          onChange={(e) => setValues({ ...values, current: e.target.value })}
                        />
                        <span>A</span>
                      </div>
                    </label>

                    <label>
                      Kabel materiali
                      <select
                        value={values.material}
                        onChange={(e) => setValues({ ...values, material: e.target.value })}
                        className="w-full p-2.5 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                      >
                        <option value="copper">Mis (Cu)</option>
                        <option value="aluminium">Alyuminiy (Al)</option>
                      </select>
                    </label>
                  </div>
                </>
              )}

              {kind === "energy" && (
                <>
                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Kuchlanish (V)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.voltage}
                          onChange={(e) => setValues({ ...values, voltage: e.target.value })}
                        />
                        <span>V</span>
                      </div>
                    </label>
                    <label>
                      Tok (I)
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.current}
                          onChange={(e) => setValues({ ...values, current: e.target.value })}
                        />
                        <span>A</span>
                      </div>
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      Ishlash vaqti
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.hours}
                          onChange={(e) => setValues({ ...values, hours: e.target.value })}
                        />
                        <span>soat/kun</span>
                      </div>
                    </label>
                    <label>
                      Davr
                      <div className="input-unit">
                        <input
                          type="number"
                          value={values.days}
                          onChange={(e) => setValues({ ...values, days: e.target.value })}
                        />
                        <span>kun</span>
                      </div>
                    </label>
                  </div>
                </>
              )}

              {error && <div className="text-xs text-[#f47785] p-2 bg-[#f47785]/10 rounded-lg">{error}</div>}

              <button className="btn primary w-full justify-center" onClick={run}>
                <Calculator size={17} /> Hisoblash
              </button>
            </div>
          </Panel>

          <Panel title="Natija & Xulosa" label="03 / NATIJA">
            {result ? (
              <div className="calc-result space-y-4">
                <div className="p-4 rounded-xl bg-[#102137] border border-[#23374f]">
                  <span className="text-xs font-mono uppercase text-[#9bb0c8]">Asosiy qiymat</span>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-3xl font-extrabold text-[#4bc8dc]">
                      {result.value.toFixed(2)}
                    </span>
                    <span className="text-lg font-bold text-white">{result.unit}</span>
                  </div>
                  <div className="text-xs font-mono text-[#6e849d] mt-2 bg-[#07111f] p-2 rounded border border-[#23374f]">
                    {result.formula}
                  </div>
                </div>

                {result.pueCompliance && (
                  <div
                    className={`p-4 rounded-xl border flex items-start gap-3 ${
                      result.pueCompliance.status === "pass"
                        ? "bg-[#37c99b]/10 border-[#37c99b]/30 text-[#37c99b]"
                        : result.pueCompliance.status === "warning"
                          ? "bg-[#e9b663]/10 border-[#e9b663]/30 text-[#e9b663]"
                          : "bg-[#f47785]/10 border-[#f47785]/30 text-[#f47785]"
                    }`}
                  >
                    <div className="mt-0.5">
                      {result.pueCompliance.status === "pass" ? (
                        <CheckCircle2 size={18} />
                      ) : (
                        <AlertTriangle size={18} />
                      )}
                    </div>
                    <div className="flex-1">
                      <strong className="text-xs font-bold block">{result.pueCompliance.text}</strong>
                      <p className="text-[11px] text-[#f1f6fc] mt-1 leading-relaxed">
                        {result.pueCompliance.recommendation}
                      </p>
                    </div>
                  </div>
                )}

                {result.details && (
                  <div className="p-3 rounded-xl bg-[#0a1829] border border-[#23374f] space-y-1.5 text-xs">
                    {result.details.map((d, i) => (
                      <div key={i} className="flex justify-between py-1 border-b border-[#1b2b3f] last:border-none">
                        <span className="text-[#9bb0c8]">{d.label}</span>
                        <span className="font-semibold text-white">{d.value}</span>
                      </div>
                    ))}
                  </div>
                )}

                <p className="text-[11px] text-[#6e849d] italic leading-tight">{result.assumption}</p>

                <button
                  className="btn outline w-full justify-center"
                  onClick={saveToProject}
                >
                  <Save size={16} /> Natijani loyihaga saqlash
                </button>
              </div>
            ) : (
              <div className="small-empty">
                <Activity size={24} className="text-[#6e849d]" />
                <strong>Parametrlarni kiriting</strong>
                <p>Hisoblash natijalari va PUE xulosasi shu yerda aks etadi.</p>
              </div>
            )}
          </Panel>
        </div>

        {/* Saved calculations table */}
        {project && project.calculations.length > 0 && (
          <div className="mt-8">
            <Panel
              label="LOYIHAGA SAQLANGAN HISOBLAR"
              title={`Barcha natijalar (${project.calculations.length})`}
            >
              <div className="table-wrapper">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Hisoblash turi</th>
                      <th>Formula</th>
                      <th>Natija</th>
                      <th>Vaqti</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {project.calculations.map((c) => (
                      <tr key={c.id}>
                        <td className="font-semibold text-white">{c.kind}</td>
                        <td className="font-mono text-xs text-[#9bb0c8]">{c.expression}</td>
                        <td className="font-bold text-[#4bc8dc]">{c.result}</td>
                        <td className="text-xs text-[#6e849d]">
                          {new Date(c.createdAt).toLocaleDateString()}
                        </td>
                        <td>
                          <button
                            className="icon-button danger"
                            onClick={() =>
                              update(project.id, (p) => ({
                                ...p,
                                calculations: p.calculations.filter((x) => x.id !== c.id),
                              }))
                            }
                          >
                            <Trash2 size={15} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          </div>
        )}
      </ProjectGate>
    </>
  );
}
