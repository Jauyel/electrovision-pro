import { useState } from "react";
import { Cable, Download, Plus, Trash2, WandSparkles } from "lucide-react";
import { Panel, ProjectGate, SectionHead } from "../components/shell";
import { NumberField } from "../components/number-field";
import { totalRouteLength } from "../model/geometry";
import {
  csvCell,
  downloadFile,
  estimateTotals,
  mergeEstimateItems,
  newId,
  type EstimateItem,
} from "../model/project";
import { useStore } from "../model/store";
const categories = [
  "Cable",
  "Conduit",
  "Outlet",
  "Switch",
  "Light",
  "Panel",
  "Protection",
  "Accessory",
  "Other",
];
export default function Estimator() {
  const { project, update, t } = useStore();
  const [notice, setNotice] = useState<{ tone: "success" | "warning"; text: string } | null>(null);
  const [draft, setDraft] = useState({
    name: "",
    category: "Cable",
    quantity: "1",
    unit: "pcs",
    price: "0",
    waste: "0",
    labor: "0",
  });
  if (!project)
    return (
      <>
        <SectionHead eyebrow="ESTIMATION / 05" title={t("estimator")} />
        <ProjectGate>
          <></>
        </ProjectGate>
      </>
    );
  const totals = estimateTotals(project.estimates, project.contingency);
  const currency = project.currency;
  const money = (v: number) =>
    new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(v);
  const edit = (id: string, patch: Partial<EstimateItem>) =>
    update(project.id, (p) => ({
      ...p,
      estimates: p.estimates.map((x) => (x.id === id ? { ...x, ...patch } : x)),
    }));
  const add = () => {
    if (!draft.name.trim() || Number(draft.quantity) <= 0) return;
    const item: EstimateItem = {
      id: newId(),
      name: draft.name.trim(),
      category: draft.category,
      quantity: Number(draft.quantity),
      unit: draft.unit || "pcs",
      price: Math.max(0, Number(draft.price) || 0),
      waste: Math.max(0, Number(draft.waste) || 0),
      labor: Math.max(0, Number(draft.labor) || 0),
    };
    update(project.id, (p) => ({ ...p, estimates: [...p.estimates, item] }));
    setDraft({ ...draft, name: "", quantity: "1" });
  };
  const suggest = () => {
    const points = project.rooms.flatMap((r) => r.points);
    const count = (kind: string) => points.filter((p) => p.kind === kind).length;
    const cableMeters = project.rooms.reduce((n, r) => n + totalRouteLength(r), 0);
    const make = (name: string, category: string, quantity: number, unit: string, price = 0) => ({
      id: newId(),
      name: `${name} · preliminary`,
      category,
      quantity,
      unit,
      price,
      waste: 0,
      labor: 0,
    });
    const items = [
      make("Outlet", "Outlet", count("outlet"), "pcs"),
      make("Switch", "Switch", count("switch"), "pcs"),
      make("Light point", "Light", count("light"), "pcs"),
      make("Junction box", "Accessory", count("junction"), "pcs"),
      make("Distribution board", "Panel", count("panel"), "pcs"),
      make("Cable run (plan takeoff incl. allowance)", "Cable", Math.round(cableMeters * 100) / 100, "m"),
    ].filter((x) => x.quantity > 0);
    if (!items.length) {
      setNotice({ tone: "warning", text: "Add installation points or cable routes to a room first." });
      return;
    }
    update(project.id, (p) => ({ ...p, estimates: mergeEstimateItems(p.estimates, items) }));
    setNotice({
      tone: "success",
      text: `${items.length} suggested line(s) added or refreshed. Prices stay as you entered them; review every quantity.`,
    });
  };
  const fromPanel = () => {
    const groups = new Map<string, EstimateItem>();
    for (const d of project.panel) {
      const name = `${d.name}${d.manufacturer ? ` · ${d.manufacturer}` : ""}${d.model ? ` ${d.model}` : ""} · panel`;
      const key = `${name}|${d.unitPrice ?? 0}`;
      const found = groups.get(key);
      if (found) found.quantity += 1;
      else
        groups.set(key, {
          id: newId(),
          name,
          category: d.kind === "Terminal" ? "Accessory" : "Protection",
          quantity: 1,
          unit: "pcs",
          price: d.unitPrice ?? 0,
          waste: 0,
          labor: 0,
        });
    }
    if (!groups.size) {
      setNotice({ tone: "warning", text: "Place devices in the panel builder first." });
      return;
    }
    update(project.id, (p) => ({ ...p, estimates: mergeEstimateItems(p.estimates, [...groups.values()]) }));
    setNotice({ tone: "success", text: `${groups.size} panel line(s) added or refreshed.` });
  };
  return (
    <>
      <SectionHead
        eyebrow="ESTIMATION / 05"
        title={t("estimator")}
        description="User-entered prices only. Automatically suggested quantities require review."
        action={
          <button
            className="btn outline"
            onClick={() => {
              const csv = [
                [
                  "Name",
                  "Category",
                  "Quantity",
                  "Unit",
                  "Unit price",
                  "Waste %",
                  "Labor / unit",
                  "Line total",
                ],
                ...project.estimates.map((x) => [
                  x.name,
                  x.category,
                  x.quantity,
                  x.unit,
                  x.price,
                  x.waste,
                  x.labor,
                  x.quantity * (x.price * (1 + x.waste / 100) + x.labor),
                ]),
              ]
                .map((row) => row.map(csvCell).join(","))
                .join("\r\n");
              downloadFile("estimate.csv", "\uFEFF" + csv, "text/csv;charset=utf-8");
            }}
          >
            <Download size={16} /> CSV
          </button>
        }
      />
      <ProjectGate>
        <div className="estimate-bar">
          <span>
            PROJECT <b>{project.name}</b>
          </span>
          <span>
            CURRENCY{" "}
            <select
              value={currency}
              onChange={(e) =>
                update(project.id, (p) => ({ ...p, currency: e.target.value as typeof p.currency }))
              }
            >
              <option>UZS</option>
              <option>USD</option>
              <option>RUB</option>
            </select>
          </span>
          <button className="btn outline" onClick={suggest}>
            <WandSparkles size={16} /> Suggest from room points
          </button>
          <button className="btn outline" onClick={fromPanel}>
            <Cable size={16} /> Add panel devices
          </button>
        </div>
        {notice && (
          <div className={`alert ${notice.tone}`} role="status">
            {notice.text}
          </div>
        )}
        <Panel title="Bill of materials" label={`${project.estimates.length} LINE ITEMS`}>
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Material / category</th>
                  <th>Qty</th>
                  <th>Unit</th>
                  <th>Unit price</th>
                  <th>Waste %</th>
                  <th>Labor / unit</th>
                  <th>Line total</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {project.estimates.map((item) => (
                  <tr key={item.id}>
                    <td>
                      <input
                        aria-label={`Material name, ${item.name}`}
                        value={item.name}
                        onChange={(e) => edit(item.id, { name: e.target.value })}
                      />
                      <small>{item.category}</small>
                    </td>
                    <td>
                      <NumberField
                        label={`${item.name} quantity`}
                        value={item.quantity}
                        min={0}
                        commit={(n) => void edit(item.id, { quantity: n })}
                      />
                    </td>
                    <td>
                      <input
                        aria-label={`${item.name} unit`}
                        value={item.unit}
                        onChange={(e) => edit(item.id, { unit: e.target.value })}
                      />
                    </td>
                    <td>
                      <NumberField
                        label={`${item.name} unit price`}
                        value={item.price}
                        min={0}
                        commit={(n) => void edit(item.id, { price: n })}
                      />
                    </td>
                    <td>
                      <NumberField
                        label={`${item.name} waste percent`}
                        value={item.waste}
                        min={0}
                        max={1000}
                        commit={(n) => void edit(item.id, { waste: n })}
                      />
                    </td>
                    <td>
                      <NumberField
                        label={`${item.name} labor per unit`}
                        value={item.labor}
                        min={0}
                        commit={(n) => void edit(item.id, { labor: n })}
                      />
                    </td>
                    <td className="numeric-cell">
                      {money(item.quantity * (item.price * (1 + item.waste / 100) + item.labor))}
                    </td>
                    <td>
                      <button
                        className="icon-button"
                        aria-label={`Remove ${item.name}`}
                        onClick={() => {
                          if (window.confirm(`Remove “${item.name}” from the estimate?`))
                            update(project.id, (p) => ({
                              ...p,
                              estimates: p.estimates.filter((x) => x.id !== item.id),
                            }));
                        }}
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!project.estimates.length && (
              <div className="small-empty">
                No items yet. Add one below, or suggest quantities from saved room points.
              </div>
            )}
          </div>
        </Panel>
        <div className="workspace-grid estimate-bottom">
          <Panel title="Add an item" label="NEW MATERIAL">
            <form
              className="form-stack"
              onSubmit={(e) => {
                e.preventDefault();
                add();
              }}
            >
              <div className="form-row">
                <label>
                  Material name
                  <input
                    required
                    value={draft.name}
                    onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                    placeholder="e.g. 3-core copper cable"
                  />
                </label>
                <label>
                  Category
                  <select
                    value={draft.category}
                    onChange={(e) => setDraft({ ...draft, category: e.target.value })}
                  >
                    {categories.map((c) => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="form-row three">
                {(["quantity", "unit", "price", "waste", "labor"] as const).map((k) => (
                  <label key={k}>
                    {k === "price"
                      ? "Unit price"
                      : k === "labor"
                        ? "Labor / unit"
                        : k === "waste"
                          ? "Waste %"
                          : k.charAt(0).toUpperCase() + k.slice(1)}
                    <input
                      type={k === "unit" ? "text" : "number"}
                      step="any"
                      min={k === "unit" ? undefined : "0"}
                      value={draft[k]}
                      onChange={(e) => setDraft({ ...draft, [k]: e.target.value })}
                    />
                  </label>
                ))}
              </div>
              <button className="btn primary" type="submit">
                <Plus size={17} /> Add item
              </button>
            </form>
          </Panel>
          <Panel title="Estimate summary" label="TRANSPARENT TOTALS">
            <div className="summary-row">
              <span>Materials incl. waste</span>
              <b>
                {money(totals.material)} {currency}
              </b>
            </div>
            <div className="summary-row">
              <span>Labor</span>
              <b>
                {money(totals.labor)} {currency}
              </b>
            </div>
            <div className="summary-row">
              <span>
                Contingency{" "}
                <NumberField
                  className="inline-number"
                  label="Contingency percent"
                  value={project.contingency}
                  min={0}
                  max={100}
                  commit={(n) => void update(project.id, (p) => ({ ...p, contingency: n }))}
                />{" "}
                %
              </span>
              <b>
                {money(totals.reserve)} {currency}
              </b>
            </div>
            <div className="grand-total">
              <span>ESTIMATED TOTAL</span>
              <strong>
                {money(totals.total)} <small>{currency}</small>
              </strong>
            </div>
            <p className="help-text">
              Prices are entered by you. No live market pricing or tax is applied.
            </p>
          </Panel>
        </div>
      </ProjectGate>
    </>
  );
}
