import { useState } from "react";
import { Link } from "wouter";
import {
  ArrowRight,
  Boxes,
  Calculator,
  ChevronRight,
  CircuitBoard,
  FolderKanban,
  Plus,
  ScanLine,
  ShieldCheck,
  Sparkles,
  Zap,
} from "lucide-react";
import { LocalNotice, Panel } from "../components/shell";
import { useStore } from "../model/store";
import { ProjectOverviewDashboard } from "../components/project-overview-dashboard";
const tools = [
  {
    path: "/room",
    icon: ScanLine,
    key: "scanner" as const,
    number: "01",
    detail: "Dimensioned plans & 3D room",
  },
  {
    path: "/installation",
    icon: Zap,
    key: "installation" as const,
    number: "02",
    detail: "Place electrical installation points",
  },
  {
    path: "/panel",
    icon: Boxes,
    key: "panel" as const,
    number: "03",
    detail: "DIN rail component layout",
  },
  {
    path: "/calculations",
    icon: CircuitBoard,
    key: "cad" as const,
    number: "04",
    detail: "Power & voltage-drop calculations",
  },
  {
    path: "/estimator",
    icon: Calculator,
    key: "estimator" as const,
    number: "05",
    detail: "Transparent itemized costing",
  },
];
export default function Index() {
  const { db, project, choose, t } = useStore();
  const [viewMode, setViewMode] = useState<"overview" | "workspace">("overview");

  const activeProject = project || (db.projects.length > 0 ? db.projects[0] : null);
  const totalRooms = db.projects.reduce((n, p) => n + p.rooms.length, 0);
  const totalCalculations = db.projects.reduce((n, p) => n + p.calculations.length, 0);

  return (
    <>
      {activeProject ? (
        <>
          <div className="flex items-center justify-between mb-4 flex-wrap gap-3 no-print">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-slate-400">VIEW:</span>
              <div className="segmented">
                <button
                  className={viewMode === "overview" ? "active" : ""}
                  onClick={() => setViewMode("overview")}
                >
                  📊 Project Overview (Visual Analytics)
                </button>
                <button
                  className={viewMode === "workspace" ? "active" : ""}
                  onClick={() => setViewMode("workspace")}
                >
                  ⚡ Workspace Starter
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                className="btn outline"
                onClick={() => window.dispatchEvent(new Event("electrovision:create"))}
              >
                <Plus size={15} />
                {t("create")}
              </button>
              <Link href="/projects" className="btn outline">
                {t("projects")} ({db.projects.length})
              </Link>
            </div>
          </div>

          {viewMode === "overview" && (
            <ProjectOverviewDashboard
              project={activeProject}
              onSelectProject={choose}
              allProjects={db.projects}
            />
          )}
        </>
      ) : null}

      {(!activeProject || viewMode === "workspace") && (
        <div className="dashboard-hero">
          <div className="hero-copy">
            <div className="hero-eyebrow">
              <span className="pulse-dot" /> ELECTRICAL ENGINEERING WORKSPACE{" "}
              <span className="hero-line" />
            </div>
            <h1>
              {db.language === "uz"
                ? "Aniqroq loyihalang."
                : db.language === "ru"
                  ? "Проектируйте точнее."
                  : "Design with clarity."}
              <br />
              <span>
                {db.language === "uz"
                  ? "Ishonch bilan ishlang."
                  : db.language === "ru"
                    ? "Работайте уверенно."
                    : "Work with confidence."}
              </span>
            </h1>
            <p>
              {db.language === "uz"
                ? "Xona rejasidan smetagacha — barcha elektr loyihalaringiz bitta ish maydonida."
                : db.language === "ru"
                  ? "От плана комнаты до сметы — ваши электротехнические проекты в одном месте."
                  : "From room plans to material estimates, keep every electrical project in one focused workspace."}
            </p>
            <div className="hero-actions">
              <button
                className="btn primary"
                onClick={() => window.dispatchEvent(new Event("electrovision:create"))}
              >
                <Plus size={18} />
                {t("create")}
              </button>
              <Link href="/projects" className="btn outline">
                {t("projects")} <ArrowRight size={17} />
              </Link>
            </div>
          </div>
          <div className="hero-visual" aria-hidden="true">
            <div className="blueprint-orbit orbit-one" />
            <div className="blueprint-orbit orbit-two" />
            <div className="blueprint-box">
              <span className="dim dim-top">4.00 m</span>
              <span className="dim dim-side">5.00 m</span>
              <div className="plan-room">
                <i className="plan-door" />
                <i className="symbol bulb">✳</i>
                <i className="symbol outlet-one">⊙</i>
                <i className="symbol outlet-two">⊙</i>
                <i className="symbol switch-symbol">↗</i>
                <span className="room-label">
                  ROOM 01 <small>20.0 m²</small>
                </span>
              </div>
            </div>
            <div className="visual-badge">
              <span className="online-dot" /> PLAN · LOCAL
            </div>
          </div>
        </div>
      )}

      {(!activeProject || viewMode === "workspace") && (
        <div className="overview-strip">
          <div>
            <span>01 / PROJECTS</span>
            <strong>{String(db.projects.length).padStart(2, "0")}</strong>
            <small>Saved in this browser</small>
          </div>
          <div>
            <span>02 / ROOMS</span>
            <strong>{String(totalRooms).padStart(2, "0")}</strong>
            <small>Dimensioned spaces</small>
          </div>
          <div>
            <span>03 / CALCULATIONS</span>
            <strong>{String(totalCalculations).padStart(2, "0")}</strong>
            <small>Saved results</small>
          </div>
          <div className="strip-note">
            <ShieldCheck size={20} />
            <p>
              Preliminary planning tools.
              <br />
              <b>Verify against site conditions and local requirements.</b>
            </p>
          </div>
        </div>
      )}
      <div className="section-title-line">
        <div>
          <span className="eyebrow">01 / TOOLKIT</span>
          <h2>{t("quick")}</h2>
        </div>
        <span>
          SELECT A WORKSPACE <ArrowRight size={15} />
        </span>
      </div>
      <div className="tool-grid">
        {tools.map((tool) => (
          <Link className="tool-card" href={tool.path} key={tool.path}>
            <div className="tool-top">
              <span>{tool.number} / 05</span>
              <tool.icon size={22} strokeWidth={1.65} />
            </div>
            <div>
              <h3>{t(tool.key)}</h3>
              <p>{tool.detail}</p>
            </div>
            <ChevronRight className="tool-arrow" size={18} />
          </Link>
        ))}
      </div>
      <div className="dashboard-lower">
        <Panel
          label="02 / WORK IN PROGRESS"
          title={t("recent")}
          action={
            <Link href="/projects" className="text-link">
              {t("projects")} <ArrowRight size={15} />
            </Link>
          }
        >
          {db.projects.length ? (
            <div className="recent-list">
              {db.projects.slice(0, 4).map((p) => (
                <Link href="/projects" key={p.id} className="recent-row">
                  <div className="recent-glyph">
                    <FolderKanban size={18} />
                  </div>
                  <div>
                    <strong>{p.name}</strong>
                    <small>
                      {p.rooms.length} rooms · {p.estimates.length} items
                    </small>
                  </div>
                  <span className="status-chip">{p.status}</span>
                  <ChevronRight size={17} />
                </Link>
              ))}
            </div>
          ) : (
            <div className="small-empty">
              <FolderKanban size={22} />
              <strong>{t("noProject")}</strong>
              <p>{t("start")}</p>
            </div>
          )}
        </Panel>
        <Panel label="03 / WORKSPACE STATUS" title="Ready for your next project">
          <div className="readiness">
            <div className="readiness-icon">
              <Sparkles size={24} />
            </div>
            <p>
              Start with a room plan, run a calculation, or build an itemized estimate. Your work
              saves as you go.
            </p>
            <div className="readiness-row">
              <span>
                <span className="online-dot" /> Local storage
              </span>
              <span>No account required</span>
            </div>
          </div>
        </Panel>
      </div>
      <LocalNotice />
    </>
  );
}
