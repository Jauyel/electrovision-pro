import { useRef, useState } from "react";
import {
  Activity,
  AlertTriangle,
  Archive,
  CheckCircle2,
  Download,
  FileText,
  Gauge,
  HardDriveDownload,
  HardDriveUpload,
  Printer,
  Search,
  ShieldAlert,
  Zap,
} from "lucide-react";
import { LocalNotice, Panel, ProjectGate, SectionHead } from "../components/shell";
import { routeLength } from "../model/geometry";
import {
  compileItemizedCableRuns,
  compileItemizedRoomLoads,
  downloadItemizedPdfReport,
} from "../lib/pdf-report";
import {
  downloadFile,
  estimateTotals,
  readRecovery,
  recoveryDumps,
  slug,
  validDatabase,
  type Database,
} from "../model/project";
import { useStore } from "../model/store";
import { ProjectOverviewDashboard } from "../components/project-overview-dashboard";
export function ValidationPage() {
  const { project, t } = useStore();
  const findings = project
    ? [
        ...(!project.rooms.length
          ? [
              {
                level: "info",
                title: "No room plans",
                detail: "Add room geometry when spatial planning is needed.",
              },
            ]
          : []),
        ...(!project.calculations.length
          ? [
              {
                level: "warning",
                title: "No saved electrical calculations",
                detail:
                  "Record relevant load and voltage-drop calculations before technical review.",
              },
            ]
          : []),
        ...(!project.panel.length
          ? [
              {
                level: "info",
                title: "No distribution board components",
                detail: "Create a preliminary panel layout if this project needs one.",
              },
            ]
          : []),
        ...project.rooms
          .filter((r) => r.points.length > 0 && !r.points.some((p) => p.kind === "panel"))
          .map((r) => ({
            level: "info",
            title: `Room “${r.name}” has points but no panel point`,
            detail: "Mark where the supply or distribution board is, so routes can start there.",
          })),
        ...project.rooms
          .filter((r) => (r.routes ?? []).some((route) => routeLength(r, route) === null))
          .map((r) => ({
            level: "warning",
            title: `Room “${r.name}” has a cable route with a missing endpoint`,
            detail: "A point used by a route was deleted. Choose valid endpoints or remove the route.",
          })),
        ...(project.panel.reduce((n, d) => n + d.modules, 0) > 20
          ? [
              {
                level: "warning",
                title: "Panel exceeds the 20-module rail",
                detail: "Devices past module 20 are not drawn in 3D. Remove devices or split the board.",
              },
            ]
          : []),
        ...(project.panel.some((d) => !d.unitPrice)
          ? [
              {
                level: "info",
                title: "Panel devices without a price",
                detail: "Enter unit prices in the panel builder so the estimate is complete.",
              },
            ]
          : []),
        ...(project.estimates.some((x) => x.price === 0)
          ? [
              {
                level: "warning",
                title: `${project.estimates.filter((x) => x.price === 0).length} estimate line(s) have no price`,
                detail: "Totals exclude these lines until a unit price is entered.",
              },
            ]
          : []),
        ...(!project.notes.trim()
          ? [
              {
                level: "warning",
                title: "Project assumptions not documented",
                detail:
                  "Record installation assumptions, applicable standards and verification notes.",
              },
            ]
          : []),
        ...(!project.site.trim()
          ? [
              {
                level: "info",
                title: "Site details missing",
                detail: "Add a site address or reference under work orders.",
              },
            ]
          : []),
      ]
    : [];
  return (
    <>
      <SectionHead
        eyebrow="DESIGN REVIEW / 06"
        title={t("validation")}
        description="Completeness checks only — not a safety assessment or standards-compliance certification."
      />
      <ProjectGate>
        <div className="review-banner">
          <ShieldAlert size={24} />
          <div>
            <strong>Preliminary document review</strong>
            <p>
              These checks only detect missing fields. Passing them does not establish an
              electrically safe or compliant design.
            </p>
          </div>
        </div>
        <Panel title={`${findings.length} findings`} label="RULE-BASED CHECKS">
          {findings.length ? (
            findings.map((f, i) => (
              <div className="finding" key={i}>
                <span className={`finding-tag ${f.level}`}>{f.level}</span>
                <div>
                  <strong>{f.title}</strong>
                  <p>{f.detail}</p>
                </div>
              </div>
            ))
          ) : (
            <p className="muted">
              No missing-field findings from the current limited rule set. Independent engineering
              review is still required.
            </p>
          )}
        </Panel>
      </ProjectGate>
    </>
  );
}
export function WorkPage() {
  const { project, update, t } = useStore();
  return (
    <>
      <SectionHead
        eyebrow="FIELD WORK / 07"
        title={t("work")}
        description="Keep customer and work-order notes attached to the active project. Local device storage only."
      />
      <ProjectGate>
        {project && (
          <Panel title="Site & customer details" label="ACTIVE PROJECT">
            <div className="form-stack" key={project.id}>
              <div className="form-row">
                <label>
                  Customer / organization
                  <input
                    defaultValue={project.customer}
                    onBlur={(e) => update(project.id, (p) => ({ ...p, customer: e.target.value }))}
                  />
                </label>
                <label>
                  Site / address
                  <input
                    defaultValue={project.site}
                    onBlur={(e) => update(project.id, (p) => ({ ...p, site: e.target.value }))}
                  />
                </label>
              </div>
              <label>
                Work order / scope
                <textarea
                  rows={5}
                  defaultValue={project.workOrder}
                  onBlur={(e) => update(project.id, (p) => ({ ...p, workOrder: e.target.value }))}
                />
              </label>
              <label>
                Engineering notes & assumptions
                <textarea
                  rows={5}
                  defaultValue={project.notes}
                  onBlur={(e) => update(project.id, (p) => ({ ...p, notes: e.target.value }))}
                />
              </label>
              <small className="help-text">
                Changes save on leaving a field. Do not store sensitive customer information on a
                shared browser.
              </small>
            </div>
          </Panel>
        )}
      </ProjectGate>
    </>
  );
}
export function ReportsPage() {
  const { project, t, db } = useStore();
  const [reportTab, setReportTab] = useState<"all" | "visual" | "cables" | "loads" | "calculations">("all");
  const [downloading, setDownloading] = useState(false);

  if (!project)
    return (
      <>
        <SectionHead eyebrow="DOCUMENTATION / 08" title={t("reports")} />
        <ProjectGate>
          <></>
        </ProjectGate>
      </>
    );

  const totals = estimateTotals(project.estimates, project.contingency);
  const cableData = compileItemizedCableRuns(project);
  const loadData = compileItemizedRoomLoads(project);

  const handleExportPdf = () => {
    setDownloading(true);
    try {
      downloadItemizedPdfReport(project);
    } finally {
      setTimeout(() => setDownloading(false), 600);
    }
  };

  const payload = {
    project,
    cableRuns: cableData,
    loadCalculations: loadData,
    summary: {
      rooms: project.rooms.length,
      points: project.rooms.reduce((n, r) => n + r.points.length, 0),
      totalCableLengthM: cableData.totalLengthM,
      totalConnectedLoadKw: loadData.totalConnectedKw,
      panelModules: project.panel.reduce((n, d) => n + d.modules, 0),
      estimate: totals,
      standardCompliance:
        loadData.overloadedCount === 0
          ? "All monitored rooms comply with PUE 7.1 / NEC 80% continuous duty rating."
          : `${loadData.overloadedCount} room(s) exceed 80% circuit capacity limit and require engineering redistribution.`,
    },
  };

  return (
    <>
      <SectionHead
        eyebrow="DOCUMENTATION / 08"
        title="Engineering Reports & Cable Takeoff"
        description="Comprehensive itemized takeoff for all cable routes, room load capacity calculations, and PUE 7.1 compliance audit. Ready for print and client sign-off."
        action={
          <div className="report-action-buttons">
            <button
              className="btn primary"
              onClick={handleExportPdf}
              disabled={downloading}
              title="Download professional itemized PDF document"
            >
              <Download size={16} />
              {downloading ? "Generating PDF..." : "Export Itemized PDF"}
            </button>
            <button
              className="btn outline"
              onClick={() => window.print()}
              title="Print directly or save via browser PDF printer"
            >
              <Printer size={16} />
              Print / Save PDF
            </button>
            <button
              className="btn outline"
              onClick={() =>
                downloadFile(
                  `report-itemized-${slug(project.name)}.json`,
                  JSON.stringify(payload, null, 2),
                )
              }
              title="Export structured JSON report"
            >
              <FileText size={16} /> JSON
            </button>
          </div>
        }
      />
      <ProjectGate>
        {/* Interactive View Filter Tabs (hidden during print) */}
        <div className="report-filter-bar no-print">
          <div className="segmented">
            <button
              className={reportTab === "all" ? "active" : ""}
              onClick={() => setReportTab("all")}
            >
              📋 All Sections (Full Dossier)
            </button>
            <button
              className={reportTab === "visual" ? "active" : ""}
              onClick={() => setReportTab("visual")}
            >
              📊 Visual Overview (Costs & Load)
            </button>
            <button
              className={reportTab === "cables" ? "active" : ""}
              onClick={() => setReportTab("cables")}
            >
              🔌 Cable Runs ({cableData.runs.length} runs · {cableData.totalLengthM} m)
            </button>
            <button
              className={reportTab === "loads" ? "active" : ""}
              onClick={() => setReportTab("loads")}
            >
              ⚡ Load Calculations ({loadData.loads.length} rooms · {loadData.totalConnectedKw} kW)
            </button>
            <button
              className={reportTab === "calculations" ? "active" : ""}
              onClick={() => setReportTab("calculations")}
            >
              📐 Formulas ({project.calculations.length})
            </button>
          </div>
        </div>

        {/* Printable & Screen-Optimized Itemized Report Container */}
        <div className="print-report itemized-engineering-report">
          {/* Document Header Block */}
          <div className="report-brand-header">
            <div className="brand-left">
              <span className="eyebrow">ELECTROVISION AI PRO · ENGINEERING SPECIFICATION</span>
              <h2>{project.name}</h2>
              <p>
                {[
                  project.site ? `Site Address: ${project.site}` : null,
                  project.customer ? `Client: ${project.customer}` : null,
                  project.workOrder ? `Work Order: ${project.workOrder}` : null,
                ]
                  .filter(Boolean)
                  .join(" · ") || "Itemized Electrical Cable Routing & Load Capacity Certification"}
              </p>
            </div>
            <div className="brand-right">
              <div className="report-meta-box">
                <span className="report-meta-label">DATE</span>
                <span className="report-meta-value">
                  {new Date().toLocaleDateString(undefined, {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}
                </span>
                <span className="report-meta-label">PROJECT STATUS</span>
                <span className="report-status-badge">{project.status.toUpperCase()}</span>
              </div>
            </div>
          </div>

          {/* KPI Summary Tiles */}
          <div className="report-kpi-grid">
            <div className="report-kpi-card">
              <span className="kpi-label">TOTAL CABLE TAKEOFF</span>
              <strong className="kpi-value text-blue">{cableData.totalLengthM.toFixed(1)} m</strong>
              <small className="kpi-sub">
                {cableData.runs.length} routed runs across {project.rooms.length} rooms
              </small>
            </div>
            <div className="report-kpi-card">
              <span className="kpi-label">TOTAL CONNECTED LOAD</span>
              <strong className="kpi-value text-cyan">
                {loadData.totalConnectedKw.toFixed(2)} kW
              </strong>
              <small className="kpi-sub">
                {project.rooms.reduce((s, r) => s + r.points.length, 0)} points (Kc = 0.85
                diversity)
              </small>
            </div>
            <div className="report-kpi-card">
              <span className="kpi-label">SURVEYED SURFACE AREA</span>
              <strong className="kpi-value">{loadData.buildingAreaM2.toFixed(1)} m²</strong>
              <small className="kpi-sub">{project.rooms.length} separate rooms mapped</small>
            </div>
            <div
              className={`report-kpi-card ${loadData.overloadedCount > 0 ? "has-warning" : "has-pass"}`}
            >
              <span className="kpi-label">PUE 7.1 / NEC 80% AUDIT</span>
              <strong
                className={`kpi-value ${loadData.overloadedCount > 0 ? "text-amber" : "text-emerald"}`}
              >
                {loadData.overloadedCount === 0
                  ? "✓ 100% COMPLIANT"
                  : `⚠️ ${loadData.overloadedCount} ROOMS >80%`}
              </strong>
              <small className="kpi-sub">
                {loadData.overloadedCount === 0
                  ? "Safe continuous thermal load"
                  : "Action needed to prevent breaker trips"}
              </small>
            </div>
          </div>

          {/* Overload Alert Callout if any room exceeds 80% */}
          {loadData.overloadedCount > 0 && (
            <div className="report-alert-box">
              <AlertTriangle className="alert-icon" size={18} />
              <div>
                <strong>
                  Continuous Load Warning: {loadData.overloadedCount} room(s) exceed 80% circuit
                  breaker rating!
                </strong>
                <p>
                  Per PUE 7.1 and NEC 210.19, continuous electrical branch circuits must not exceed
                  80% of nominal breaker rating. Inspect the highlighted rooms below and consider
                  upgrading the breaker ampacity or redistributing socket branch feeds.
                </p>
              </div>
            </div>
          )}

          {/* SECTION: Visual Analytics (Recharts Cost & Energy Load Breakdown) */}
          {(reportTab === "all" || reportTab === "visual") && (
            <div className="report-section no-print-section mb-6">
              <div className="section-title-strip">
                <h3>Visual Project Analytics & Engineering Distribution</h3>
                <span className="section-note">
                  Interactive Recharts Visualizations
                </span>
              </div>
              <div className="pt-4">
                <ProjectOverviewDashboard project={project} compact />
              </div>
            </div>
          )}

          {/* SECTION 1: Itemized Room Load & Capacity Calculations */}
          {(reportTab === "all" || reportTab === "loads") && (
            <div className="report-section page-break-inside-avoid">
              <div className="section-title-strip">
                <h3>1. Itemized Electrical Load & Capacity Calculations</h3>
                <span className="section-note">
                  Continuous limit: 80% of circuit rating (PUE 7.1 / NEC)
                </span>
              </div>
              <div className="table-responsive">
                <table className="report-table">
                  <thead>
                    <tr>
                      <th style={{ width: "16%" }}>Room Name</th>
                      <th style={{ width: "15%" }}>Dimensions</th>
                      <th style={{ width: "8%", textAlign: "right" }}>Area</th>
                      <th style={{ width: "6%", textAlign: "center" }}>Pts</th>
                      <th style={{ width: "10%", textAlign: "right" }}>Outlets</th>
                      <th style={{ width: "9%", textAlign: "right" }}>Lights</th>
                      <th style={{ width: "11%", textAlign: "right" }}>Total Load</th>
                      <th style={{ width: "10%", textAlign: "right" }}>Breaker</th>
                      <th style={{ width: "8%", textAlign: "right" }}>Load %</th>
                      <th style={{ width: "17%" }}>PUE 7.1 Compliance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {loadData.loads.map((r) => (
                      <tr
                        key={r.roomName}
                        className={
                          r.status === "critical"
                            ? "row-critical"
                            : r.status === "warning"
                              ? "row-warning"
                              : ""
                        }
                      >
                        <td>
                          <strong>{r.roomName}</strong>
                        </td>
                        <td className="text-muted">{r.dimensionsStr}</td>
                        <td className="text-right font-mono">{r.areaM2.toFixed(1)} m²</td>
                        <td className="text-center font-mono">{r.pointsCount}</td>
                        <td className="text-right font-mono">{r.outletsKw.toFixed(2)} kW</td>
                        <td className="text-right font-mono">{r.lightsKw.toFixed(2)} kW</td>
                        <td className="text-right font-mono font-bold">{r.totalLoadKw.toFixed(2)} kW</td>
                        <td className="text-right font-mono">{r.capacityKw.toFixed(2)} kW</td>
                        <td className="text-right font-mono font-bold">
                          <span className={`table-load-pill ${r.status}`}>
                            {r.ratioPercent.toFixed(1)}%
                          </span>
                        </td>
                        <td>
                          <span className={`compliance-tag ${r.status}`}>{r.complianceRule}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan={2}>
                        <strong>PROJECT TOTALS ({loadData.loads.length} rooms)</strong>
                      </td>
                      <td className="text-right font-mono font-bold">
                        {loadData.buildingAreaM2.toFixed(1)} m²
                      </td>
                      <td className="text-center font-mono font-bold">
                        {project.rooms.reduce((s, r) => s + r.points.length, 0)}
                      </td>
                      <td colSpan={2} />
                      <td className="text-right font-mono font-bold text-cyan">
                        {loadData.totalConnectedKw.toFixed(2)} kW
                      </td>
                      <td colSpan={3} className="text-muted font-mono text-right">
                        Estimated Diversified Peak:{" "}
                        {(loadData.totalConnectedKw * 0.85).toFixed(2)} kW
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}

          {/* SECTION 2: Itemized Cable Runs Takeoff */}
          {(reportTab === "all" || reportTab === "cables") && (
            <div className="report-section page-break-inside-avoid">
              <div className="section-title-strip">
                <h3>2. Itemized Cable Runs & Conductor Sizing Takeoff</h3>
                <span className="section-note">
                  Includes plan geometry + corner/elevation allowances. Sized per PUE 2.1.
                </span>
              </div>
              <div className="table-responsive">
                <table className="report-table">
                  <thead>
                    <tr>
                      <th style={{ width: "4%", textAlign: "center" }}>#</th>
                      <th style={{ width: "14%" }}>Room</th>
                      <th style={{ width: "15%" }}>Route Name</th>
                      <th style={{ width: "26%" }}>Linked Points Sequence</th>
                      <th style={{ width: "9%", textAlign: "right" }}>Plan Run</th>
                      <th style={{ width: "6%", textAlign: "center" }}>Allow.</th>
                      <th style={{ width: "9%", textAlign: "right" }}>Cut Length</th>
                      <th style={{ width: "8%", textAlign: "right" }}>Load</th>
                      <th style={{ width: "19%" }}>Recommended Conductor Spec</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cableData.runs.length > 0 ? (
                      cableData.runs.map((r, i) => (
                        <tr key={`${r.roomName}-${r.routeName}-${i}`}>
                          <td className="text-center font-mono text-muted">
                            {String(i + 1).padStart(2, "0")}
                          </td>
                          <td>
                            <strong>{r.roomName}</strong>
                          </td>
                          <td>{r.routeName}</td>
                          <td className="points-cell" title={r.pointsDesc}>
                            {r.pointsDesc}
                          </td>
                          <td className="text-right font-mono">{r.planLengthM.toFixed(2)} m</td>
                          <td className="text-center font-mono text-muted">
                            +{r.allowancePercent}%
                          </td>
                          <td className="text-right font-mono font-bold">{r.cutLengthM.toFixed(2)} m</td>
                          <td className="text-right font-mono">{r.estimatedLoadKw.toFixed(2)} kW</td>
                          <td>
                            <strong className="cable-spec-text">{r.recommendedCable}</strong>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={9} className="empty-table-cell">
                          No cable routes have been defined yet. Open <strong>Site Planning → Cable Routes</strong> to draw wiring conduits.
                        </td>
                      </tr>
                    )}
                  </tbody>
                  {cableData.runs.length > 0 && (
                    <tfoot>
                      <tr>
                        <td colSpan={6}>
                          <strong>TOTAL MEASURED CABLE CUT LENGTH</strong>
                        </td>
                        <td className="text-right font-mono font-bold text-blue">
                          {cableData.totalLengthM.toFixed(2)} m
                        </td>
                        <td colSpan={2} className="text-right text-muted font-mono">
                          With +10% Installation Reserve:{" "}
                          <strong>{(cableData.totalLengthM * 1.1).toFixed(1)} m</strong>
                        </td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>

              {/* Cable Takeoff by Room Summary */}
              {cableData.roomTotals.length > 0 && (
                <div className="room-cables-summary">
                  <span className="summary-title">Cable Takeoff Breakdown by Room:</span>
                  <div className="room-cables-pills">
                    {cableData.roomTotals.map((rt) => (
                      <div key={rt.roomName} className="room-cable-pill">
                        <strong>{rt.roomName}:</strong>
                        <span>
                          {rt.lengthM.toFixed(1)} m ({rt.routesCount} routes)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* SECTION 3: Saved Engineering Calculations */}
          {(reportTab === "all" || reportTab === "calculations") && (
            <div className="report-section page-break-inside-avoid">
              <div className="section-title-strip">
                <h3>3. Saved Engineering & Code Compliance Calculations</h3>
                <span className="section-note">
                  Formulas, voltage drop checks, and earthing calculations
                </span>
              </div>
              {project.calculations.length > 0 ? (
                <div className="table-responsive">
                  <table className="report-table">
                    <thead>
                      <tr>
                        <th style={{ width: "5%", textAlign: "center" }}>#</th>
                        <th style={{ width: "25%" }}>Calculation Type</th>
                        <th style={{ width: "40%" }}>Formula & Input Parameters</th>
                        <th style={{ width: "18%", textAlign: "right" }}>Result</th>
                        <th style={{ width: "12%", textAlign: "right" }}>Timestamp</th>
                      </tr>
                    </thead>
                    <tbody>
                      {project.calculations.map((c, i) => (
                        <tr key={c.id}>
                          <td className="text-center font-mono text-muted">
                            {String(i + 1).padStart(2, "0")}
                          </td>
                          <td>
                            <strong>{c.kind}</strong>
                          </td>
                          <td className="font-mono text-muted">{c.expression}</td>
                          <td className="text-right font-mono font-bold text-cyan">{c.result}</td>
                          <td className="text-right font-mono text-muted">
                            {new Date(c.createdAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="empty-subtle">
                  No electrical calculations saved yet. Use the <strong>Calculations</strong> page to evaluate voltage drop, short circuit currents, and earthing resistance.
                </p>
              )}
            </div>
          )}

          {/* SECTION 4: Distribution Board & Material Estimates */}
          {reportTab === "all" && (
            <div className="report-section page-break-inside-avoid">
              <div className="section-title-strip">
                <h3>4. Distribution Board & Bill of Materials Summary</h3>
              </div>
              <div className="distribution-materials-grid">
                <div className="summary-subcard">
                  <h4>Distribution Board ({project.panel.length} Devices)</h4>
                  {project.panel.length ? (
                    <div className="panel-devices-list">
                      {project.panel.map((d, i) => (
                        <div key={d.id} className="panel-dev-row">
                          <span>
                            {String(i + 1).padStart(2, "0")}. {d.name}
                          </span>
                          <strong>
                            {d.modules}M{d.manufacturer ? ` · ${d.manufacturer}` : ""}
                          </strong>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="empty-subtle">No devices placed in distribution board.</p>
                  )}
                </div>

                <div className="summary-subcard">
                  <h4>Material Estimate Summary</h4>
                  <div className="material-summary-content">
                    <div className="material-line">
                      <span>Total Line Items:</span>
                      <strong>{project.estimates.length} items</strong>
                    </div>
                    <div className="material-line">
                      <span>Materials Total:</span>
                      <strong>
                        {totals.material.toLocaleString(undefined, { maximumFractionDigits: 2 })}{" "}
                        {project.currency}
                      </strong>
                    </div>
                    <div className="material-line">
                      <span>Labor Total:</span>
                      <strong>
                        {totals.labor.toLocaleString(undefined, { maximumFractionDigits: 2 })}{" "}
                        {project.currency}
                      </strong>
                    </div>
                    <div className="material-line total">
                      <span>Project Total ({project.contingency}% reserve):</span>
                      <strong className="text-emerald">
                        {totals.total.toLocaleString(undefined, { maximumFractionDigits: 2 })}{" "}
                        {project.currency}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Engineering Verification & Handover Sign-Off Block */}
          <div className="report-signoff-block page-break-inside-avoid">
            <div className="signoff-note">
              <strong>ENGINEERING VERIFICATION & DISCLAIMER:</strong>
              <p>
                This itemized report provides accurate geometric takeoffs and load calculations
                based on site survey inputs and PUE 7.1 / NEC continuous electrical load criteria.
                Final installation must comply with local building regulations and be certified by
                authorized electrical inspectors.
              </p>
            </div>
            <div className="signoff-signatures">
              <div className="sign-col">
                <span className="sign-title">PREPARED BY (ELECTRICAL ENGINEER):</span>
                <div className="sign-line" />
                <span className="sign-meta">Signature / Date</span>
              </div>
              <div className="sign-col">
                <span className="sign-title">VERIFIED & APPROVED BY (CLIENT / SITE):</span>
                <div className="sign-line" />
                <span className="sign-meta">Signature / Date</span>
              </div>
            </div>
          </div>
        </div>
      </ProjectGate>
    </>
  );
}
const examples = [
  ["Cable", "Copper conductor", "m"],
  ["Cable", "Aluminium conductor", "m"],
  ["Conduit", "PVC conduit", "m"],
  ["Outlet", "Power outlet", "pcs"],
  ["Switch", "Wall switch", "pcs"],
  ["Light", "Light fixture", "pcs"],
  ["Panel", "Distribution enclosure", "pcs"],
  ["Protection", "MCB", "pcs"],
  ["Protection", "RCD", "pcs"],
  ["Protection", "RCBO", "pcs"],
  ["Accessory", "Junction box", "pcs"],
  ["Accessory", "Terminal block", "pcs"],
];
export function LibraryPage() {
  const [search, setSearch] = useState("");
  const { t } = useStore();
  return (
    <>
      <SectionHead
        eyebrow="REFERENCE / 09"
        title={t("library")}
        description="Generic starter categories only. No manufacturers, certifications or current market prices are implied."
      />
      <Panel
        label="GENERIC MATERIAL TYPES"
        title="Browse categories"
        action={
          <div className="search-field">
            <Search size={16} />
            <input
              aria-label="Search materials"
              placeholder="Search materials"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        }
      >
        <div className="library-grid">
          {examples
            .filter((row) => row.join(" ").toLowerCase().includes(search.toLowerCase()))
            .map(([category, name, unit]) => (
              <div className="library-item" key={name}>
                <div className="library-icon">
                  <Archive size={19} />
                </div>
                <div>
                  <strong>{name}</strong>
                  <small>
                    {category} · {unit} · price not set
                  </small>
                </div>
              </div>
            ))}
        </div>
      </Panel>
    </>
  );
}
export function SettingsPage() {
  const { db, replace, setLanguage, theme, setTheme, t } = useStore();
  const input = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");
  const dumps = recoveryDumps();
  async function restore(file: File) {
    try {
      const parsed: unknown = JSON.parse(await file.text());
      if (!validDatabase(parsed)) throw Error("Invalid or unsupported backup format.");
      if (
        !window.confirm(
          "Replace all local projects and settings with this backup? This cannot be undone.",
        )
      )
        return;
      replace(parsed as Database);
      setMessage("Backup restored successfully.");
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "Restore failed.");
    }
  }
  return (
    <>
      <SectionHead
        eyebrow="PREFERENCES / 10"
        title={t("settings")}
        description="Ish muhiti mavzusi, til va mahalliy ma'lumotlar xavfsizligini boshqarish."
      />
      <div className="workspace-grid two">
        <Panel title="Workspace preferences" label="LOCAL SETTINGS">
          <div className="form-stack">
            <label>
              Interfeys tili
              <select
                value={db.language}
                onChange={(e) => setLanguage(e.target.value as Database["language"])}
              >
                <option value="uz">O‘zbekcha (Lotin)</option>
                <option value="ru">Русский</option>
                <option value="en">English</option>
              </select>
            </label>
            <label>
              Ekran mavzusi (Theme)
              <select
                value={theme}
                onChange={(e) => setTheme(e.target.value as "dark" | "light")}
              >
                <option value="dark">Deep Space · Qorong'i muhandislik rejimi</option>
                <option value="light">Light Engineering · Yuqori kontrastli yorug' maydon rejimi</option>
              </select>
            </label>
            <div className="settings-item">
              <strong>Mavzu maqsadi</strong>
              <span>
                {theme === "light"
                  ? "Light Engineering: quyoshli maydon va ochiq havoda yuqori kontrast."
                  : "Deep Space: qulay laboratoriya va qorong'i xona rejimi."}
              </span>
            </div>
            <div className="settings-item">
              <strong>Storage mode</strong>
              <span>Browser localStorage · Ushbu qurilma xotirasi</span>
            </div>
            <div className="settings-item">
              <strong>AI Engineering Co-Pilot</strong>
              <span className="text-[#37c99b] font-semibold">Gemini 3.8 Flash Pro · Faol</span>
            </div>
          </div>
        </Panel>
        <Panel title="Backup & restore" label="DATA PROTECTION">
          <p className="muted">
            Download a versioned JSON backup regularly. Restoring replaces all local projects after
            confirmation.
          </p>
          <div className="button-row">
            <button
              className="btn primary"
              onClick={() =>
                downloadFile(
                  `electrovision-backup-${new Date().toISOString().slice(0, 10)}.json`,
                  JSON.stringify(db, null, 2),
                )
              }
            >
              <HardDriveDownload size={17} /> Download backup
            </button>
            <button className="btn outline" onClick={() => input.current?.click()}>
              <HardDriveUpload size={17} /> Restore backup
            </button>
          </div>
          <input
            aria-label="Backup file"
            ref={input}
            hidden
            type="file"
            accept="application/json,.json"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void restore(file);
              e.target.value = "";
            }}
          />
          {message && (
            <div className="alert" role="status">
              {message}
            </div>
          )}
          {dumps.length > 0 && (
            <div className="alert warning">
              <strong>Recover unreadable data</strong>
              <p>
                Saved data that failed validation was kept separately so it was not overwritten. Download it and
                inspect or repair the JSON.
              </p>
              <div className="button-row">
                {dumps.map((d) => (
                  <button
                    key={d.key}
                    className="btn outline"
                    onClick={() => {
                      const raw = readRecovery(d.key);
                      if (raw) downloadFile(`electrovision-unreadable-${d.savedAt.slice(0, 10) || "data"}.json`, raw);
                    }}
                  >
                    <Download size={15} /> {d.savedAt.slice(0, 16).replace("T", " ") || "Unknown date"} ·{" "}
                    {Math.ceil(d.size / 1024)} KB
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="subtle-note">
            There is no server-side backup or automatic cross-device synchronization.
          </div>
        </Panel>
      </div>
      <LocalNotice />
    </>
  );
}
