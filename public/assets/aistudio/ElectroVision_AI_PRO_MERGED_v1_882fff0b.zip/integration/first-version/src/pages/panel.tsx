import { useCallback, useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Download,
  Eye,
  Plus,
  Trash2,
  Sparkles,
  CircuitBoard,
  Boxes,
  Zap,
} from "lucide-react";
import { Panel, ProjectGate, SectionHead } from "../components/shell";
import { NumberField } from "../components/number-field";
import { Panel3D, type PanelView } from "../components/panel-3d";
import { downloadFile, newId, type PanelDevice } from "../model/project";
import { useStore } from "../model/store";

const catalog = [
  { name: "MCB 1P · B10 (Yoritish)", kind: "MCB", modules: 1, poles: 1, defaultPrice: 35000 },
  { name: "MCB 1P · C16 (Rozetkalar)", kind: "MCB", modules: 1, poles: 1, defaultPrice: 38000 },
  { name: "MCB 1P · C25 (Plita / Konditsioner)", kind: "MCB", modules: 1, poles: 1, defaultPrice: 42000 },
  { name: "MCB 2P · C32 / C40 (Kirish 1-faza)", kind: "MCB", modules: 2, poles: 2, defaultPrice: 85000 },
  { name: "MCB 3P · C25 / C32 (Kirish 3-faza)", kind: "MCB", modules: 3, poles: 3, defaultPrice: 125000 },
  { name: "MCB 4P · C40 (Asosiy kiritish)", kind: "MCB", modules: 4, poles: 4, defaultPrice: 160000 },
  { name: "UZO (RCD) 2P · 40A 30mA (Nam zona)", kind: "RCD", modules: 2, poles: 2, defaultPrice: 220000 },
  { name: "RCBO (Diftavtomat) · 16A 30mA", kind: "RCBO", modules: 2, poles: 2, defaultPrice: 190000 },
  { name: "Raqamli kuchlanish relesi (Zubr/Volt)", kind: "Contactor", modules: 2, poles: 2, defaultPrice: 180000 },
  { name: "N/PE Nol va Yerlash shinasi", kind: "Terminal", modules: 1, poles: 1, defaultPrice: 25000 },
];

export default function PanelPage() {
  const { project, update, t } = useStore();
  const [selectedCatalog, setSelectedCatalog] = useState(0);
  const [selectedId, setSelectedId] = useState("");
  const [view, setView] = useState<PanelView>("iso");
  const [cover, setCover] = useState(false);
  const [diagramMode, setDiagramMode] = useState<"3d" | "singleline">("3d");

  const onSelect = useCallback((id: string) => setSelectedId(id), []);
  const [models, setModels] = useState({ loaded: 0, total: 0 });
  const onModelStatus = useCallback(
    (loaded: number, total: number) =>
      setModels((m) => (m.loaded === loaded && m.total === total ? m : { loaded, total })),
    [],
  );

  const used = project?.panel.reduce((n, d) => n + d.modules, 0) ?? 0;
  const active = project?.panel.find((d) => d.id === selectedId);
  const cost = project?.panel.reduce((n, d) => n + (d.unitPrice ?? 0), 0) ?? 0;

  function edit(id: string, values: Partial<PanelDevice>) {
    if (!project) return;
    update(project.id, (p) => ({
      ...p,
      panel: p.panel.map((d) => (d.id === id ? { ...d, ...values } : d)),
    }));
  }

  function move(index: number, direction: -1 | 1) {
    if (!project || index + direction < 0 || index + direction >= project.panel.length) return;
    update(project.id, (p) => {
      const panel = [...p.panel];
      [panel[index], panel[index + direction]] = [panel[index + direction], panel[index]];
      return { ...p, panel };
    });
  }

  function autoPopulateFromRooms() {
    if (!project) return;
    // Build intelligent panel structure based on rooms
    const newDevices: PanelDevice[] = [
      {
        id: newId(),
        name: "Kirish 2P C40A (40A / 230V)",
        kind: "MCB",
        modules: 2,
        poles: 2,
        unitPrice: 85000,
      },
      {
        id: newId(),
        name: "Kuchlanish nazorati relesi (63A)",
        kind: "Contactor",
        modules: 2,
        poles: 2,
        unitPrice: 180000,
      },
      {
        id: newId(),
        name: "Yong'inga qarshi UZO 40A 100mA",
        kind: "RCD",
        modules: 2,
        poles: 2,
        unitPrice: 220000,
      },
    ];

    project.rooms.forEach((r, idx) => {
      const hasSockets = r.points.some((p) => p.kind === "outlet");
      const hasLights = r.points.some((p) => p.kind === "light");

      if (hasLights && newDevices.reduce((n, d) => n + d.modules, 0) + 1 <= 20) {
        newDevices.push({
          id: newId(),
          name: `${r.name}: Yoritish B10A`,
          kind: "MCB",
          modules: 1,
          poles: 1,
          unitPrice: 35000,
        });
      }

      if (hasSockets && newDevices.reduce((n, d) => n + d.modules, 0) + 1 <= 20) {
        const isWet = r.name.toLowerCase().includes("hammom") || r.name.toLowerCase().includes("vanna");
        newDevices.push({
          id: newId(),
          name: `${r.name}: Rozetkalar ${isWet ? "RCBO 16A/10mA" : "C16A"}`,
          kind: isWet ? "RCBO" : "MCB",
          modules: isWet ? 2 : 1,
          poles: isWet ? 2 : 1,
          unitPrice: isWet ? 190000 : 38000,
        });
      }
    });

    if (newDevices.reduce((n, d) => n + d.modules, 0) + 1 <= 20) {
      newDevices.push({
        id: newId(),
        name: "Nol va PE Yerlash shinalari",
        kind: "Terminal",
        modules: 1,
        poles: 1,
        unitPrice: 25000,
      });
    }

    update(project.id, (p) => ({ ...p, panel: newDevices }));
  }

  return (
    <>
      <SectionHead
        eyebrow="PANEL DESIGN / 03"
        title={t("panel")}
        description="20 modulli standart DIN-reyka taqsimlash shchiti. 3D vizualizatsiya va professional bir chiziqli (odnolineynaya) elektr sxemasi."
        action={
          project && (
            <div className="flex items-center gap-2">
              <button
                className="btn primary"
                onClick={autoPopulateFromRooms}
                title="Xonalar bo'yicha shchitni avtomatik shakllantirish"
              >
                <Sparkles size={16} /> AI Shchitni to'ldirish
              </button>
              <button
                className="btn outline"
                onClick={() =>
                  downloadFile(
                    "panel-bom.json",
                    JSON.stringify(
                      {
                        projectId: project.id,
                        currency: project.currency,
                        devices: project.panel,
                        totalEnteredPrice: cost,
                      },
                      null,
                      2,
                    ),
                  )
                }
              >
                <Download size={16} /> BOM JSON
              </button>
            </div>
          )
        }
      />
      <ProjectGate>
        <div className="workspace-grid panel-layout">
          <Panel label="MODUL KUTUBXONASI" title="DIN-reykaga qo'shish">
            <div className="catalog-list space-y-1.5">
              {catalog.map((device, i) => (
                <button
                  key={device.name}
                  className={`catalog-row ${selectedCatalog === i ? "selected" : ""}`}
                  onClick={() => setSelectedCatalog(i)}
                >
                  <span className="mini-device font-mono">{device.modules}M</span>
                  <span>
                    <strong>{device.name}</strong>
                    <small>
                      {device.kind} · {device.poles} qutbli
                    </small>
                  </span>
                </button>
              ))}
            </div>
            <button
              className="btn primary full mt-4"
              disabled={used + catalog[selectedCatalog].modules > 20}
              onClick={() => {
                if (!project) return;
                const chosen = catalog[selectedCatalog];
                const item = {
                  name: chosen.name,
                  kind: chosen.kind,
                  modules: chosen.modules,
                  poles: chosen.poles,
                  id: newId(),
                  unitPrice: chosen.defaultPrice,
                };
                update(project.id, (p) => ({ ...p, panel: [...p.panel, item] }));
                setSelectedId(item.id);
              }}
            >
              <Plus size={17} /> DIN-reykaga o'rnatish
            </button>
            <p className="help-text">
              Standart 1 qatorli DIN-reyka 20 ta modulni sig'diradi. Shinalar va avtomatlar ketma-ket joylashadi.
            </p>
          </Panel>

          <div>
            <Panel
              label="TAQSIMLASH SHCHITI WORKBENCH"
              title={diagramMode === "3d" ? "3D Taqsimlash shchiti" : "Bir chiziqli sxema"}
              action={
                <div className="flex items-center gap-2">
                  <div className="flex rounded-lg bg-[#07111f] p-0.5 border border-[#23374f]">
                    <button
                      onClick={() => setDiagramMode("3d")}
                      className={`px-3 py-1 rounded text-xs font-semibold flex items-center gap-1.5 transition ${
                        diagramMode === "3d"
                          ? "bg-[#3b8cff] text-white"
                          : "text-[#9bb0c8] hover:text-white"
                      }`}
                    >
                      <Boxes size={14} /> 3D Shchit
                    </button>
                    <button
                      onClick={() => setDiagramMode("singleline")}
                      className={`px-3 py-1 rounded text-xs font-semibold flex items-center gap-1.5 transition ${
                        diagramMode === "singleline"
                          ? "bg-[#3b8cff] text-white"
                          : "text-[#9bb0c8] hover:text-white"
                      }`}
                    >
                      <CircuitBoard size={14} /> Bir chiziqli sxema
                    </button>
                  </div>
                  <span className={`status-chip ${used > 20 ? "danger" : ""}`}>
                    {used} / 20 modul
                  </span>
                </div>
              }
            >
              {diagramMode === "3d" ? (
                <>
                  <div className="viewport-toolbar">
                    <span>KAMERA</span>
                    {(["iso", "front", "side"] as PanelView[]).map((preset) => (
                      <button
                        key={preset}
                        className={`tool-pill ${view === preset ? "active" : ""}`}
                        onClick={() => setView(preset)}
                      >
                        {preset}
                      </button>
                    ))}
                    <button
                      className={`tool-pill ${cover ? "active" : ""}`}
                      onClick={() => setCover(!cover)}
                    >
                      <Eye size={14} /> {cover ? "Qopqoqni yopish" : "Qopqoqni ko'rsatish"}
                    </button>
                  </div>
                  {project && (
                    <Panel3D
                      devices={project.panel}
                      selectedId={selectedId}
                      onSelect={onSelect}
                      onModelStatus={onModelStatus}
                      view={view}
                      cover={cover}
                    />
                  )}
                  {used > 20 && (
                    <div className="alert danger" role="alert">
                      Reykada 20 ta modul joy bor, lekin {used} ta qo'shildi. Ortiqchalari sig'maydi!
                    </div>
                  )}
                  <div className="capacity-track">
                    <span style={{ width: `${Math.min(100, (used / 20) * 100)}%` }} />
                  </div>
                  <div className="plan-footer">
                    <span>Tahrirlash uchun modulni bosing · Aylanib ko'rish: sichqoncha bilan</span>
                    <span>Modullar DIN 35/7.5mm standartida</span>
                  </div>
                </>
              ) : (
                /* SINGLE-LINE DIAGRAM (BIR CHIZIQLI SXEMA) */
                <div className="singleline-view p-6 bg-[#07111f] rounded-xl border border-[#23374f] overflow-x-auto min-h-[380px]">
                  <div className="text-xs font-mono text-[#6e849d] mb-4 flex items-center justify-between">
                    <span>BIR CHIZIQLI ELEKTR TAQSIMLASH SXEMASI (PUE / GOST 21.608)</span>
                    <span className="text-[#37c99b]">Tarmoq: 230V / 50Hz · TN-C-S</span>
                  </div>

                  <svg viewBox="0 0 860 360" className="w-full min-w-[700px] h-auto font-mono text-xs">
                    {/* Incomer feed */}
                    <line x1="60" y1="30" x2="60" y2="90" stroke="#f47785" strokeWidth="4" />
                    <text x="75" y="45" fill="#f47785" fontSize="11" fontWeight="bold">
                      KIRISH: 230V (L+N+PE)
                    </text>

                    {/* Main Incomer Breaker */}
                    <rect x="40" y="90" width="40" height="50" fill="#102137" stroke="#3b8cff" strokeWidth="2" rx="4" />
                    <text x="60" y="120" fill="#ffffff" fontSize="10" textAnchor="middle">
                      QF1
                    </text>
                    <text x="60" y="160" fill="#9bb0c8" fontSize="9" textAnchor="middle">
                      C40A 2P
                    </text>

                    {/* Busbar trunk */}
                    <line x1="60" y1="140" x2="60" y2="180" stroke="#3b8cff" strokeWidth="3" />
                    <line x1="60" y1="180" x2="820" y2="180" stroke="#e9b663" strokeWidth="5" />
                    <text x="825" y="184" fill="#e9b663" fontSize="11" fontWeight="bold">
                      L SHINASI
                    </text>

                    {/* PE Ground Busbar */}
                    <line x1="60" y1="310" x2="820" y2="310" stroke="#37c99b" strokeWidth="4" strokeDasharray="6 3" />
                    <text x="825" y="314" fill="#37c99b" fontSize="11" fontWeight="bold">
                      PE YERLASH
                    </text>

                    {/* Branch devices */}
                    {project?.panel.map((d, idx) => {
                      const count = Math.max(1, project.panel.length);
                      const spacing = Math.min(110, 720 / count);
                      const x = 110 + idx * spacing;
                      const isRcd = d.kind === "RCD" || d.kind === "RCBO";

                      return (
                        <g key={d.id} className="cursor-pointer" onClick={() => setSelectedId(d.id)}>
                          {/* Feed from busbar */}
                          <line x1={x} y1="180" x2={x} y2="210" stroke="#e9b663" strokeWidth="2" />
                          <circle cx={x} cy="180" r="3" fill="#e9b663" />

                          {/* Device symbol box */}
                          <rect
                            x={x - 18}
                            y="210"
                            width="36"
                            height="44"
                            fill={selectedId === d.id ? "#3b8cff" : isRcd ? "#1a364d" : "#102137"}
                            stroke={isRcd ? "#4bc8dc" : "#23374f"}
                            strokeWidth="1.5"
                            rx="3"
                          />
                          <text x={x} y="232" fill="#ffffff" fontSize="9" textAnchor="middle" fontWeight="bold">
                            {d.kind}
                          </text>
                          <text x={x} y="246" fill="#9bb0c8" fontSize="8" textAnchor="middle">
                            {d.poles}P
                          </text>

                          {/* Outgoing cable line */}
                          <line x1={x} y1="254" x2={x} y2="285" stroke="#9bb0c8" strokeWidth="2" />
                          <text x={x} y="295" fill="#f1f6fc" fontSize="8" textAnchor="middle">
                            3x{d.name.includes("B10") ? "1.5" : d.name.includes("C25") ? "4.0" : "2.5"}
                          </text>

                          {/* Circuit label */}
                          <text
                            x={x}
                            y="335"
                            fill="#9bb0c8"
                            fontSize="8"
                            textAnchor="middle"
                            className="truncate"
                          >
                            {d.name.slice(0, 10)}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>
              )}
            </Panel>

            <Panel label="MODUL SOZLAMALARI" title={active ? active.name : "Modulni tanlang"}>
              {active ? (
                <div className="form-stack space-y-4">
                  <div className="form-row grid grid-cols-2 gap-3">
                    <label>
                      Nomi & Xarakteristikasi
                      <input
                        aria-label="Panel device label"
                        value={active.name}
                        onChange={(e) => edit(active.id, { name: e.target.value })}
                        className="w-full p-2.5 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                      />
                    </label>
                    <label>
                      Qutblar soni (Poles)
                      <NumberField
                        label="Qutblar soni"
                        min={1}
                        max={4}
                        step={1}
                        value={active.poles ?? 1}
                        commit={(n) => {
                          if (!Number.isInteger(n)) return "Qutb butun son bo'lishi kerak.";
                          const modules = active.kind === "Terminal" ? active.modules : n;
                          if (used - active.modules + modules > 20)
                            return `20 modulli reykada joy yetarli emas (${20 - used + active.modules}M bo'sh).`;
                          edit(active.id, { poles: n, modules });
                        }}
                      />
                    </label>
                  </div>
                  <div className="form-row grid grid-cols-3 gap-3">
                    <label>
                      Ishlab chiqaruvchi (Brend)
                      <input
                        aria-label="Manufacturer"
                        placeholder="Schneider, ABB, IEK, Chint..."
                        value={active.manufacturer ?? ""}
                        onChange={(e) => edit(active.id, { manufacturer: e.target.value })}
                        className="w-full p-2 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                      />
                    </label>
                    <label>
                      Model / Seriya
                      <input
                        aria-label="Model reference"
                        placeholder="Acti9, SH200, BKN..."
                        value={active.model ?? ""}
                        onChange={(e) => edit(active.id, { model: e.target.value })}
                        className="w-full p-2 rounded-xl bg-[#0a1829] border border-[#23374f] text-xs text-white"
                      />
                    </label>
                    <label>
                      Narxi ({project?.currency})
                      <NumberField
                        label="Narxi"
                        min={0}
                        value={active.unitPrice ?? 0}
                        commit={(n) => void edit(active.id, { unitPrice: n })}
                      />
                    </label>
                  </div>
                  <div className="flex items-center justify-between pt-2">
                    <div className="flex gap-2">
                      <button
                        className="btn outline text-xs"
                        onClick={() => {
                          const idx = project?.panel.findIndex((d) => d.id === active.id) ?? -1;
                          move(idx, -1);
                        }}
                      >
                        <ChevronLeft size={14} /> Chapga surish
                      </button>
                      <button
                        className="btn outline text-xs"
                        onClick={() => {
                          const idx = project?.panel.findIndex((d) => d.id === active.id) ?? -1;
                          move(idx, 1);
                        }}
                      >
                        O'ngga surish <ChevronRight size={14} />
                      </button>
                    </div>
                    <button
                      className="btn outline danger text-xs"
                      onClick={() => {
                        if (!project) return;
                        update(project.id, (p) => ({
                          ...p,
                          panel: p.panel.filter((d) => d.id !== active.id),
                        }));
                        setSelectedId("");
                      }}
                    >
                      <Trash2 size={14} /> O'chirish
                    </button>
                  </div>
                </div>
              ) : (
                <p className="muted text-xs text-[#6e849d]">
                  Tahrirlash uchun 3D ko'rinishdagi yoki ro'yxatdagi istalgan modul ustiga bosing.
                </p>
              )}
            </Panel>
          </div>
        </div>
      </ProjectGate>
    </>
  );
}
