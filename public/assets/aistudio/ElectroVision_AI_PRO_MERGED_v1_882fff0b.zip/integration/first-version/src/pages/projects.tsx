import { useState } from "react";
import { Link } from "wouter";
import { BarChart3, Copy, Download, FolderKanban, Plus, Search, Trash2 } from "lucide-react";
import { Panel, SectionHead } from "../components/shell";
import { downloadFile, slug } from "../model/project";
import { useStore } from "../model/store";
const statusLabel = { planning: "Planning", "in-progress": "In progress", completed: "Completed" } as const;
export default function Projects() {
  const { db, project, choose, addProject, update, remove, t } = useStore();
  const [query, setQuery] = useState("");
  const [newName, setNewName] = useState("");
  return (
    <>
      <SectionHead
        eyebrow="PROJECT MANAGEMENT / 01"
        title={t("projects")}
        description="A single project keeps rooms, calculations, estimates and panel layouts connected."
        action={
          <button
            className="btn primary"
            onClick={() => window.dispatchEvent(new Event("electrovision:create"))}
          >
            <Plus size={17} />
            {t("create")}
          </button>
        }
      />
      <div className="workspace-grid two">
        <Panel
          title="Your projects"
          label={`${db.projects.length} SAVED LOCALLY`}
          action={
            <div className="search-field">
              <Search size={16} />
              <input
                aria-label={t("search")}
                placeholder={t("search")}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
          }
        >
          {db.projects.length ? (
            <div className="project-list">
              {db.projects
                .filter((p) => p.name.toLowerCase().includes(query.toLowerCase()))
                .map((p) => (
                  <button
                    className={`project-row ${project?.id === p.id ? "selected" : ""}`}
                    key={p.id}
                    onClick={() => choose(p.id)}
                  >
                    <div className="project-avatar">
                      <FolderKanban size={19} />
                    </div>
                    <span>
                      <strong>{p.name}</strong>
                      <small>
                        {p.type} · {new Date(p.updatedAt).toLocaleDateString()}
                      </small>
                    </span>
                    <em>{statusLabel[p.status]}</em>
                  </button>
                ))}
            </div>
          ) : (
            <div className="small-empty">
              <FolderKanban size={25} />
              <strong>{t("noProject")}</strong>
              <p>{t("start")}</p>
            </div>
          )}
        </Panel>
        <Panel
          title={project ? "Project details" : "Get started"}
          label={project ? "ACTIVE PROJECT" : "NEW PROJECT"}
        >
          {project ? (
            <div className="form-stack" key={project.id}>
              <label>
                {t("name")}
                <input
                  key={project.name}
                  defaultValue={project.name}
                  onBlur={(e) => {
                    if (e.target.value.trim())
                      update(project.id, (p) => ({ ...p, name: e.target.value.trim() }));
                    else e.target.value = project.name;
                  }}
                />
              </label>
              <label>
                {t("description")}
                <textarea
                  key={project.description}
                  defaultValue={project.description}
                  onBlur={(e) => update(project.id, (p) => ({ ...p, description: e.target.value }))}
                  rows={3}
                />
              </label>
              <div className="form-row">
                <label>
                  Project type
                  <select
                    value={project.type}
                    onChange={(e) => update(project.id, (p) => ({ ...p, type: e.target.value }))}
                  >
                    <option>Residential</option>
                    <option>Commercial</option>
                    <option>Industrial</option>
                    <option>Other</option>
                  </select>
                </label>
                <label>
                  Status
                  <select
                    value={project.status}
                    onChange={(e) =>
                      update(project.id, (p) => ({
                        ...p,
                        status: e.target.value as typeof p.status,
                      }))
                    }
                  >
                    <option value="planning">Planning</option>
                    <option value="in-progress">In progress</option>
                    <option value="completed">Completed</option>
                  </select>
                </label>
              </div>
              <div className="detail-meta">
                <span>Created {new Date(project.createdAt).toLocaleDateString()}</span>
                <span>ID {project.id.slice(0, 8)}</span>
              </div>
              <div className="button-row">
                <Link href="/" className="btn primary">
                  <BarChart3 size={15} /> Overview Dashboard
                </Link>
                <button
                  className="btn outline"
                  onClick={() => {
                    const copy = structuredClone(project);
                    const fresh = addProject(`${project.name} (copy)`);
                    update(fresh.id, () => ({
                      ...copy,
                      id: fresh.id,
                      name: fresh.name,
                      createdAt: fresh.createdAt,
                    }));
                  }}
                >
                  <Copy size={15} /> Duplicate
                </button>
                <button
                  className="btn outline"
                  onClick={() =>
                    downloadFile(
                      `${slug(project.name)}.json`,
                      JSON.stringify({ version: 1, project }, null, 2),
                    )
                  }
                >
                  <Download size={15} /> JSON
                </button>
                <button
                  className="btn danger-button"
                  onClick={() => {
                    if (
                      window.confirm(
                        `Delete “${project.name}” and all associated data? This cannot be undone.`,
                      )
                    )
                      remove(project.id);
                  }}
                >
                  <Trash2 size={15} />
                  {t("delete")}
                </button>
              </div>
              <small className="help-text">Changes are saved when you leave a field.</small>
            </div>
          ) : (
            <form
              className="form-stack"
              onSubmit={(e) => {
                e.preventDefault();
                if (newName.trim()) {
                  addProject(newName);
                  setNewName("");
                }
              }}
            >
              <p className="muted">Create a project to unlock connected workspaces.</p>
              <label>
                {t("name")}
                <input
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Tashkent · Office fit-out"
                />
              </label>
              <button className="btn primary" type="submit">
                <Plus size={16} />
                {t("create")}
              </button>
            </form>
          )}
        </Panel>
      </div>
    </>
  );
}
