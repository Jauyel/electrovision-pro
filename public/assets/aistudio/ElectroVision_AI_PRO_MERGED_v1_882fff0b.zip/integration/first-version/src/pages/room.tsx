import { useState } from "react";
import {
  AlertTriangle,
  Download,
  Eye,
  FileText,
  Gauge,
  Lightbulb,
  MousePointer2,
  Plus,
  ScanLine,
  ShieldAlert,
  Sparkles,
  Trash2,
  Zap,
} from "lucide-react";
import { Panel, ProjectGate, SectionHead } from "../components/shell";
import { Room3D, type CameraView } from "../components/room-3d";
import { CameraRoom } from "../components/camera-room";
import { OpeningsEditor } from "../components/openings-editor";
import { RoutesEditor } from "../components/routes-editor";
import { NumberField } from "../components/number-field";
import { openingError, routePath } from "../model/geometry";
import { downloadItemizedPdfReport } from "../lib/pdf-report";
import {
  calculateRoomLoad,
  downloadFile,
  getPointPowerKw,
  makeRoom,
  newId,
  type PointKind,
  type Room,
} from "../model/project";
import { useStore } from "../model/store";
export function FloorPlan({
  room,
  tool,
  onAdd,
  onSelect,
  onMove,
  selected,
}: {
  room: Room;
  tool: PointKind | "select";
  onAdd: (x: number, y: number) => void;
  onSelect: (id: string) => void;
  onMove: (id: string, x: number, y: number) => void;
  selected?: string;
}) {
  const [drag, setDrag] = useState("");
  const scale = Math.min(530 / room.length, 372 / room.width);
  const width = room.length * scale,
    height = room.width * scale;
  const x0 = (600 - width) / 2,
    y0 = (440 - height) / 2;
  const coords = (
    e: React.MouseEvent<HTMLButtonElement> | React.PointerEvent<HTMLButtonElement>,
  ) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const fit = Math.min(rect.width / 600, rect.height / 440);
    const px = (e.clientX - rect.left - (rect.width - 600 * fit) / 2) / fit;
    const py = (e.clientY - rect.top - (rect.height - 440 * fit) / 2) / fit;
    return {
      x: Math.max(0, Math.min(1, (px - x0) / width)),
      y: Math.max(0, Math.min(1, (py - y0) / height)),
      inside: px >= x0 && px <= x0 + width && py >= y0 && py <= y0 + height,
    };
  };
  return (
    <div className="plan-wrapper">
      <div className="plan-measure top">{room.length} m</div>
      <div className="plan-measure side">{room.width} m</div>
      <button
        type="button"
        className="floor-svg"
        aria-label={`2D floor plan for ${room.name}; activate to place ${tool}`}
        onPointerMove={(e) => {
          if (drag && e.buttons) {
            const pos = coords(e);
            onMove(drag, pos.x, pos.y);
          }
        }}
        onPointerUp={() => setDrag("")}
        onPointerCancel={() => setDrag("")}
        onClick={(e) => {
          if (drag || tool === "select") return;
          if (e.detail === 0) {
            onAdd(0.5, 0.5);
            return;
          }
          const pos = coords(e);
          if (pos.inside) onAdd(pos.x, pos.y);
        }}
      >
        <svg
          viewBox="0 0 600 440"
          preserveAspectRatio="xMidYMid meet"
          style={{ width: "100%", height: "100%" }}
        >
          <defs>
            <pattern id="plan-grid" width="26" height="26" patternUnits="userSpaceOnUse">
              <path d="M 26 0 L 0 0 0 26" fill="none" stroke="#25415b" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="600" height="440" fill="url(#plan-grid)" />
          <rect
            x={x0}
            y={y0}
            width={width}
            height={height}
            fill="#14314844"
            stroke="#80badb"
            strokeWidth="7"
          />
          <text
            x="300"
            y="220"
            fill="#6c91a9"
            fontSize="14"
            textAnchor="middle"
            fontFamily="monospace"
          >
            {room.name.toUpperCase()} · {(room.length * room.width).toFixed(2)} m²
          </text>
          {(room.openings ?? []).map((o) => {
            const a = o.offset * scale,
              b = o.width * scale;
            const horizontal = o.wall === "north" || o.wall === "south";
            const cx = horizontal ? x0 + a + b / 2 : o.wall === "west" ? x0 : x0 + width;
            const cy = horizontal ? (o.wall === "north" ? y0 : y0 + height) : y0 + a + b / 2;
            return (
              <g key={o.id}>
                <line
                  x1={horizontal ? cx - b / 2 : cx}
                  y1={horizontal ? cy : cy - b / 2}
                  x2={horizontal ? cx + b / 2 : cx}
                  y2={horizontal ? cy : cy + b / 2}
                  stroke="#0a192a"
                  strokeWidth="10"
                />
                <line
                  x1={horizontal ? cx - b / 2 : cx}
                  y1={horizontal ? cy : cy - b / 2}
                  x2={horizontal ? cx + b / 2 : cx}
                  y2={horizontal ? cy : cy + b / 2}
                  stroke={o.kind === "door" ? "#e8bd82" : "#75d5e5"}
                  strokeWidth={o.kind === "door" ? 3 : 6}
                />
                <text
                  x={cx + (horizontal ? 0 : 14)}
                  y={cy + (horizontal ? (o.wall === "north" ? 16 : -9) : 4)}
                  textAnchor={horizontal ? "middle" : "start"}
                  fill="#a5c7d5"
                  fontSize="9"
                  fontFamily="monospace"
                >
                  {o.kind === "door" ? "D" : "W"} {o.width}m
                </text>
              </g>
            );
          })}
          {(room.routes ?? []).map((route) => {
            const points = routePath(room, route);
            return points ? (
              <polyline
                key={route.id}
                points={points.map((p) => `${x0 + p.x * width},${y0 + p.y * height}`).join(" ")}
                fill="none"
                stroke="#f6ba75"
                strokeWidth="2.5"
                strokeDasharray="8 5"
              />
            ) : null;
          })}
          {room.points.map((p) => (
            <g
              key={p.id}
              transform={`translate(${x0 + p.x * width} ${y0 + p.y * height})`}
              onPointerDown={(e) => {
                e.stopPropagation();
                if (tool === "select") {
                  setDrag(p.id);
                  onSelect(p.id);
                  e.currentTarget.parentElement?.parentElement?.setPointerCapture(e.pointerId);
                }
              }}
              onClick={(e) => {
                e.stopPropagation();
                onSelect(p.id);
              }}
              style={{ cursor: "grab" }}
            >
              <circle
                r="16"
                fill={p.id === selected ? "#3b8cff" : "#10273c"}
                stroke={p.id === selected ? "#a9d3ff" : p.kind === "light" ? "#edca86" : "#64bdd5"}
                strokeWidth="2"
              />
              <text
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="14"
                fontWeight="bold"
                fill="#f1f6fc"
              >
                {{ outlet: "O", switch: "S", light: "L", panel: "P", junction: "J" }[p.kind]}
              </text>
            </g>
          ))}
        </svg>
      </button>
      <div className="plan-coordinates">
        Scaled geometry · {room.length} × {room.width} m
      </div>
    </div>
  );
}
export default function RoomPage({ mode = "room" }: { mode?: "room" | "installation" }) {
  const { project, update, t, db } = useStore();
  const [selectedRoom, setSelectedRoom] = useState("");
  const [selectedPoint, setSelectedPoint] = useState("");
  const [tool, setTool] = useState<PointKind | "select">("select");
  const [name, setName] = useState("");
  const [view, setView] = useState<"2d" | "3d">("2d");
  const [cameraView, setCameraView] = useState<CameraView>("iso");
  const [transparentWalls, setTransparentWalls] = useState(true);
  const [showCeiling, setShowCeiling] = useState(false);
  const [nightMode, setNightMode] = useState(false);
  const [showLoadIndicator, setShowLoadIndicator] = useState(true);

  const room = project?.rooms.find((r) => r.id === selectedRoom) ?? project?.rooms[0];
  const point = room?.points.find((p) => p.id === selectedPoint);
  const roomLoad = room ? calculateRoomLoad(room) : null;
  const overloadedRooms = (project?.rooms ?? [])
    .map((r) => ({ room: r, load: calculateRoomLoad(r) }))
    .filter((x) => x.load.isOver80);

  const mutate = (fn: (r: Room) => Room) => {
    if (!project || !room) return;
    update(project.id, (p) => ({
      ...p,
      rooms: p.rooms.map((r) => (r.id === room.id ? fn(r) : r)),
    }));
  };
  const addPoint = (x: number, y: number) => {
    if (tool === "select") return;
    const id = newId();
    mutate((r) => ({
      ...r,
      points: [
        ...r.points,
        {
          id,
          kind: tool,
          x,
          y,
          label: `${tool} ${r.points.filter((p) => p.kind === tool).length + 1}`,
        },
      ],
    }));
    setSelectedPoint(id);
  };
  return (
    <>
      <SectionHead
        eyebrow={mode === "room" ? "SITE PLANNING / 02" : "INSTALLATION / 03"}
        title={t(mode === "room" ? "scanner" : "installation")}
        description={
          mode === "room"
            ? "Manual dimensions and saved openings drive linked 2D and Three.js 3D views. Camera photos assist the survey; measurements remain manual."
            : "Place and move proposed electrical points on saved rooms. Routes are geometric estimates, not verified wiring."
        }
        action={
          <div className="flex items-center gap-2">
            <button
              className="btn primary"
              onClick={() =>
                window.dispatchEvent(
                  new CustomEvent("electrovision:ai", { detail: { tab: "scan" } })
                )
              }
            >
              <Sparkles size={16} /> AI Chizma Skaneri
            </button>
            {project && (
              <button
                className="btn outline"
                onClick={() => downloadItemizedPdfReport(project)}
                title="Kabel marshrutlari va yuklama hisobotini PDF formatida yuklab olish"
              >
                <FileText size={16} /> Itemized PDF
              </button>
            )}
            {room && (
              <button
                className="btn outline"
                onClick={() =>
                  downloadFile(
                    `room-${room.name.replace(/[^a-z0-9]/gi, "-")}.json`,
                    JSON.stringify(room, null, 2),
                  )
                }
              >
                <Download size={16} /> JSON
              </button>
            )}
          </div>
        }
      />
      <ProjectGate>
        <div className="room-layout">
          <Panel label="ROOMS / METRIC" title="Room setup" className="room-sidebar">
            <form
              className="add-room"
              onSubmit={(e) => {
                e.preventDefault();
                if (!project || !name.trim()) return;
                const r = makeRoom(name);
                update(project.id, (p) => ({ ...p, rooms: [...p.rooms, r] }));
                setSelectedRoom(r.id);
                setName("");
              }}
            >
              <label>
                New room name
                <input
                  aria-label="New room name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Living room"
                />
              </label>
              <button className="btn primary" type="submit">
                <Plus size={17} /> Add room
              </button>
            </form>
            <div className="room-list">
              {project?.rooms.map((r) => {
                const rLoad = calculateRoomLoad(r);
                return (
                  <button
                    key={r.id}
                    className={`room-list-item ${room?.id === r.id ? "selected" : ""} ${rLoad.isOver80 ? "has-overload" : ""}`}
                    onClick={() => {
                      setSelectedRoom(r.id);
                      setSelectedPoint("");
                    }}
                  >
                    <ScanLine size={17} />
                    <span className="room-list-info">
                      <strong className="room-list-name">{r.name}</strong>
                      <small>
                        {r.length} × {r.width} m · {r.points.length} nuqta
                      </small>
                    </span>
                    <span
                      className={`room-load-chip ${rLoad.status}`}
                      title={`${rLoad.statusLabel[db.language]}: ${rLoad.ratioPercent.toFixed(1)}% (${rLoad.totalLoadKw} / ${rLoad.capacityKw} kW)`}
                    >
                      {rLoad.isOver100 ? "🚨" : rLoad.isOver80 ? "⚠️" : "⚡"}{" "}
                      {rLoad.ratioPercent.toFixed(0)}%
                    </span>
                  </button>
                );
              })}
            </div>
            {room && (
              <div className="room-inputs">
                <div className="eyebrow">DIMENSIONS / VERIFIED MANUALLY</div>
                {(["length", "width", "height"] as const).map((key) => (
                  <label key={key}>
                    {key.charAt(0).toUpperCase() + key.slice(1)} (m)
                    <NumberField
                      label={`${key} in metres`}
                      min={0.1}
                      max={1000}
                      step={0.1}
                      decimals={3}
                      value={room[key]}
                      commit={(value) => {
                        const candidate = { ...room, [key]: value };
                        const invalid = (room.openings ?? []).find((opening) =>
                          openingError(candidate, opening, opening.id),
                        );
                        if (invalid) return `Cannot set ${key} to ${value} m: ${invalid.label} would no longer fit.`;
                        mutate((r) => ({ ...r, [key]: value }));
                      }}
                    />
                  </label>
                ))}
                <label>
                  Wall thickness (m)
                  <NumberField
                    label="Wall thickness in metres"
                    min={0.05}
                    max={0.6}
                    step={0.01}
                    decimals={3}
                    value={room.wallThickness ?? 0.16}
                    commit={(n) => void mutate((r) => ({ ...r, wallThickness: n }))}
                  />
                </label>
                <div className="eyebrow" style={{ marginTop: 14 }}>
                  CIRCUIT BREAKER / ELECTRICAL RATING
                </div>
                <label>
                  Avtomat o'chirgich quvvati (Breaker)
                  <select
                    value={room.maxCapacityKw ?? 3.68}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      mutate((r) => ({ ...r, maxCapacityKw: val }));
                    }}
                  >
                    <option value={2.3}>10A · 2.30 kW (Yoritish liniyasi)</option>
                    <option value={3.68}>16A · 3.68 kW (Standart rozetkalar, 230V)</option>
                    <option value={4.6}>20A · 4.60 kW (Konditsioner / Oshxona)</option>
                    <option value={5.75}>25A · 5.75 kW (Yuqori quvvat / Plita)</option>
                    <option value={7.36}>32A · 7.36 kW (Asosiy taqsimlash)</option>
                  </select>
                </label>
                {roomLoad && (
                  <div className={`room-sidebar-load ${roomLoad.status}`}>
                    <div className="sidebar-load-row">
                      <span>Yuklama:</span>
                      <strong>
                        {roomLoad.totalLoadKw.toFixed(2)} / {roomLoad.capacityKw.toFixed(2)} kW
                      </strong>
                    </div>
                    <div className="sidebar-load-track">
                      <span
                        style={{
                          width: `${Math.min(100, (roomLoad.ratioPercent / 120) * 100)}%`,
                          backgroundColor: roomLoad.colorHex,
                        }}
                      />
                    </div>
                    <small>
                      {roomLoad.isOver100
                        ? "🚨 O'ta yuklama (>100%)"
                        : roomLoad.isOver80
                          ? "⚠️ 80% me'yordan oshgan"
                          : "✓ Optimal ishchi rejim"}
                    </small>
                  </div>
                )}
                <div className="room-metric">
                  <span>Floor area</span>
                  <strong>{(room.length * room.width).toFixed(2)} m²</strong>
                </div>
                <button
                  className="text-link danger-text"
                  onClick={() => {
                    if (window.confirm(`Delete room “${room.name}” and its points?`))
                      update(project!.id, (p) => ({
                        ...p,
                        rooms: p.rooms.filter((r) => r.id !== room.id),
                      }));
                  }}
                >
                  <Trash2 size={15} /> Delete room
                </button>
              </div>
            )}
          </Panel>
          <div className="room-main">
            {room ? (
              <>
                {overloadedRooms.length > 0 && (
                  <div className="overload-alert-banner">
                    <div className="alert-content">
                      <AlertTriangle className="alert-icon" size={20} />
                      <div>
                        <strong>
                          ELEKTR YUKLAMA OGOHLANTIRISHI: {overloadedRooms.length} ta xonada yuklama 80% dan oshgan!
                        </strong>
                        <p>
                          PUE 7.1 va NEC qoidasiga ko'ra, xavfsiz uzluksiz foydalanish uchun xona yuklamasi avtomat quvvatining 80% idan oshmasligi shart.
                        </p>
                      </div>
                    </div>
                    <div className="overload-jump-pills">
                      {overloadedRooms.map(({ room: ovr, load }) => (
                        <button
                          key={ovr.id}
                          type="button"
                          className={`overload-pill ${load.isOver100 ? "critical" : "warning"} ${room.id === ovr.id ? "active" : ""}`}
                          onClick={() => {
                            setSelectedRoom(ovr.id);
                            setView("3d");
                          }}
                        >
                          {load.isOver100 ? "🚨" : "⚠️"} {ovr.name}: {load.ratioPercent.toFixed(0)}%
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <Panel
                  label="PLAN / 1: PROPORTIONAL"
                  title={room.name}
                  action={
                    <div className="segmented">
                      <button
                        className={view === "2d" ? "active" : ""}
                        onClick={() => setView("2d")}
                      >
                        2D plan
                      </button>
                      <button
                        className={view === "3d" ? "active" : ""}
                        onClick={() => setView("3d")}
                      >
                        3D room
                      </button>
                    </div>
                  }
                >
                  <div className="plan-toolbar">
                    <span>PLACE</span>
                    {(["select", "outlet", "switch", "light", "junction", "panel"] as const).map(
                      (key) => (
                        <button
                          key={key}
                          className={`tool-pill ${tool === key ? "active" : ""}`}
                          onClick={() => {
                            setTool(key);
                            setView("2d");
                          }}
                        >
                          <span>
                            {key === "select" ? (
                              <MousePointer2 size={15} />
                            ) : key === "light" ? (
                              <Lightbulb size={15} />
                            ) : (
                              <Zap size={14} />
                            )}
                          </span>
                          {key}
                        </button>
                      ),
                    )}
                  </div>
                  {view === "2d" ? (
                    <FloorPlan
                      room={room}
                      tool={tool}
                      onAdd={addPoint}
                      onMove={(id, x, y) =>
                        mutate((r) => ({
                          ...r,
                          points: r.points.map((p) => (p.id === id ? { ...p, x, y } : p)),
                        }))
                      }
                      onSelect={(id) => {
                        setSelectedPoint(id);
                        setTool("select");
                      }}
                      selected={selectedPoint}
                    />
                  ) : (
                    <>
                      <div className="viewport-toolbar">
                        <span>KAMERA</span>
                        {(["iso", "top", "front", "side", "inside"] as CameraView[]).map((preset) => (
                          <button
                            className={`tool-pill ${cameraView === preset ? "active" : ""}`}
                            key={preset}
                            onClick={() => setCameraView(preset)}
                          >
                            {preset}
                          </button>
                        ))}
                        <button
                          className={`tool-pill ${transparentWalls ? "active" : ""}`}
                          onClick={() => setTransparentWalls(!transparentWalls)}
                        >
                          <Eye size={14} /> Devor kesimi
                        </button>
                        <button
                          className={`tool-pill ${showCeiling ? "active" : ""}`}
                          onClick={() => setShowCeiling(!showCeiling)}
                        >
                          Shift
                        </button>
                        <button
                          className={`tool-pill ${nightMode ? "active" : ""}`}
                          onClick={() => setNightMode(!nightMode)}
                        >
                          <Sparkles size={14} /> {nightMode ? "🌙 Tun" : "💡 Yoritish sinovi"}
                        </button>
                        <button
                          className={`tool-pill ${showLoadIndicator ? "active" : ""}`}
                          onClick={() => setShowLoadIndicator(!showLoadIndicator)}
                          title="3D elektr yuklama indikatori va chegaralarini ko'rsatish"
                        >
                          <Zap size={14} /> ⚡ 3D Yuklama {roomLoad ? `(${roomLoad.ratioPercent.toFixed(0)}%)` : ""}
                        </button>
                      </div>

                      {roomLoad && (
                        <div className={`viewport-load-hud ${roomLoad.status}`}>
                          <div className="load-hud-header">
                            <div className="load-hud-title">
                              <Gauge size={16} />
                              <span>ELEKTR YUKLAMA HOLATI (LOAD CAPACITY MONITOR)</span>
                            </div>
                            <div className={`load-status-badge ${roomLoad.status}`}>
                              {roomLoad.isOver100 ? (
                                <>
                                  <ShieldAlert size={14} /> 🚨 {roomLoad.ratioPercent.toFixed(1)}% XAVFLI O'TA YUKLAMA
                                </>
                              ) : roomLoad.isOver80 ? (
                                <>
                                  <AlertTriangle size={14} /> ⚠️ {roomLoad.ratioPercent.toFixed(1)}% CHEGARA OSHGAN (&gt;80%)
                                </>
                              ) : (
                                <>
                                  <Zap size={14} /> ✓ {roomLoad.ratioPercent.toFixed(1)}% {roomLoad.status.toUpperCase()}
                                </>
                              )}
                            </div>
                          </div>

                          {/* Continuous load progress meter with 80% mark */}
                          <div
                            className="load-meter-track"
                            title={`Joriy yuklama: ${roomLoad.ratioPercent.toFixed(1)}% (${roomLoad.totalLoadKw} kW / ${roomLoad.capacityKw} kW)`}
                          >
                            <div
                              className={`load-meter-fill ${roomLoad.status}`}
                              style={{
                                width: `${Math.min(100, (roomLoad.ratioPercent / 120) * 100)}%`,
                                backgroundColor: roomLoad.colorHex,
                              }}
                            />
                            <div
                              className="load-threshold-line"
                              style={{ left: `${(80 / 120) * 100}%` }}
                              title="PUE 7.1 / NEC 80% uzluksiz yuklama ruxsat etilgan chegarasi"
                            >
                              <span className="threshold-tag">80% CHEGARA</span>
                            </div>
                          </div>

                          <div className="load-hud-stats">
                            <div className="load-stat-item">
                              <small>Hisoblangan yuklama</small>
                              <strong style={{ color: roomLoad.colorHex }}>
                                {roomLoad.totalLoadKw.toFixed(2)} kW
                              </strong>
                            </div>
                            <div className="load-stat-item">
                              <small>Avtomat quvvati</small>
                              <strong>{roomLoad.capacityKw.toFixed(2)} kW</strong>
                            </div>
                            <div className="load-stat-item">
                              <small>80% ruxsat me'yori</small>
                              <strong>{(roomLoad.capacityKw * 0.8).toFixed(2)} kW</strong>
                            </div>
                            <div className="load-stat-item">
                              <small>Nuqtalar (Rozetka / Chiroq)</small>
                              <strong>
                                {roomLoad.breakdown.outletsKw.toFixed(1)} kW /{" "}
                                {roomLoad.breakdown.lightsKw.toFixed(1)} kW
                              </strong>
                            </div>
                          </div>

                          {roomLoad.isOver80 && (
                            <div className={`load-warning-callout ${roomLoad.status}`}>
                              <AlertTriangle size={16} />
                              <div>
                                <strong>
                                  {roomLoad.isOver100
                                    ? "O'ta yuqori elektr yuklama (100% dan ortiq)!"
                                    : "Diqqat: Xona elektr yuklamasi 80% ruxsat chegarasidan oshdi!"}
                                </strong>
                                <p>
                                  PUE 7.1 va NEC qoidasiga ko'ra, avtomat o'chirgichning doimiy yuklamasi nominal quvvatining 80% idan (bu xona uchun {(roomLoad.capacityKw * 0.8).toFixed(2)} kW) oshmasligi shart. 3D xonada rangli perimetr nuri, miltillovchi burchak mayoqlari va tepada 3D status paneli faollashtirildi.
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      <Room3D
                        room={room}
                        view={cameraView}
                        transparentWalls={transparentWalls}
                        ceiling={showCeiling}
                        nightMode={nightMode}
                        showLoadIndicator={showLoadIndicator}
                      />
                      <p className="help-text">
                        Drag to orbit · scroll to zoom · right-drag to pan. 3D visual indicators highlight rooms exceeding 80% electrical load capacity.
                      </p>
                    </>
                  )}
                  <div className="plan-footer">
                    <span>{room.points.length} installation points</span>
                    <span>{(room.openings ?? []).length} openings · manual measurements</span>
                  </div>
                </Panel>
                <Panel label="ARCHITECTURAL ELEMENTS" title="Doors & windows">
                  <OpeningsEditor
                    room={room}
                    onChange={(openings) => mutate((r) => ({ ...r, openings }))}
                  />
                </Panel>
                <Panel label="INSTALLATION / PLAN TAKEOFF" title="Cable routes">
                  <RoutesEditor
                    room={room}
                    onChange={(routes) => mutate((r) => ({ ...r, routes }))}
                  />
                </Panel>
                {mode === "room" && (
                  <Panel
                    label="CAMERA / DEVICE-LOCAL"
                    title="Survey photographs"
                    action={<span className="status-chip">{(room.photos ?? []).length} / 8</span>}
                  >
                    <CameraRoom
                      key={room.id}
                      photos={room.photos ?? []}
                      capacity={8}
                      onSave={(photos) =>
                        mutate((r) => ({ ...r, photos: [...(r.photos ?? []), ...photos] }))
                      }
                      onDelete={(id) =>
                        mutate((r) => ({
                          ...r,
                          photos: (r.photos ?? []).filter((photo) => photo.id !== id),
                        }))
                      }
                    />
                  </Panel>
                )}
                <Panel label="POINT INSPECTOR" title={point ? point.label : "Select a symbol"}>
                  {point ? (
                    <div className="point-inspector-form">
                      <div className="form-row">
                        <label>
                          Label
                          <input
                            aria-label="Point label"
                            value={point.label}
                            onChange={(e) =>
                              mutate((r) => ({
                                ...r,
                                points: r.points.map((p) =>
                                  p.id === point.id ? { ...p, label: e.target.value } : p,
                                ),
                              }))
                            }
                          />
                        </label>
                        <label>
                          Type
                          <select
                            value={point.kind}
                            onChange={(e) =>
                              mutate((r) => ({
                                ...r,
                                points: r.points.map((p) =>
                                  p.id === point.id ? { ...p, kind: e.target.value as PointKind } : p,
                                ),
                              }))
                            }
                          >
                            <option value="outlet">Outlet (Rozetka)</option>
                            <option value="switch">Switch (Kalit)</option>
                            <option value="light">Light (Yoritgich)</option>
                            <option value="junction">Junction box (Taqsimlash qutisi)</option>
                            <option value="panel">Panel (Qalqon)</option>
                          </select>
                        </label>
                        <label>
                          Quvvat (kW)
                          <NumberField
                            label="Elektr quvvati (kW)"
                            min={0}
                            max={50}
                            step={0.1}
                            decimals={2}
                            value={point.powerKw ?? getPointPowerKw(point)}
                            commit={(val) =>
                              mutate((r) => ({
                                ...r,
                                points: r.points.map((p) =>
                                  p.id === point.id ? { ...p, powerKw: val } : p,
                                ),
                              }))
                            }
                          />
                        </label>
                        <button
                          className="btn danger-button"
                          onClick={() => {
                            mutate((r) => ({
                              ...r,
                              points: r.points.filter((p) => p.id !== point.id),
                            }));
                            setSelectedPoint("");
                          }}
                        >
                          <Trash2 size={15} /> Remove
                        </button>
                      </div>
                      <div className="point-power-presets">
                        <span className="preset-label">Tezkor quvvat shablonlari:</span>
                        {[
                          { label: "Rozetka 0.6 kW", kw: 0.6 },
                          { label: "Konditsioner 1.8 kW", kw: 1.8 },
                          { label: "Boyler 2.0 kW", kw: 2.0 },
                          { label: "Plita/Pech 2.5 kW", kw: 2.5 },
                          { label: "LED 0.12 kW", kw: 0.12 },
                          { label: "Lyustra 0.25 kW", kw: 0.25 },
                        ].map((preset) => (
                          <button
                            key={preset.label}
                            type="button"
                            className="preset-btn"
                            onClick={() =>
                              mutate((r) => ({
                                ...r,
                                points: r.points.map((p) =>
                                  p.id === point.id ? { ...p, powerKw: preset.kw } : p,
                                ),
                              }))
                            }
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="muted">
                      Select a point to edit it, or pick a tool and click inside the floor plan to
                      place one.
                    </p>
                  )}
                </Panel>
              </>
            ) : (
              <div className="empty-state tall">
                <ScanLine size={36} />
                <h2>Add your first room</h2>
                <p>
                  Enter a room name on the left, then edit its dimensions and place electrical
                  points.
                </p>
              </div>
            )}
          </div>
        </div>
      </ProjectGate>
    </>
  );
}
