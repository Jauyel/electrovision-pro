import React from 'react';
import { 
  Cpu, 
  DollarSign, 
  ShieldCheck, 
  Activity, 
  ArrowUpRight, 
  CheckCircle2, 
  AlertTriangle, 
  Zap, 
  Server, 
  Layers,
  Sparkles,
  TrendingUp,
  FileCheck
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

interface ProjectStatisticsProps {
  className?: string;
}

export const ProjectStatistics: React.FC<ProjectStatisticsProps> = ({ className = '' }) => {
  const { 
    activeProject, 
    powerCalculations, 
    formatCurrency, 
    currency, 
    setActiveModule 
  } = useProject();

  // 1. Cost Calculations
  const materialsSubtotalUzs = activeProject.materials.reduce((acc, item) => {
    return acc + (item.quantity * item.unitPriceUzS * (1 + item.wastePercent / 100));
  }, 0);
  const laborTotalUzs = activeProject.laborRatePerDayUzs * 5;
  const contingencyUzs = (materialsSubtotalUzs + laborTotalUzs) * (activeProject.contingencyPercent / 100);
  const grandTotalUzs = materialsSubtotalUzs + laborTotalUzs + contingencyUzs;

  // 2. Active Circuits Metrics
  const circuits = activeProject.cadCircuits;
  const totalCircuitsCount = circuits.length;
  const singlePhaseCount = circuits.filter(c => c.phase !== '3P').length;
  const threePhaseCount = circuits.filter(c => c.phase === '3P').length;

  // 3. Safety Compliance Metrics
  const maxVoltageDropPercent = Math.max(
    ...powerCalculations.circuitCalculations.map(c => c.voltageDropPercent), 
    0
  );
  const nonCompliantCircuits = powerCalculations.circuitCalculations.filter(c => !c.isCompliant);
  const isFullyCompliant = nonCompliantCircuits.length === 0 && powerCalculations.phaseBalanceUnbalancePercent <= 15;

  // 4. Panel Enclosure Utilization
  const totalOccupiedModules = activeProject.panelComponents.reduce((acc, c) => acc + c.moduleWidth, 0);
  const enclosureOccupancyPercent = Math.min(
    100, 
    Math.round((totalOccupiedModules / (activeProject.panelEnclosure.totalModules || 1)) * 100)
  );

  return (
    <section aria-label="Project Statistics" className={`space-y-4 ${className}`}>
      {/* Section Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-[#18D8F2] shadow-[0_0_8px_#18D8F2] animate-pulse" />
          <h2 className="text-sm font-bold text-[#F4F8FF] uppercase tracking-wider font-mono">
            Key Engineering Performance Indicators
          </h2>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-[#10243D]/90 text-[#9EB2CC] border border-[#1B3A5C]">
            Live CAD & BOM Telemetry
          </span>
        </div>

        <div className="text-[11px] font-mono text-[#9EB2CC] flex items-center gap-2">
          <span>Standard: <strong className="text-[#00D6A0]">{activeProject.standard}</strong></span>
          <span className="text-[#1B3A5C]">·</span>
          <span>Base Grid: <strong className="text-[#F4F8FF]">400V / 230V 50Hz</strong></span>
        </div>
      </div>

      {/* Primary 3-Metric Glassmorphism Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Metric 1: Active Circuits & Electrical Load */}
        <div 
          role="button"
          tabIndex={0}
          onClick={() => setActiveModule('cad')}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setActiveModule('cad');
            }
          }}
          className="group relative rounded-2xl bg-gradient-to-b from-[#0B1C32]/80 via-[#07172C]/75 to-[#040E1B]/90 backdrop-blur-2xl border border-white/10 hover:border-[#8B5CFF]/70 p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] transition-all duration-300 hover:-translate-y-1 cursor-pointer overflow-hidden focus:outline-none focus:ring-2 focus:ring-[#8B5CFF]/50 before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-[#8B5CFF]/40 before:to-transparent"
        >
          {/* Subtle Accent Glow Flare */}
          <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-[#8B5CFF]/15 blur-2xl pointer-events-none group-hover:bg-[#8B5CFF]/30 transition-all duration-500" />

          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#8B5CFF]/15 border border-[#8B5CFF]/30 flex items-center justify-center text-[#8B5CFF] group-hover:scale-105 group-hover:shadow-[0_0_15px_rgba(139,92,255,0.3)] transition-all">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9EB2CC] block">
                  Distribution Network
                </span>
                <h3 className="text-sm font-bold text-[#F4F8FF] group-hover:text-white transition-colors">
                  Active Circuits
                </h3>
              </div>
            </div>

            <div className="p-1.5 rounded-lg bg-[#061426]/60 border border-white/5 text-[#9EB2CC] group-hover:text-[#8B5CFF] group-hover:border-[#8B5CFF]/30 transition-all">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-[#F4F8FF] font-mono tabular-nums tracking-tight group-hover:text-white">
                {totalCircuitsCount}
              </span>
              <span className="text-xs text-[#9EB2CC] font-mono">
                Branches ({singlePhaseCount} 1P / {threePhaseCount} 3P)
              </span>
            </div>

            {/* Load Flow Sub-bar */}
            <div className="p-3 bg-[#040E1B]/80 rounded-xl border border-white/5 space-y-1.5 font-mono text-xs">
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>Connected Power:</span>
                <span className="text-[#F4F8FF] font-bold">
                  {powerCalculations.totalActivePowerKw} kW <span className="text-[#9EB2CC] font-normal">({powerCalculations.totalApparentPowerKva} kVA)</span>
                </span>
              </div>
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>Design Current (Ib):</span>
                <span className="text-[#18D8F2] font-semibold">{powerCalculations.designCurrentA} A</span>
              </div>
              <div className="w-full h-1.5 bg-[#0B1C32] rounded-full overflow-hidden mt-1.5">
                <div 
                  className="h-full bg-gradient-to-r from-[#8B5CFF] to-[#18D8F2] rounded-full transition-all duration-500" 
                  style={{ width: `${Math.min(100, (powerCalculations.totalActivePowerKw / 25) * 100)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#9EB2CC]">
            <span>Phase Balance: <strong className="text-[#F4F8FF]">{powerCalculations.phaseBalanceUnbalancePercent}%</strong></span>
            <span className="text-[#8B5CFF] group-hover:underline flex items-center gap-1 font-semibold">
              Inspect SLD &rarr;
            </span>
          </div>
        </div>

        {/* Metric 2: Estimated Cost & Procurement Take-Off */}
        <div 
          role="button"
          tabIndex={0}
          onClick={() => setActiveModule('estimator')}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setActiveModule('estimator');
            }
          }}
          className="group relative rounded-2xl bg-gradient-to-b from-[#0B1C32]/80 via-[#07172C]/75 to-[#040E1B]/90 backdrop-blur-2xl border border-white/10 hover:border-[#00D6A0]/70 p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] transition-all duration-300 hover:-translate-y-1 cursor-pointer overflow-hidden focus:outline-none focus:ring-2 focus:ring-[#00D6A0]/50 before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-[#00D6A0]/40 before:to-transparent"
        >
          {/* Subtle Accent Glow Flare */}
          <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-[#00D6A0]/15 blur-2xl pointer-events-none group-hover:bg-[#00D6A0]/30 transition-all duration-500" />

          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#00D6A0]/15 border border-[#00D6A0]/30 flex items-center justify-center text-[#00D6A0] group-hover:scale-105 group-hover:shadow-[0_0_15px_rgba(0,214,160,0.3)] transition-all">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9EB2CC] block">
                  Procurement & Labor
                </span>
                <h3 className="text-sm font-bold text-[#F4F8FF] group-hover:text-white transition-colors">
                  Estimated Cost
                </h3>
              </div>
            </div>

            <div className="p-1.5 rounded-lg bg-[#061426]/60 border border-white/5 text-[#9EB2CC] group-hover:text-[#00D6A0] group-hover:border-[#00D6A0]/30 transition-all">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-[#00D6A0] font-mono tabular-nums tracking-tight group-hover:brightness-110">
                {formatCurrency(grandTotalUzs)}
              </span>
            </div>

            {/* Cost Breakdown Sub-bar */}
            <div className="p-3 bg-[#040E1B]/80 rounded-xl border border-white/5 space-y-1.5 font-mono text-xs">
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>Materials Subtotal:</span>
                <span className="text-[#F4F8FF] font-medium">{formatCurrency(materialsSubtotalUzs)}</span>
              </div>
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>Labor Rate:</span>
                <span className="text-[#18D8F2] font-medium">{formatCurrency(laborTotalUzs)}</span>
              </div>
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>Contingency ({activeProject.contingencyPercent}%):</span>
                <span className="text-[#FF9A24] font-medium">{formatCurrency(contingencyUzs)}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#9EB2CC]">
            <span>{activeProject.materials.length} Synchronized items</span>
            <span className="text-[#00D6A0] group-hover:underline flex items-center gap-1 font-semibold">
              Open Full BOM &rarr;
            </span>
          </div>
        </div>

        {/* Metric 3: Safety Compliance & Standards Verification */}
        <div 
          role="button"
          tabIndex={0}
          onClick={() => setActiveModule('cad')}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              setActiveModule('cad');
            }
          }}
          className="group relative rounded-2xl bg-gradient-to-b from-[#0B1C32]/80 via-[#07172C]/75 to-[#040E1B]/90 backdrop-blur-2xl border border-white/10 hover:border-[#18D8F2]/70 p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] transition-all duration-300 hover:-translate-y-1 cursor-pointer overflow-hidden focus:outline-none focus:ring-2 focus:ring-[#18D8F2]/50 before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-gradient-to-r before:from-transparent before:via-[#18D8F2]/40 before:to-transparent"
        >
          {/* Subtle Accent Glow Flare */}
          <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-[#18D8F2]/15 blur-2xl pointer-events-none group-hover:bg-[#18D8F2]/30 transition-all duration-500" />

          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className={`w-10 h-10 rounded-xl border flex items-center justify-center group-hover:scale-105 transition-all shadow-sm ${
                isFullyCompliant 
                  ? 'bg-[#00D6A0]/15 border-[#00D6A0]/30 text-[#00D6A0] group-hover:shadow-[0_0_15px_rgba(0,214,160,0.3)]' 
                  : 'bg-[#FF9A24]/15 border-[#FF9A24]/30 text-[#FF9A24] group-hover:shadow-[0_0_15px_rgba(255,154,36,0.3)]'
              }`}>
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#9EB2CC] block">
                  Regulatory Compliance
                </span>
                <h3 className="text-sm font-bold text-[#F4F8FF] group-hover:text-white transition-colors">
                  Safety Compliance
                </h3>
              </div>
            </div>

            <div className="p-1.5 rounded-lg bg-[#061426]/60 border border-white/5 text-[#9EB2CC] group-hover:text-[#18D8F2] group-hover:border-[#18D8F2]/30 transition-all">
              <ArrowUpRight className="w-4 h-4" />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className={`text-2xl font-black font-mono tracking-tight flex items-center gap-1.5 ${
                isFullyCompliant ? 'text-[#00D6A0]' : 'text-[#FF9A24]'
              }`}>
                {isFullyCompliant ? (
                  <>
                    <CheckCircle2 className="w-6 h-6" />
                    <span>100% COMPLIANT</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-6 h-6" />
                    <span>REVIEW REQUIRED</span>
                  </>
                )}
              </span>
            </div>

            {/* Safety Parameters Sub-bar */}
            <div className="p-3 bg-[#040E1B]/80 rounded-xl border border-white/5 space-y-1.5 font-mono text-xs">
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>Peak Voltage Drop (ΔU):</span>
                <span className={`font-bold ${maxVoltageDropPercent > 3.0 ? 'text-[#FF9A24]' : 'text-[#00D6A0]'}`}>
                  {maxVoltageDropPercent.toFixed(2)}% <span className="text-[#9EB2CC] font-normal">(Limit: &le; 3.0%)</span>
                </span>
              </div>
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>Thermal Overload Flags:</span>
                <span className="text-[#00D6A0] font-semibold">0 Violations</span>
              </div>
              <div className="flex justify-between items-center text-[#9EB2CC] text-[11px]">
                <span>RCD Earth Protection:</span>
                <span className="text-[#18D8F2] font-semibold">30mA Type A Active</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-[#9EB2CC]">
            <span>Code: <strong className="text-[#F4F8FF]">{activeProject.standard}</strong></span>
            <span className="text-[#18D8F2] group-hover:underline flex items-center gap-1 font-semibold">
              View Audit &rarr;
            </span>
          </div>
        </div>
      </div>

      {/* Secondary Quick Telemetry Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-xl bg-[#0B1C32]/60 backdrop-blur-md border border-white/5 hover:border-white/10 transition-colors flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#FF9A24]/15 border border-[#FF9A24]/30 flex items-center justify-center shrink-0">
            <Server className="w-4 h-4 text-[#FF9A24]" />
          </div>
          <div className="truncate">
            <div className="text-[10px] text-[#9EB2CC] uppercase font-mono">DIN Enclosure</div>
            <div className="text-xs font-bold text-[#F4F8FF] font-mono tabular-nums">
              {enclosureOccupancyPercent}% Occupied
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-[#0B1C32]/60 backdrop-blur-md border border-white/5 hover:border-white/10 transition-colors flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#18D8F2]/15 border border-[#18D8F2]/30 flex items-center justify-center shrink-0">
            <Layers className="w-4 h-4 text-[#18D8F2]" />
          </div>
          <div className="truncate">
            <div className="text-[10px] text-[#9EB2CC] uppercase font-mono">Cable Routing</div>
            <div className="text-xs font-bold text-[#F4F8FF] font-mono tabular-nums">
              {activeProject.cableRoutes.reduce((a, b) => a + b.lengthMeters, 0).toFixed(1)} m Total
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-[#0B1C32]/60 backdrop-blur-md border border-white/5 hover:border-white/10 transition-colors flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#00D6A0]/15 border border-[#00D6A0]/30 flex items-center justify-center shrink-0">
            <Zap className="w-4 h-4 text-[#00D6A0]" />
          </div>
          <div className="truncate">
            <div className="text-[10px] text-[#9EB2CC] uppercase font-mono">Phase Asymmetry</div>
            <div className="text-xs font-bold text-[#F4F8FF] font-mono tabular-nums">
              {powerCalculations.phaseBalanceUnbalancePercent}% (Target &lt; 15%)
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl bg-[#0B1C32]/60 backdrop-blur-md border border-white/5 hover:border-white/10 transition-colors flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-[#8B5CFF]/15 border border-[#8B5CFF]/30 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-[#8B5CFF]" />
          </div>
          <div className="truncate">
            <div className="text-[10px] text-[#9EB2CC] uppercase font-mono">Electrical Nodes</div>
            <div className="text-xs font-bold text-[#F4F8FF] font-mono tabular-nums">
              {activeProject.roomData.points.length} Terminals
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
