import React, { useState } from 'react';
import { 
  Calculator, 
  Download, 
  FileText, 
  Plus, 
  RotateCcw, 
  Trash2, 
  Save, 
  Search, 
  DollarSign, 
  ShieldCheck, 
  Sparkles,
  FileSpreadsheet,
  CheckCircle2,
  Printer
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { MaterialItem } from '../../types';
import { Modal } from '../common/Modal';

export const MaterialEstimator: React.FC = () => {
  const { 
    activeProject, 
    updateActiveProject, 
    recalculateMaterialsFromProject, 
    removeMaterial, 
    addCustomMaterial, 
    formatCurrency, 
    currency, 
    t, 
    triggerSave, 
    saveStatus 
  } = useProject();

  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);

  // New material form state
  const [newName, setNewName] = useState('');
  const [newModel, setNewModel] = useState('');
  const [newCat, setNewCat] = useState<MaterialItem['category']>('cables');
  const [newUnit, setNewUnit] = useState<MaterialItem['unit']>('m');
  const [newQty, setNewQty] = useState(10);
  const [newPrice, setNewPrice] = useState(15000);
  const [newWaste, setNewWaste] = useState(5);

  const materials = activeProject.materials;

  const handleUpdateMaterial = (id: string, field: keyof MaterialItem, val: any) => {
    updateActiveProject(prev => ({
      ...prev,
      materials: prev.materials.map(m => m.id === id ? { ...m, [field]: val } : m)
    }));
  };

  const handleCreateMaterial = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName) return;
    addCustomMaterial({
      category: newCat,
      name: newName,
      model: newModel || "Custom",
      specification: "Field engineer custom specification",
      unit: newUnit,
      quantity: Number(newQty),
      unitPriceUzS: Number(newPrice),
      wastePercent: Number(newWaste),
      sourceModule: 'Manual',
      notes: "Direct manual entry"
    });
    setNewName('');
    setNewModel('');
    setIsAddModalOpen(false);
  };

  // Deterministic calculations
  const filteredMaterials = materials.filter(m => {
    const matchesCat = categoryFilter === 'all' || m.category === categoryFilter;
    const matchesSearch = m.name.toLowerCase().includes(searchFilter.toLowerCase()) || 
                          m.model.toLowerCase().includes(searchFilter.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const materialsSubtotalUzs = materials.reduce((acc, m) => {
    return acc + (m.quantity * m.unitPriceUzS * (1 + m.wastePercent / 100));
  }, 0);

  const laborCostUzs = activeProject.laborRatePerDayUzs * 5;
  const contingencyCostUzs = (materialsSubtotalUzs + laborCostUzs) * (activeProject.contingencyPercent / 100);
  const grandTotalUzs = materialsSubtotalUzs + laborCostUzs + contingencyCostUzs;

  // Real CSV Download
  const handleExportCsv = () => {
    const headers = ["Item #", "Category", "Description", "Model", "Unit", "Qty", "Unit Price (UZS)", "Waste %", "Line Total (UZS)", "Source Module"];
    const rows = materials.map((m, idx) => [
      idx + 1,
      `"${m.category}"`,
      `"${m.name}"`,
      `"${m.model}"`,
      m.unit,
      m.quantity,
      m.unitPriceUzS,
      `${m.wastePercent}%`,
      Math.round(m.quantity * m.unitPriceUzS * (1 + m.wastePercent / 100)),
      `"${m.sourceModule}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," + 
      [headers.join(","), ...rows.map(e => e.join(","))].join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `ElectroVision_BOM_${activeProject.code}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4 pb-12 animate-fade-in">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-[#061426] border border-[#1B3A5C] rounded-xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#147DFF]" />
            <h1 className="text-xl font-extrabold text-[#F4F8FF] tracking-tight">{t.estimator.title}</h1>
            <span className="text-[10px] font-mono uppercase bg-[#147DFF]/15 text-[#18D8F2] px-2 py-0.5 rounded border border-[#147DFF]/30">
              Module 05
            </span>
          </div>
          <p className="text-xs text-[#9EB2CC] mt-1">{t.estimator.subtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={recalculateMaterialsFromProject}
            className="px-3.5 py-1.5 bg-[#00D6A0]/20 hover:bg-[#00D6A0]/30 border border-[#00D6A0]/40 text-[#00D6A0] rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors"
            title="Pull latest counts from Room Scanner, 3D Panel, and Cable Routes"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Sync from 3D Model</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-3 py-1.5 bg-[#0B1C32] hover:bg-[#10243D] border border-[#1B3A5C] text-[#F4F8FF] rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-[#18D8F2]" />
            <span>{t.estimator.addMaterial}</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="px-3 py-1.5 bg-[#0B1C32] hover:bg-[#10243D] border border-[#1B3A5C] text-[#F4F8FF] rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#00D6A0]" />
            <span>{t.estimator.exportCsv}</span>
          </button>

          <button
            onClick={() => setIsPdfModalOpen(true)}
            className="px-3 py-1.5 bg-[#0B1C32] hover:bg-[#10243D] border border-[#1B3A5C] text-[#F4F8FF] rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <FileText className="w-3.5 h-3.5 text-[#8B5CFF]" />
            <span>{t.estimator.exportPdf}</span>
          </button>

          <button
            onClick={triggerSave}
            className="px-3.5 py-1.5 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#147DFF]/25 transition-all"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saveStatus === 'saved' ? t.saved : t.save}</span>
          </button>
        </div>
      </div>

      {/* Synchronized Notice Banner */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#061426] border border-[#1B3A5C] rounded-xl text-xs text-[#9EB2CC]">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-[#00D6A0]" />
          <span>{t.estimator.syncNotice}</span>
        </div>
        <div className="font-mono text-[11px] text-[#18D8F2]">
          Currency: <strong className="text-[#F4F8FF]">{currency}</strong>
        </div>
      </div>

      {/* Cost Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl p-4">
          <div className="text-[10px] uppercase font-mono text-[#9EB2CC] mb-1">
            {t.estimator.materialsSubtotal}
          </div>
          <div className="text-xl font-extrabold text-[#F4F8FF] font-mono tabular-nums">
            {formatCurrency(materialsSubtotalUzs)}
          </div>
          <div className="text-[10px] text-[#9EB2CC] font-mono mt-1">
            {materials.length} verified item rows
          </div>
        </div>

        <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl p-4">
          <div className="text-[10px] uppercase font-mono text-[#9EB2CC] mb-1">
            {t.estimator.laborCost}
          </div>
          <div className="text-xl font-extrabold text-[#18D8F2] font-mono tabular-nums">
            {formatCurrency(laborCostUzs)}
          </div>
          <div className="text-[10px] text-[#9EB2CC] font-mono mt-1">
            5 Days @ {formatCurrency(activeProject.laborRatePerDayUzs)}/day
          </div>
        </div>

        <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl p-4">
          <div className="text-[10px] uppercase font-mono text-[#9EB2CC] mb-1">
            {t.estimator.contingency}
          </div>
          <div className="text-xl font-extrabold text-[#FF9A24] font-mono tabular-nums">
            {formatCurrency(contingencyCostUzs)}
          </div>
          <div className="text-[10px] text-[#9EB2CC] font-mono mt-1">
            Reserve factor ({activeProject.contingencyPercent}%)
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#0B1C32] to-[#10243D] border-2 border-[#147DFF]/50 rounded-xl p-4 shadow-xl">
          <div className="text-[10px] uppercase font-mono text-[#18D8F2] mb-1 font-bold">
            {t.estimator.grandTotal}
          </div>
          <div className="text-2xl font-black text-[#00D6A0] font-mono tabular-nums">
            {formatCurrency(grandTotalUzs)}
          </div>
          <div className="text-[10px] text-[#9EB2CC] font-mono mt-1">
            All taxes & delivery included
          </div>
        </div>
      </div>

      {/* Material Filtering & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#061426] p-2.5 rounded-xl border border-[#1B3A5C]">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {['all', 'cables', 'conduits', 'panel_equipment', 'protection', 'sockets_switches', 'mounting'].map(cat => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors capitalize ${
                categoryFilter === cat 
                  ? 'bg-[#147DFF] text-white shadow' 
                  : 'text-[#9EB2CC] hover:text-[#F4F8FF] hover:bg-[#0B1C32]'
              }`}
            >
              {cat.replace('_', ' ')}
            </button>
          ))}
        </div>

        <div className="relative min-w-[220px]">
          <Search className="w-3.5 h-3.5 text-[#9EB2CC] absolute left-2.5 top-2.5" />
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Search material or model..."
            className="w-full pl-8 pr-2.5 py-1.5 bg-[#0B1C32] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
          />
        </div>
      </div>

      {/* Editable Material Data Table */}
      <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-[#061426] border-b border-[#1B3A5C] text-[#9EB2CC] uppercase font-mono text-[10px]">
              <tr>
                <th className="px-3 py-3">#</th>
                <th className="px-4 py-3">Material & Specification</th>
                <th className="px-3 py-3">Model</th>
                <th className="px-2 py-3">Unit</th>
                <th className="px-2 py-3">Qty</th>
                <th className="px-3 py-3">Unit Price ({currency})</th>
                <th className="px-2 py-3">Waste %</th>
                <th className="px-3 py-3 text-right">Line Total</th>
                <th className="px-3 py-3">Source</th>
                <th className="px-2 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1B3A5C]/40">
              {filteredMaterials.map((m, idx) => {
                const lineTotalUzs = m.quantity * m.unitPriceUzS * (1 + m.wastePercent / 100);
                return (
                  <tr key={m.id} className="hover:bg-[#10243D] transition-colors">
                    <td className="px-3 py-2 font-mono text-[#9EB2CC]">{idx + 1}</td>
                    <td className="px-4 py-2 font-semibold text-[#F4F8FF]">
                      <div>{m.name}</div>
                      <div className="text-[10px] text-[#9EB2CC] font-mono">{m.specification}</div>
                    </td>
                    <td className="px-3 py-2 font-mono text-[#9EB2CC]">{m.model}</td>
                    <td className="px-2 py-2 font-mono text-[#9EB2CC]">{m.unit}</td>
                    <td className="px-2 py-2">
                      <input
                        type="number"
                        min="1"
                        value={m.quantity}
                        onChange={(e) => handleUpdateMaterial(m.id, 'quantity', Math.max(1, parseInt(e.target.value) || 1))}
                        className="w-16 px-1.5 py-0.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono font-bold text-[#F4F8FF]"
                      />
                    </td>
                    <td className="px-3 py-2">
                      <input
                        type="number"
                        step="1000"
                        value={m.unitPriceUzS}
                        onChange={(e) => handleUpdateMaterial(m.id, 'unitPriceUzS', parseInt(e.target.value) || 0)}
                        className="w-24 px-1.5 py-0.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono text-[#18D8F2]"
                      />
                    </td>
                    <td className="px-2 py-2">
                      <input
                        type="number"
                        min="0"
                        max="30"
                        value={m.wastePercent}
                        onChange={(e) => handleUpdateMaterial(m.id, 'wastePercent', parseInt(e.target.value) || 0)}
                        className="w-12 px-1 py-0.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono text-[#9EB2CC]"
                      />
                    </td>
                    <td className="px-3 py-2 text-right font-mono font-bold text-[#00D6A0]">
                      {formatCurrency(lineTotalUzs)}
                    </td>
                    <td className="px-3 py-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-[#061426] text-[#9EB2CC] rounded border border-[#1B3A5C]">
                        {m.sourceModule}
                      </span>
                    </td>
                    <td className="px-2 py-2 text-center">
                      <button
                        onClick={() => removeMaterial(m.id)}
                        className="p-1 text-[#FF5263] hover:bg-[#FF5263]/20 rounded transition-colors"
                        title="Delete row"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Custom Material Row Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add Material Specification Row"
        subtitle="Insert custom cables, fixtures, switchgear, or mounting supplies into the BOM."
      >
        <form onSubmit={handleCreateMaterial} className="space-y-4 text-xs">
          <div>
            <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Material Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Copper Earth Grounding Rod 16mm x 2.5m"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Manufacturer / Model</label>
              <input
                type="text"
                placeholder="e.g. DKC Galvanized Steel"
                value={newModel}
                onChange={(e) => setNewModel(e.target.value)}
                className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Category</label>
              <select
                value={newCat}
                onChange={(e) => setNewCat(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
              >
                <option value="cables">Cables & Conductors</option>
                <option value="conduits">Conduits & Trays</option>
                <option value="panel_equipment">Panel Equipment</option>
                <option value="protection">Protection (MCB/RCD)</option>
                <option value="sockets_switches">Sockets & Switches</option>
                <option value="mounting">Mounting & Hardware</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Unit</label>
              <select
                value={newUnit}
                onChange={(e) => setNewUnit(e.target.value as any)}
                className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
              >
                <option value="m">Meters (m)</option>
                <option value="pcs">Pieces (pcs)</option>
                <option value="set">Set</option>
                <option value="roll">Roll</option>
                <option value="pack">Pack</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Quantity</label>
              <input
                type="number"
                value={newQty}
                onChange={(e) => setNewQty(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#9EB2CC] mb-1">Unit Price (UZS)</label>
              <input
                type="number"
                step="5000"
                value={newPrice}
                onChange={(e) => setNewPrice(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#061426] border border-[#1B3A5C] rounded-lg text-xs text-[#F4F8FF]"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-[#1B3A5C]">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-3 py-1.5 bg-[#061426] text-xs font-medium text-[#9EB2CC] rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-[#147DFF] text-white text-xs font-bold rounded-lg"
            >
              Add Material
            </button>
          </div>
        </form>
      </Modal>

      {/* PDF Export Preview Modal */}
      <Modal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        title="Engineering Bill of Materials & Cost Certificate"
        subtitle="Official project bill of quantities formatted for client sign-off."
        maxWidth="max-w-4xl"
      >
        <div className="space-y-4 text-xs font-sans">
          {/* Printable Document Box */}
          <div className="p-6 bg-white text-slate-900 rounded-xl border border-slate-300 space-y-6 shadow-inner print:p-0">
            {/* Document Header */}
            <div className="flex items-start justify-between border-b border-slate-300 pb-4">
              <div>
                <h2 className="text-xl font-black text-slate-900 tracking-tight">
                  ELECTROVISION ENGINEERING ESTIMATE
                </h2>
                <p className="text-xs text-slate-600 font-mono">
                  Document ID: EV-EST-{activeProject.code}-2026
                </p>
                <div className="text-xs text-slate-600 mt-1">
                  <strong>Project:</strong> {activeProject.name} ({activeProject.location})
                </div>
              </div>
              <div className="text-right text-xs text-slate-600">
                <div><strong>Standard:</strong> {activeProject.standard}</div>
                <div><strong>Date:</strong> {new Date().toLocaleDateString()}</div>
                <div><strong>Lead PE:</strong> {activeProject.leadEngineer}</div>
              </div>
            </div>

            {/* Compact Table */}
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="border-b-2 border-slate-900 text-slate-700 font-bold">
                  <th className="py-1">Item</th>
                  <th className="py-1">Specification</th>
                  <th className="py-1">Model</th>
                  <th className="py-1 text-center">Unit</th>
                  <th className="py-1 text-right">Qty</th>
                  <th className="py-1 text-right">Unit Price</th>
                  <th className="py-1 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {materials.map((m, idx) => (
                  <tr key={m.id}>
                    <td className="py-1.5 font-mono text-slate-500">{idx + 1}</td>
                    <td className="py-1.5 font-semibold text-slate-900">{m.name}</td>
                    <td className="py-1.5 text-slate-600 font-mono">{m.model}</td>
                    <td className="py-1.5 text-center text-slate-600">{m.unit}</td>
                    <td className="py-1.5 text-right font-mono font-bold text-slate-900">{m.quantity}</td>
                    <td className="py-1.5 text-right font-mono text-slate-600">{formatCurrency(m.unitPriceUzS)}</td>
                    <td className="py-1.5 text-right font-mono font-bold text-slate-900">
                      {formatCurrency(m.quantity * m.unitPriceUzS * (1 + m.wastePercent / 100))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Financial Totals Block */}
            <div className="flex justify-end pt-4 border-t-2 border-slate-900">
              <div className="w-64 space-y-1.5 text-xs font-mono">
                <div className="flex justify-between text-slate-600">
                  <span>Materials Subtotal:</span>
                  <span className="font-bold text-slate-900">{formatCurrency(materialsSubtotalUzs)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Labor & Installation:</span>
                  <span className="font-bold text-slate-900">{formatCurrency(laborCostUzs)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Contingency ({activeProject.contingencyPercent}%):</span>
                  <span className="font-bold text-slate-900">{formatCurrency(contingencyCostUzs)}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-900 text-sm font-black text-blue-900">
                  <span>ESTIMATE TOTAL:</span>
                  <span>{formatCurrency(grandTotalUzs)}</span>
                </div>
              </div>
            </div>

            {/* Engineering Stamp Seal */}
            <div className="pt-6 border-t border-slate-300 flex items-center justify-between text-[11px] text-slate-500">
              <div>
                Verified for compliance with Republic of Uzbekistan ShNQ and GOST electrical safety codes.
              </div>
              <div className="border-2 border-blue-900 text-blue-900 px-3 py-1 font-mono font-black rounded uppercase text-center">
                ELECTROVISION PRO<br/>CERTIFIED PE STAMP
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setIsPdfModalOpen(false)}
              className="px-3 py-1.5 bg-[#061426] text-xs font-medium text-[#9EB2CC] rounded-lg"
            >
              Close
            </button>
            <button
              onClick={() => window.print()}
              className="px-4 py-1.5 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white text-xs font-bold rounded-lg flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save as PDF</span>
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
