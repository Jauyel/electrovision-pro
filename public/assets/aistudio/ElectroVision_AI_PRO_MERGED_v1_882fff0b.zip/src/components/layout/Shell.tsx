import React from 'react';
import { TopHeader } from './TopHeader';
import { Sidebar } from './Sidebar';
import { useProject } from '../../context/ProjectContext';
import { Dashboard } from '../dashboard/Dashboard';
import { AIObjectScanner } from '../scanner/AIObjectScanner';
import { InstallationMode } from '../installation/InstallationMode';
import { PanelBuilder } from '../panel/PanelBuilder';
import { ElectricalCAD } from '../cad/ElectricalCAD';
import { MaterialEstimator } from '../estimator/MaterialEstimator';
import { ProjectsView } from '../projects/ProjectsView';
import { ReportsView } from '../reports/ReportsView';
import { SettingsView } from '../settings/SettingsView';

export const Shell: React.FC = () => {
  const { activeModule } = useProject();

  const renderActiveModule = () => {
    switch (activeModule) {
      case 'dashboard':
        return <Dashboard />;
      case 'scanner':
        return <AIObjectScanner />;
      case 'installation':
        return <InstallationMode />;
      case 'panel':
        return <PanelBuilder />;
      case 'cad':
        return <ElectricalCAD />;
      case 'estimator':
        return <MaterialEstimator />;
      case 'projects':
      case 'saved':
        return <ProjectsView />;
      case 'reports':
        return <ReportsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#030B18] text-[#F4F8FF] flex flex-col">
      {/* Top Application Header */}
      <TopHeader />

      {/* Main Container with Sidebar + Content Canvas */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar />

        {/* Dynamic Content Canvas */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-[#030B18]">
          <div className="max-w-7xl mx-auto">
            {renderActiveModule()}
          </div>
        </main>
      </div>
    </div>
  );
};
