import React from 'react';
import { 
  FolderKanban, 
  Bookmark,
  FileText,
  Settings,
  ChevronRight,
  Zap,
  X,
  ShieldCheck,
  Activity
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { SidebarNav } from './SidebarNav';

export const Sidebar: React.FC = () => {
  const { 
    activeModule, 
    setActiveModule, 
    t, 
    activeProject, 
    isMobileMenuOpen, 
    setIsMobileMenuOpen 
  } = useProject();

  const secondaryNav = [
    { id: 'projects', label: t.nav.myProjects, icon: FolderKanban, badge: 'All' },
    { id: 'saved', label: t.nav.savedDesigns, icon: Bookmark, badge: 'CAD' },
    { id: 'reports', label: t.nav.reports, icon: FileText, badge: 'PDF' },
    { id: 'settings', label: t.nav.settings, icon: Settings, badge: 'Config' },
  ];

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/80 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Main Sidebar (Fixed on mobile, static on desktop) */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-[#061426] border-r border-[#1B3A5C] flex flex-col justify-between shrink-0 select-none transition-transform duration-300 ease-in-out
        lg:static lg:translate-x-0
        ${isMobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Top Section */}
        <div className="p-4 space-y-5 overflow-y-auto custom-scrollbar">
          {/* Mobile Close Bar */}
          <div className="flex items-center justify-between lg:hidden pb-1 border-b border-[#1B3A5C]">
            <span className="text-xs font-bold text-[#F4F8FF] font-mono flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-[#18D8F2]" /> ElectroVision PRO
            </span>
            <button 
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-1 text-[#9EB2CC] hover:text-[#F4F8FF] hover:bg-[#10243D] rounded transition-colors"
              aria-label="Close menu"
            >
              <X className="w-4 h-4 text-[#18D8F2]" />
            </button>
          </div>

          {/* Active Project Card */}
          <div className="p-3 bg-gradient-to-b from-[#0B1C32] to-[#081729] border border-[#1B3A5C] rounded-xl flex flex-col gap-1.5 shadow-sm">
            <div className="flex items-center justify-between text-[11px] text-[#9EB2CC]">
              <span className="uppercase font-mono tracking-wider font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00D6A0] animate-pulse" />
                Active Project
              </span>
              <span className="px-1.5 py-0.2 bg-[#00D6A0]/15 text-[#00D6A0] text-[9px] font-mono rounded border border-[#00D6A0]/30">
                Live State
              </span>
            </div>
            <div className="text-xs font-bold text-[#F4F8FF] truncate" title={activeProject.name}>
              {activeProject.name}
            </div>
            <div className="text-[10px] text-[#9EB2CC] flex items-center justify-between font-mono pt-0.5">
              <span className="text-[#00D6A0]">{activeProject.standard}</span>
              <span>{activeProject.cadCircuits.length} Circuits</span>
            </div>
          </div>

          {/* Primary 5 Modules Navigation Component */}
          <SidebarNav onItemClick={() => setIsMobileMenuOpen(false)} />

          {/* Secondary Management Nav */}
          <div className="pt-2 border-t border-[#1B3A5C]/60 space-y-1.5">
            <div className="text-[10px] font-bold text-[#9EB2CC] uppercase tracking-wider font-mono px-3 mb-1">
              Workspace & Reports
            </div>
            <nav className="space-y-1">
              {secondaryNav.map((item) => {
                const Icon = item.icon;
                const isActive = activeModule === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveModule(item.id as any);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full group flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all duration-200 border ${
                      isActive 
                        ? 'bg-[#10243D] border-[#147DFF]/50 text-[#F4F8FF] font-bold shadow-sm' 
                        : 'border-transparent text-[#9EB2CC] hover:text-[#F4F8FF] hover:bg-[#0B1C32] hover:border-[#1B3A5C]/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border transition-colors ${
                        isActive
                          ? 'bg-[#147DFF]/20 border-[#147DFF]/40 text-[#18D8F2]'
                          : 'bg-[#061426] border-[#1B3A5C] text-[#9EB2CC] group-hover:text-[#F4F8FF] group-hover:border-[#1B3A5C]'
                      }`}>
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <span className="truncate">{item.label}</span>
                    </div>

                    <span className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                      isActive 
                        ? 'bg-[#061426] border-white/20 text-[#18D8F2]' 
                        : 'bg-[#061426] border-[#1B3A5C] text-[#9EB2CC]'
                    }`}>
                      {item.badge}
                    </span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Bottom Engineering Cert Badge */}
        <div className="p-4 border-t border-[#1B3A5C] bg-[#030B18]/70">
          <div className="p-2.5 bg-[#0B1C32] border border-[#1B3A5C] rounded-xl flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#00D6A0]/15 border border-[#00D6A0]/30 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4 text-[#00D6A0]" />
            </div>
            <div className="flex flex-col truncate">
              <span className="text-[11px] font-bold text-[#F4F8FF] truncate">Deterministic Engine</span>
              <span className="text-[9px] text-[#9EB2CC] font-mono">GOST 30331 & IEC 60364</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
