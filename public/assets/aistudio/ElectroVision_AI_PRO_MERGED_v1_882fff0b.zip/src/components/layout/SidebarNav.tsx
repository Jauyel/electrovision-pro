import React from 'react';
import { 
  Box, 
  Wrench, 
  Server, 
  Cpu, 
  Calculator, 
  LayoutDashboard,
  ChevronRight,
  Zap,
  Sparkles
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

interface SidebarNavProps {
  onItemClick?: () => void;
  className?: string;
}

export interface NavModuleItem {
  id: 'scanner' | 'installation' | 'panel' | 'cad' | 'estimator';
  modNumber: string;
  labelKey: string;
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  accentColor: string;
  glowColor: string;
  badge: string;
  techTag: string;
}

export const MAIN_MODULES: NavModuleItem[] = [
  {
    id: 'scanner',
    modNumber: '01',
    labelKey: 'roomScanner',
    icon: Box,
    accentColor: '#18D8F2',
    glowColor: 'rgba(24, 216, 242, 0.4)',
    badge: '3D Room',
    techTag: 'BIM Scan'
  },
  {
    id: 'installation',
    modNumber: '02',
    labelKey: 'installation',
    icon: Wrench,
    accentColor: '#00D6A0',
    glowColor: 'rgba(0, 214, 160, 0.4)',
    badge: 'AR Routes',
    techTag: 'Laser AR'
  },
  {
    id: 'panel',
    modNumber: '03',
    labelKey: 'panelBuilder',
    icon: Server,
    accentColor: '#FF9A24',
    glowColor: 'rgba(255, 154, 36, 0.4)',
    badge: '3D Panel',
    techTag: 'DIN Rail'
  },
  {
    id: 'cad',
    modNumber: '04',
    labelKey: 'electricalCad',
    icon: Cpu,
    accentColor: '#8B5CFF',
    glowColor: 'rgba(139, 92, 255, 0.4)',
    badge: 'CAD / SLD',
    techTag: 'IEC / GOST'
  },
  {
    id: 'estimator',
    modNumber: '05',
    labelKey: 'materialEstimator',
    icon: Calculator,
    accentColor: '#147DFF',
    glowColor: 'rgba(20, 125, 255, 0.4)',
    badge: 'BOM Cost',
    techTag: 'Live Rates'
  }
];

export const SidebarNav: React.FC<SidebarNavProps> = ({ 
  onItemClick,
  className = '' 
}) => {
  const { activeModule, setActiveModule, t } = useProject();

  const handleSelectModule = (id: string) => {
    setActiveModule(id as any);
    if (onItemClick) {
      onItemClick();
    }
  };

  return (
    <nav className={`space-y-4 ${className}`} aria-label="Main Navigation">
      {/* Overview / Dashboard Entry */}
      <div>
        <button
          type="button"
          onClick={() => handleSelectModule('dashboard')}
          className={`w-full group relative flex items-center justify-between px-3 py-2.5 rounded-xl text-xs transition-all duration-200 border ${
            activeModule === 'dashboard'
              ? 'bg-gradient-to-r from-[#147DFF]/20 via-[#147DFF]/10 to-transparent border-[#147DFF]/50 text-white font-bold shadow-md shadow-black/20'
              : 'border-transparent text-[#9EB2CC] hover:text-[#F4F8FF] hover:bg-[#0B1C32] hover:border-[#1B3A5C]/60'
          }`}
          aria-current={activeModule === 'dashboard' ? 'page' : undefined}
        >
          {/* Active Left Indicator Bar */}
          {activeModule === 'dashboard' && (
            <div className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full bg-[#147DFF] shadow-[0_0_8px_#147DFF]" />
          )}

          <div className="flex items-center gap-3 truncate">
            {/* Standardized Icon Container */}
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all duration-200 ${
              activeModule === 'dashboard'
                ? 'bg-[#147DFF]/25 border-[#147DFF]/50 text-[#147DFF] shadow-[0_0_12px_rgba(20,125,255,0.35)] scale-105'
                : 'bg-[#061426] border-[#1B3A5C] text-[#9EB2CC] group-hover:text-[#147DFF] group-hover:border-[#147DFF]/40 group-hover:bg-[#10243D]'
            }`}>
              <LayoutDashboard className="w-4 h-4" />
            </div>

            <span className="truncate tracking-tight">{t.nav.dashboard}</span>
          </div>

          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border transition-colors ${
            activeModule === 'dashboard'
              ? 'bg-[#147DFF]/20 border-[#147DFF]/40 text-[#147DFF]'
              : 'bg-[#061426] border-[#1B3A5C] text-[#9EB2CC]'
          }`}>
            HQ
          </span>
        </button>
      </div>

      {/* The Five Main Modules Section */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between px-3 pb-1">
          <span className="text-[10px] font-bold text-[#9EB2CC] uppercase tracking-wider font-mono flex items-center gap-1.5">
            <Zap className="w-3 h-3 text-[#18D8F2]" />
            5 Core Engineering Modules
          </span>
          <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#061426] text-[#00D6A0] border border-[#00D6A0]/30">
            PRO 3.0
          </span>
        </div>

        <div className="space-y-1">
          {MAIN_MODULES.map((item) => {
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            const label = (t.nav as any)[item.labelKey] || item.labelKey;

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectModule(item.id)}
                className={`w-full group relative flex items-center justify-between px-3 py-2.5 rounded-xl text-xs transition-all duration-200 border ${
                  isActive
                    ? 'font-bold text-white shadow-lg shadow-black/30'
                    : 'border-transparent text-[#9EB2CC] hover:text-[#F4F8FF] hover:bg-[#0B1C32] hover:border-[#1B3A5C]/60 hover:translate-x-0.5'
                }`}
                style={isActive ? {
                  background: `linear-gradient(90deg, ${item.accentColor}25 0%, ${item.accentColor}08 70%, transparent 100%)`,
                  borderColor: `${item.accentColor}55`,
                  boxShadow: `0 4px 20px -2px ${item.accentColor}20`
                } : undefined}
                aria-current={isActive ? 'page' : undefined}
              >
                {/* Active Left Vertical Luminescent Pill */}
                {isActive && (
                  <div 
                    className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full transition-all"
                    style={{
                      backgroundColor: item.accentColor,
                      boxShadow: `0 0 10px ${item.accentColor}`
                    }}
                  />
                )}

                {/* Left Side: Standardized Uniform Icon + Module Title */}
                <div className="flex items-center gap-3 truncate">
                  {/* Uniform Icon Container */}
                  <div 
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border transition-all duration-200 ${
                      isActive ? 'scale-105' : 'bg-[#061426] border-[#1B3A5C] text-[#9EB2CC] group-hover:bg-[#10243D]'
                    }`}
                    style={isActive ? {
                      backgroundColor: `${item.accentColor}25`,
                      borderColor: `${item.accentColor}60`,
                      color: item.accentColor,
                      boxShadow: `0 0 14px ${item.accentColor}35`
                    } : undefined}
                  >
                    <Icon 
                      className={`w-4 h-4 transition-transform duration-200 ${isActive ? 'rotate-0' : 'group-hover:scale-110'}`} 
                      style={!isActive ? undefined : { color: item.accentColor }} 
                    />
                  </div>

                  <div className="flex flex-col text-left truncate">
                    <span className="truncate tracking-tight text-xs font-semibold group-hover:text-white transition-colors">
                      {label}
                    </span>
                    <span className="text-[9px] font-mono text-[#9EB2CC] group-hover:text-[#9EB2CC] flex items-center gap-1">
                      <span className="opacity-75">MOD {item.modNumber}</span>
                      <span>·</span>
                      <span style={{ color: isActive ? item.accentColor : undefined }}>
                        {item.techTag}
                      </span>
                    </span>
                  </div>
                </div>

                {/* Right Side: Module Badge */}
                <div className="flex items-center gap-1.5 shrink-0 pl-1">
                  <span 
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded border transition-colors ${
                      isActive ? 'font-bold' : 'bg-[#061426] border-[#1B3A5C] text-[#9EB2CC]'
                    }`}
                    style={isActive ? {
                      backgroundColor: `${item.accentColor}20`,
                      borderColor: `${item.accentColor}50`,
                      color: item.accentColor
                    } : undefined}
                  >
                    {item.badge}
                  </span>

                  {isActive ? (
                    <div 
                      className="w-1.5 h-1.5 rounded-full animate-pulse shrink-0"
                      style={{ backgroundColor: item.accentColor }}
                    />
                  ) : (
                    <ChevronRight className="w-3 h-3 text-[#9EB2CC]/40 group-hover:text-[#9EB2CC] group-hover:translate-x-0.5 transition-all" />
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
