import React from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  ShieldCheck, 
  CheckCircle2, 
  Layers, 
  Cpu, 
  Calculator,
  Calendar,
  Zap
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';

export const ReportsView: React.FC = () => {
  const { activeProject, powerCalculations, formatCurrency, addActivityLog } = useProject();
  const [downloadedDoc, setDownloadedDoc] = React.useState<string | null>(null);

  const totalWatts = activeProject.cadCircuits.reduce((a, b) => a + b.powerWatts, 0);
  const totalBOM = activeProject.materials.reduce((acc, m) => acc + (m.quantity * m.unitPriceUzS * (1 + m.wastePercent / 100)), 0);

  const reports = [
    {
      id: 'rep-load-flow',
      title: 'IEC 60364 Power Flow & Cable Thermal Sizing Audit',
      docCode: `EV-REP-CALC-${activeProject.code}`,
      desc: 'Complete mathematical verification of conductor ampacity, prospective short circuit current, and max voltage drop across all branch feeders.',
      status: 'Verified (Compliant)',
      icon: Cpu,
      color: 'text-[#8B5CFF]'
    },
    {
      id: 'rep-sld',
      title: 'Single-Line Diagram (SLD) Schematic Package',
      docCode: `EV-DRW-SLD-${activeProject.code}`,
      desc: 'Certified electrical schematic showing incoming feeder switchgear, RCD residual protection, busbar links, and terminal nodes.',
      status: 'Engineering Approved',
      icon: Layers,
      color: 'text-[#18D8F2]'
    },
    {
      id: 'rep-bom',
      title: 'Official Bill of Materials & Procurement Take-Off',
      docCode: `EV-BOM-${activeProject.code}`,
      desc: `Comprehensive itemized schedule of cables, conduits, DIN devices, and terminals with commercial costing (${formatCurrency(totalBOM)}).`,
      status: 'Live Synchronized',
      icon: Calculator,
      color: 'text-[#00D6A0]'
    }
  ];

  return (
    <div className="space-y-6 pb-12 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-[#061426] border border-[#1B3A5C] rounded-xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#8B5CFF]" />
            <h1 className="text-xl font-extrabold text-[#F4F8FF] tracking-tight">Engineering Certification Reports</h1>
          </div>
          <p className="text-xs text-[#9EB2CC] mt-1">Export formal engineering calculation sheets, schematics, and client compliance packages.</p>
        </div>

        <button
          onClick={() => window.print()}
          className="px-4 py-2 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#147DFF]/25 transition-all self-start sm:self-auto"
        >
          <Printer className="w-4 h-4" />
          <span>Print All Reports</span>
        </button>
      </div>

      <div className="space-y-4">
        {reports.map((rep) => {
          const Icon = rep.icon;
          return (
            <div
              key={rep.id}
              className="p-5 bg-[#0B1C32] border border-[#1B3A5C] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-[#147DFF]/40 transition-colors"
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#061426] border border-[#1B3A5C] flex items-center justify-center shrink-0">
                  <Icon className={`w-5 h-5 ${rep.color}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-[#F4F8FF]">{rep.title}</h3>
                    <span className="text-[10px] font-mono px-2 py-0.5 bg-[#061426] text-[#9EB2CC] rounded border border-[#1B3A5C]">
                      {rep.docCode}
                    </span>
                  </div>
                  <p className="text-xs text-[#9EB2CC] mt-1 max-w-2xl leading-relaxed">
                    {rep.desc}
                  </p>
                  <div className="flex items-center gap-3 mt-3 text-[11px] font-mono text-[#00D6A0]">
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{rep.status}</span>
                    </span>
                    <span className="text-[#9EB2CC]">·</span>
                    <span className="text-[#9EB2CC]">Project: {activeProject.name}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => window.print()}
                  className="px-3.5 py-1.5 bg-[#061426] hover:bg-[#10243D] text-[#F4F8FF] text-xs font-semibold rounded-lg border border-[#1B3A5C] flex items-center gap-1.5 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Sheet</span>
                </button>
                <button
                  onClick={() => {
                    addActivityLog({
                      action: 'Exported Report',
                      details: `Generated stamped engineering certificate ${rep.docCode} (${rep.title})`,
                      category: 'report',
                      status: 'completed',
                      user: 'Olimjon K.',
                      moduleTarget: 'reports'
                    });
                    setDownloadedDoc(rep.docCode);
                    setTimeout(() => setDownloadedDoc(null), 3000);
                  }}
                  className="px-3.5 py-1.5 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 shadow-md shadow-[#147DFF]/20 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{downloadedDoc === rep.docCode ? 'Exported!' : 'Download PDF'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
