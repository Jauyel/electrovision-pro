import React, { useState } from 'react';
import { 
  Box, 
  Upload, 
  Plus, 
  Save, 
  Eye, 
  Maximize2, 
  Trash2, 
  Info, 
  CheckCircle2, 
  Layers, 
  DoorClosed, 
  Square, 
  Lightbulb, 
  ToggleLeft, 
  Server, 
  Cpu, 
  ShieldAlert
} from 'lucide-react';
import { useProject } from '../../context/ProjectContext';
import { Room3DViewer } from './Room3DViewer';
import { ElectricalPoint, ElectricalPointType } from '../../types';
import { Modal } from '../common/Modal';

export const AIObjectScanner: React.FC = () => {
  const { 
    activeProject, 
    updateActiveProject, 
    addRoomPoint, 
    removeRoomPoint, 
    t, 
    triggerSave, 
    saveStatus 
  } = useProject();

  const [activeTab, setActiveTab] = useState<'2d' | '3d' | 'details' | 'points'>('2d');
  const [selectedPointId, setSelectedPointId] = useState<string | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadStep, setUploadStep] = useState<'idle' | 'analyzing' | 'done'>('idle');

  const room = activeProject.roomData;

  const handleUpdateDimensions = (key: 'lengthMeters' | 'widthMeters' | 'heightMeters', value: number) => {
    updateActiveProject(prev => ({
      ...prev,
      roomData: {
        ...prev.roomData,
        [key]: Math.max(1, value)
      }
    }));
  };

  const handleUpdateRoomMeta = (key: string, value: string) => {
    updateActiveProject(prev => ({
      ...prev,
      roomData: {
        ...prev.roomData,
        [key]: value
      }
    }));
  };

  // Add new electrical point
  const handleAddPoint = (type: ElectricalPointType) => {
    const defaultHeights: Record<ElectricalPointType, number> = {
      socket_single: 300,
      socket_double: 300,
      socket_wet: 1100,
      switch_1gang: 900,
      switch_2gang: 900,
      switch_dimmer: 900,
      ceiling_light: room.heightMeters * 1000,
      spotlight: room.heightMeters * 1000,
      led_strip: 2400,
      panel: 1600,
      ac_unit: 2600,
      oven: 450,
      boiler: 1400
    };

    const typeNames: Record<ElectricalPointType, string> = {
      socket_single: "Single Socket (16A)",
      socket_double: "Double Socket (16A)",
      socket_wet: "IP44 Water-Resistant Socket",
      switch_1gang: "1-Gang Rocker Switch",
      switch_2gang: "2-Gang Dual Switch",
      switch_dimmer: "Rotary LED Dimmer",
      ceiling_light: "Center Ceiling Fixture",
      spotlight: "Recessed Downlight",
      led_strip: "Architectural Cove Light",
      panel: "Distribution Sub-Panel",
      ac_unit: "Inverter AC Dedicated Feed",
      oven: "Heavy Cooker Outlet (32A)",
      boiler: "Water Heater Isolation Point"
    };

    const newPt: ElectricalPoint = {
      id: `pt-${Date.now()}`,
      type,
      name: typeNames[type],
      wall: type.includes('light') ? 'ceiling' : 'north',
      x: Number((room.lengthMeters / 2 + (Math.random() * 2 - 1)).toFixed(2)),
      y: Number((room.widthMeters / 2 + (Math.random() * 2 - 1)).toFixed(2)),
      heightMm: defaultHeights[type] || 900,
      wattage: type.includes('socket') ? 600 : type.includes('light') ? 60 : type.includes('ac') ? 2500 : 0,
      notes: "Configured via AI Room Palette"
    };

    addRoomPoint(newPt);
    setSelectedPointId(newPt.id);
  };

  const selectedPoint = room.points.find(p => p.id === selectedPointId);

  const handleUpdateSelectedPoint = (field: keyof ElectricalPoint, val: any) => {
    if (!selectedPointId) return;
    updateActiveProject(prev => ({
      ...prev,
      roomData: {
        ...prev.roomData,
        points: prev.roomData.points.map(pt => pt.id === selectedPointId ? { ...pt, [field]: val } : pt)
      }
    }));
  };

  // Simulate Floor Plan Image Upload & Optical Parsing
  const handleSimulateUpload = () => {
    setUploadStep('analyzing');
    setTimeout(() => {
      setUploadStep('done');
      setTimeout(() => {
        setIsUploadModalOpen(false);
        setUploadStep('idle');
      }, 1000);
    }, 1800);
  };

  return (
    <div className="space-y-4 pb-12 animate-fade-in">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-[#061426] border border-[#1B3A5C] rounded-xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#18D8F2]" />
            <h1 className="text-xl font-extrabold text-[#F4F8FF] tracking-tight">{t.scanner.title}</h1>
            <span className="text-[10px] font-mono uppercase bg-[#18D8F2]/15 text-[#18D8F2] px-2 py-0.5 rounded border border-[#18D8F2]/30">
              Module 01
            </span>
          </div>
          <p className="text-xs text-[#9EB2CC] mt-1">{t.scanner.subtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="px-3 py-1.5 bg-[#0B1C32] hover:bg-[#10243D] border border-[#1B3A5C] text-[#F4F8FF] rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-[#18D8F2]" />
            <span>{t.scanner.uploadImage}</span>
          </button>

          <button
            onClick={triggerSave}
            className="px-3.5 py-1.5 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md shadow-[#147DFF]/25 transition-all"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saveStatus === 'saved' ? t.saved : t.scanner.saveProject}</span>
          </button>
        </div>
      </div>

      {/* Main 3-Column / Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Tool Palette (2 cols) */}
        <div className="lg:col-span-2 space-y-3">
          <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl p-3 space-y-2">
            <div className="text-[11px] font-bold text-[#9EB2CC] uppercase tracking-wider px-1">
              Add Terminals
            </div>

            <div className="space-y-1.5">
              {[
                { type: 'socket_double' as const, label: '+ Socket 2P', icon: Square, color: 'text-[#147DFF]' },
                { type: 'socket_single' as const, label: '+ Socket 1P', icon: Square, color: 'text-[#147DFF]' },
                { type: 'switch_2gang' as const, label: '+ Dual Switch', icon: ToggleLeft, color: 'text-[#18D8F2]' },
                { type: 'ceiling_light' as const, label: '+ Ceiling Fixture', icon: Lightbulb, color: 'text-[#00D6A0]' },
                { type: 'spotlight' as const, label: '+ Spotlight', icon: Lightbulb, color: 'text-[#00D6A0]' },
                { type: 'panel' as const, label: '+ Electrical Panel', icon: Server, color: 'text-[#FF9A24]' },
                { type: 'ac_unit' as const, label: '+ HVAC Inverter', icon: Cpu, color: 'text-[#FF9A24]' },
              ].map((tool) => {
                const Icon = tool.icon;
                return (
                  <button
                    key={tool.type}
                    onClick={() => handleAddPoint(tool.type)}
                    className="w-full flex items-center gap-2 px-2.5 py-2 bg-[#061426] hover:bg-[#10243D] border border-[#1B3A5C] hover:border-[#18D8F2]/50 rounded-lg text-xs font-medium text-[#F4F8FF] transition-all text-left"
                  >
                    <Icon className={`w-3.5 h-3.5 ${tool.color} shrink-0`} />
                    <span className="truncate">{tool.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Room Specs */}
          <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl p-3 space-y-2 text-xs">
            <div className="text-[11px] font-bold text-[#9EB2CC] uppercase tracking-wider px-1">
              Room Dimensions
            </div>
            <div className="space-y-2">
              <div>
                <label className="text-[10px] text-[#9EB2CC] font-mono">Length (L)</label>
                <input
                  type="number"
                  step="0.1"
                  value={room.lengthMeters}
                  onChange={(e) => handleUpdateDimensions('lengthMeters', parseFloat(e.target.value) || 1)}
                  className="w-full px-2.5 py-1 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono text-[#F4F8FF]"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#9EB2CC] font-mono">Width (W)</label>
                <input
                  type="number"
                  step="0.1"
                  value={room.widthMeters}
                  onChange={(e) => handleUpdateDimensions('widthMeters', parseFloat(e.target.value) || 1)}
                  className="w-full px-2.5 py-1 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono text-[#F4F8FF]"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#9EB2CC] font-mono">Height (H)</label>
                <input
                  type="number"
                  step="0.1"
                  value={room.heightMeters}
                  onChange={(e) => handleUpdateDimensions('heightMeters', parseFloat(e.target.value) || 1)}
                  className="w-full px-2.5 py-1 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono text-[#F4F8FF]"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Central Visualization Canvas (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          {/* Workspace Tabs */}
          <div className="flex items-center justify-between bg-[#061426] p-1.5 rounded-xl border border-[#1B3A5C]">
            <div className="flex items-center gap-1">
              <button
                onClick={() => setActiveTab('2d')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === '2d' 
                    ? 'bg-[#18D8F2]/20 text-[#18D8F2] border border-[#18D8F2]/40' 
                    : 'text-[#9EB2CC] hover:text-[#F4F8FF]'
                }`}
              >
                {t.scanner.tab2d}
              </button>
              <button
                onClick={() => setActiveTab('3d')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === '3d' 
                    ? 'bg-[#147DFF]/20 text-[#147DFF] border border-[#147DFF]/40' 
                    : 'text-[#9EB2CC] hover:text-[#F4F8FF]'
                }`}
              >
                {t.scanner.tab3d}
              </button>
              <button
                onClick={() => setActiveTab('points')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  activeTab === 'points' 
                    ? 'bg-[#00D6A0]/20 text-[#00D6A0] border border-[#00D6A0]/40' 
                    : 'text-[#9EB2CC] hover:text-[#F4F8FF]'
                }`}
              >
                {t.scanner.tabPoints} ({room.points.length})
              </button>
            </div>

            <div className="text-[11px] font-mono text-[#9EB2CC] px-2 hidden sm:block">
              Floor Area: {(room.lengthMeters * room.widthMeters).toFixed(1)} m²
            </div>
          </div>

          {/* Active Canvas Body */}
          {activeTab === '3d' ? (
            <Room3DViewer
              roomData={room}
              selectedPointId={selectedPointId}
              onSelectPoint={setSelectedPointId}
            />
          ) : activeTab === '2d' ? (
            <div className="relative w-full h-[520px] rounded-xl overflow-hidden border border-[#1B3A5C] bg-[#061426] blueprint-grid flex items-center justify-center p-8 select-none">
              {/* 2D Architectural Floor Plan Interactive Canvas */}
              <div 
                className="relative bg-[#0B1C32]/90 border-2 border-[#18D8F2] rounded shadow-2xl transition-all"
                style={{
                  width: `${Math.min(540, room.lengthMeters * 65)}px`,
                  height: `${Math.min(420, room.widthMeters * 65)}px`,
                }}
              >
                {/* Wall Labels & Dimensions */}
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-[10px] font-mono text-[#18D8F2] bg-[#061426] px-2 py-0.5 rounded border border-[#1B3A5C]">
                  North Wall ({room.lengthMeters}m)
                </div>
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-mono text-[#9EB2CC] bg-[#061426] px-2 py-0.5 rounded border border-[#1B3A5C]">
                  South Wall ({room.lengthMeters}m)
                </div>
                <div className="absolute -left-16 top-1/2 -translate-y-1/2 -rotate-90 text-[10px] font-mono text-[#9EB2CC] bg-[#061426] px-2 py-0.5 rounded border border-[#1B3A5C]">
                  West Wall ({room.widthMeters}m)
                </div>
                <div className="absolute -right-16 top-1/2 -translate-y-1/2 rotate-90 text-[10px] font-mono text-[#9EB2CC] bg-[#061426] px-2 py-0.5 rounded border border-[#1B3A5C]">
                  East Wall ({room.widthMeters}m)
                </div>

                {/* Door Opening Representation */}
                <div className="absolute left-0 top-1/4 w-2 h-14 bg-[#FF9A24] rounded-r" title="Door (1.0m)" />

                {/* Window Opening Representation */}
                <div className="absolute top-0 left-1/3 h-2 w-28 bg-[#18D8F2]/60 rounded-b" title="Terrace Window" />

                {/* Render All Electrical Points in 2D with exact coordinates */}
                {room.points.map((pt) => {
                  const isSelected = pt.id === selectedPointId;
                  const leftPercent = (pt.x / room.lengthMeters) * 100;
                  const topPercent = (pt.y / room.widthMeters) * 100;

                  let colorBg = 'bg-[#147DFF]';
                  if (pt.type.includes('light')) colorBg = 'bg-[#00D6A0]';
                  if (pt.type.includes('panel')) colorBg = 'bg-[#FF9A24]';
                  if (pt.type.includes('switch')) colorBg = 'bg-[#18D8F2]';

                  return (
                    <div
                      key={pt.id}
                      onClick={() => setSelectedPointId(pt.id)}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform hover:scale-125 z-20 ${
                        isSelected ? 'scale-125 ring-2 ring-[#FF9A24]' : ''
                      }`}
                      style={{ left: `${Math.min(96, Math.max(4, leftPercent))}%`, top: `${Math.min(96, Math.max(4, topPercent))}%` }}
                      title={`${pt.name} (${pt.heightMm}mm)`}
                    >
                      <div className={`w-5 h-5 rounded-md ${colorBg} flex items-center justify-center shadow-lg text-[9px] font-bold text-[#030B18]`}>
                        {pt.type.includes('socket') ? 'S' : pt.type.includes('switch') ? 'W' : pt.type.includes('panel') ? 'P' : 'L'}
                      </div>
                      <div className="absolute left-6 top-0 text-[9px] font-mono whitespace-nowrap bg-[#061426]/90 px-1 py-0.2 rounded border border-[#1B3A5C] text-[#F4F8FF] pointer-events-none">
                        {pt.name.split(' ')[0]}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Bottom 2D Legend */}
              <div className="absolute bottom-3 left-4 flex items-center gap-3 bg-[#0B1C32]/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#1B3A5C] text-[11px] font-mono">
                <span className="flex items-center gap-1 text-[#147DFF]">
                  <span className="w-2 h-2 rounded bg-[#147DFF]" /> Sockets
                </span>
                <span className="flex items-center gap-1 text-[#18D8F2]">
                  <span className="w-2 h-2 rounded bg-[#18D8F2]" /> Switches
                </span>
                <span className="flex items-center gap-1 text-[#00D6A0]">
                  <span className="w-2 h-2 rounded bg-[#00D6A0]" /> Lighting
                </span>
                <span className="flex items-center gap-1 text-[#FF9A24]">
                  <span className="w-2 h-2 rounded bg-[#FF9A24]" /> Panel
                </span>
              </div>
            </div>
          ) : (
            /* Table of Points */
            <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl overflow-hidden">
              <table className="w-full text-xs text-left">
                <thead className="bg-[#061426] border-b border-[#1B3A5C] text-[#9EB2CC] uppercase font-mono text-[10px]">
                  <tr>
                    <th className="px-4 py-2.5">Point Name</th>
                    <th className="px-3 py-2.5">Type</th>
                    <th className="px-3 py-2.5">Elevation (mm)</th>
                    <th className="px-3 py-2.5">Location (x, y)</th>
                    <th className="px-3 py-2.5">Load (W)</th>
                    <th className="px-3 py-2.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1B3A5C]/50">
                  {room.points.map(pt => (
                    <tr
                      key={pt.id}
                      onClick={() => setSelectedPointId(pt.id)}
                      className={`hover:bg-[#10243D] cursor-pointer transition-colors ${
                        pt.id === selectedPointId ? 'bg-[#147DFF]/10 text-[#18D8F2]' : 'text-[#F4F8FF]'
                      }`}
                    >
                      <td className="px-4 py-2 font-medium">{pt.name}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-[#9EB2CC]">{pt.type}</td>
                      <td className="px-3 py-2 font-mono">{pt.heightMm} mm</td>
                      <td className="px-3 py-2 font-mono text-[#9EB2CC]">{pt.x}m, {pt.y}m</td>
                      <td className="px-3 py-2 font-mono">{pt.wattage} W</td>
                      <td className="px-3 py-2 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            removeRoomPoint(pt.id);
                          }}
                          className="p-1 text-[#FF5263] hover:bg-[#FF5263]/20 rounded transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Right Properties & Inspector Panel (3 cols) */}
        <div className="lg:col-span-3 space-y-3">
          <div className="bg-[#0B1C32] border border-[#1B3A5C] rounded-xl p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-[#1B3A5C] pb-2">
              <h3 className="text-xs font-bold text-[#F4F8FF] uppercase tracking-wider">
                {selectedPoint ? t.scanner.selectedObject : t.scanner.tabDetails}
              </h3>
              {selectedPoint && (
                <button
                  onClick={() => removeRoomPoint(selectedPoint.id)}
                  className="text-[10px] text-[#FF5263] hover:underline flex items-center gap-1 font-mono"
                >
                  <Trash2 className="w-3 h-3" /> Delete
                </button>
              )}
            </div>

            {selectedPoint ? (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">Terminal Label</label>
                  <input
                    type="text"
                    value={selectedPoint.name}
                    onChange={(e) => handleUpdateSelectedPoint('name', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs text-[#F4F8FF] font-medium"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">Mounting Height (mm from FFL)</label>
                  <input
                    type="number"
                    step="50"
                    value={selectedPoint.heightMm}
                    onChange={(e) => handleUpdateSelectedPoint('heightMm', parseInt(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono text-[#F4F8FF]"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">Connected Load (Watts)</label>
                  <input
                    type="number"
                    step="50"
                    value={selectedPoint.wattage}
                    onChange={(e) => handleUpdateSelectedPoint('wattage', parseInt(e.target.value) || 0)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs font-mono text-[#F4F8FF]"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">Associated Circuit Tag</label>
                  <input
                    type="text"
                    value={selectedPoint.circuitId || ''}
                    placeholder="e.g. QF1, QF2"
                    onChange={(e) => handleUpdateSelectedPoint('circuitId', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs text-[#F4F8FF]"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">Engineering Notes</label>
                  <textarea
                    rows={2}
                    value={selectedPoint.notes || ''}
                    onChange={(e) => handleUpdateSelectedPoint('notes', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs text-[#F4F8FF]"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3 text-xs">
                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">{t.scanner.roomName}</label>
                  <input
                    type="text"
                    value={room.roomName}
                    onChange={(e) => handleUpdateRoomMeta('roomName', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs text-[#F4F8FF]"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">{t.scanner.roomType}</label>
                  <select
                    value={room.roomType}
                    onChange={(e) => handleUpdateRoomMeta('roomType', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs text-[#F4F8FF]"
                  >
                    <option value="living_room">Living Room & Lounge</option>
                    <option value="kitchen">Commercial / Domestic Kitchen</option>
                    <option value="office">Executive Office</option>
                    <option value="server_room">Server Room / Data NOC</option>
                    <option value="electrical_room">Electrical Switchboard Room</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-[#9EB2CC] font-mono">{t.scanner.notes}</label>
                  <textarea
                    rows={3}
                    value={room.notes}
                    onChange={(e) => handleUpdateRoomMeta('notes', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-[#061426] border border-[#1B3A5C] rounded text-xs text-[#F4F8FF]"
                  />
                </div>

                <div className="p-3 bg-[#061426] rounded-lg border border-[#1B3A5C] text-[11px] text-[#9EB2CC] space-y-1">
                  <div className="font-semibold text-[#18D8F2]">Standards Guidance:</div>
                  <p>{t.scanner.disclaimer}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Upload Floor Plan Modal */}
      <Modal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        title="Import Architectural CAD Plan / Laser Scan"
        subtitle="Upload PNG, PDF, or DXF floor plans to calibrate spatial geometry."
      >
        <div className="space-y-4">
          <div className="border-2 border-dashed border-[#1B3A5C] hover:border-[#18D8F2] rounded-xl p-8 text-center cursor-pointer transition-colors bg-[#061426]">
            <Upload className="w-8 h-8 text-[#18D8F2] mx-auto mb-3" />
            <div className="text-xs font-bold text-[#F4F8FF]">Click to browse or drop architectural drawings</div>
            <p className="text-[11px] text-[#9EB2CC] mt-1">Supports PDF, DWG, DXF, PNG (Max 50MB)</p>
          </div>

          {uploadStep === 'analyzing' && (
            <div className="p-4 bg-[#061426] rounded-xl border border-[#18D8F2]/40 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#18D8F2] flex items-center gap-1.5">
                  <div className="w-3 h-3 border-2 border-[#18D8F2] border-t-transparent rounded-full animate-spin" />
                  Calibrating scale & wall boundaries...
                </span>
                <span className="text-[#9EB2CC]">78%</span>
              </div>
              <div className="w-full h-1.5 bg-[#10243D] rounded-full overflow-hidden">
                <div className="h-full bg-[#18D8F2] rounded-full w-3/4 animate-pulse" />
              </div>
            </div>
          )}

          {uploadStep === 'done' && (
            <div className="p-3 bg-[#00D6A0]/15 border border-[#00D6A0]/40 rounded-xl text-xs text-[#00D6A0] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Calibration complete! Room dimensions and 9 terminals mapped.</span>
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1B3A5C]">
            <button
              onClick={() => setIsUploadModalOpen(false)}
              className="px-3 py-1.5 bg-[#061426] text-xs font-medium text-[#9EB2CC] rounded-lg"
            >
              Cancel
            </button>
            <button
              onClick={handleSimulateUpload}
              disabled={uploadStep === 'analyzing'}
              className="px-4 py-1.5 bg-[#147DFF] hover:bg-[#147DFF]/90 text-white text-xs font-bold rounded-lg shadow"
            >
              Simulate Import
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
